package com.mkyong.rest.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class NetClientGet {

	private static XSSFWorkbook workBook;
	private static XSSFSheet sheet;
	private static Integer testCount = 1;
	public static int[] versionArray = {/*4, 12,*/ 14/*, 16, 18, 20, 22, 24, 32*/};
	// private static int[] versionArray = { 12 };
	private static Map<Integer, List<Map<Integer, List<Long>>>> productVersionHashMap;

	public static void main(String[] args) {
		try {
			masterMethod();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void masterMethod() throws Exception {
		for (int version : versionArray) {
			productVersionHashMap = new HashMap<>();
			populateVersionArray(version);
			getRunCaseVersionData();
			printHashMap();
		}
	}

	private static void populateVersionArray(int version) throws URISyntaxException, IOException {
		Integer offset = 0;
		Integer limit = 500;
		Boolean loadMore = Boolean.TRUE;
		String runUrl = "http://172.20.19.162:8000/api/v1/run/?format=json&productversion_product_name=DSMC&productversion="
				+ version;
		List<Map<Integer, List<Long>>> runCaseIdList = new ArrayList<>();
		productVersionHashMap.put(version, runCaseIdList);
		while (loadMore) {
			URL url = new URL(runUrl + "&limit=" + limit + "&offset=" + offset);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setReadTimeout(10000);
			conn.setConnectTimeout(10000);
			conn.setRequestProperty("Accept", "application/json");
			checkResponseCode(conn.getResponseCode());
			//BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			
			//System.out.println(br.toString());
			//for (String response = br.readLine(); response != null; response = br.readLine()) {
			// String response = br.readLine();
			/*URI uri = new URI(runUrl + "&limit=" + limit + "&offset=" + offset);
			// create HttpClient
			
	        HttpClient httpclient = new DefaultHttpClient();

	        // make GET request to the given URL ...use
	        HttpResponse httpResponse = httpclient.execute(new HttpGet(uri));

	        // receive response as inputStream
	        HttpEntity entity = httpResponse.getEntity();

	        String response= EntityUtils.toString(entity);*/
			int x;
		    StringBuilder response = new StringBuilder();
			try (InputStream in = conn.getInputStream();) {
				boolean flag = true;
				while (flag) {
					;
					if (-1 != (x = in.read())) {
						response.append((char) x);
					}
				}
			} catch (IOException ex) {
		    	System.out.println();
		    }
		    System.out.println(response);
					JsonParser jsonParser = new JsonParser();
					JsonObject jsonResponseObject = (JsonObject) jsonParser.parse(response.toString());
					// System.out.println("META Information");
					Integer totalCount = new Integer(
							jsonResponseObject.get("meta").getAsJsonObject().get("total_count").getAsString());
					if (totalCount < offset) {
						loadMore = Boolean.FALSE;
					}
					// System.out.println(jsonObject.get("meta"));
					System.out.println("Test Cases : " + jsonResponseObject.getAsJsonArray("objects").size()
							+ " Offset : " + offset + " Total Count : " + totalCount);
					JsonArray objectsArray = jsonResponseObject.getAsJsonArray("objects");
					for (JsonElement jo : objectsArray) {
						List<Long> runCaseVersionsIdList = getRunCaseVersionsIdList(
								jo.getAsJsonObject().getAsJsonArray("runcaseversions"));
						populateHashMap(version, jo.getAsJsonObject().get("id").getAsInt(), runCaseVersionsIdList);
					}
			// }
			conn.disconnect();
			/*entity.consumeContent();*/
			offset += limit;
		}
	}

	private static void printHashMap() {
		for (List<Map<Integer, List<Long>>> list : productVersionHashMap.values()) {
			for (Map<Integer, List<Long>> map : list) {
				for (List<Long> l : map.values()) {
					System.out.println(l);
				}
			}
		}
	}

	private static List<Long> getRunCaseVersionsIdList(JsonArray runCaseVersionsJsonArray) {
		List<Long> runCaseVersionsIdList = new ArrayList<>();
		if (runCaseVersionsJsonArray.size() != 0) {
			Long runCaseVersionId;
			for (JsonElement jo : runCaseVersionsJsonArray) {
				runCaseVersionId = Long.valueOf(jo.getAsString().split("/")[4]);
				runCaseVersionsIdList.add(runCaseVersionId);
			}
		}
		return runCaseVersionsIdList;
	}

	private static void checkResponseCode(int responseCode) {
		if (responseCode != 200) {
			throw new RuntimeException("Failed : HTTP error code : " + responseCode);
		}
	}

	private static void populateHashMap(Integer version, Integer runCaseId, List<Long> runCaseVersionsIdList) {
		if (runCaseId != null) {
			Map<Integer, List<Long>> runCaseMap = new HashMap<>();
			runCaseMap.put(runCaseId, runCaseVersionsIdList);
			productVersionHashMap.get(version).add(runCaseMap);
		}
	}

	private static void getRunCaseVersionData() throws Exception {
		Set<Entry<Integer, List<Map<Integer, List<Long>>>>> productVersionEntrySet = productVersionHashMap.entrySet();
		Iterator<Entry<Integer, List<Map<Integer, List<Long>>>>> productVersionEntrySetIterator = productVersionEntrySet
				.iterator();
		File dir = new File("D:\\Jira-Zephyr");
		removeDirectory(dir);
		createDirectory(dir);
		while (productVersionEntrySetIterator.hasNext()) {
			
			Entry<Integer, List<Map<Integer, List<Long>>>> productVersionEntry = productVersionEntrySetIterator.next();
			for (Map<Integer, List<Long>> runCaseMap : productVersionEntry.getValue()) {
				Set<Entry<Integer, List<Long>>> runCaseMapEntrySet = runCaseMap.entrySet();
				Iterator<Entry<Integer, List<Long>>> runCaseMapEntrySetIterator = runCaseMapEntrySet.iterator();
				while (runCaseMapEntrySetIterator.hasNext()) {
					Entry<Integer, List<Long>> runCaseMapEntry = runCaseMapEntrySetIterator.next();
					for (Long runCaseVersionId : runCaseMapEntry.getValue()) {
						String fileName = "D:\\Jira-Zephyr\\DSMC_Version_" + productVersionEntry.getKey() + "_Run_Case_Version_" + runCaseMapEntry.getKey()
								+ "_Run_Case_Version_ID_" + runCaseVersionId + ".xlsx";
						createFile();
						createExcelFilesWithRunCaseVersionData(runCaseVersionId);
						closeFile(fileName);
					}
				}
			}
		}
	}

	private static void createDirectory(File dir) {
		if(!(dir.exists() && dir.isDirectory())) {
			dir.mkdir();
		}
	}

	private static void removeDirectory(File dir) {
		if (dir.isDirectory()) {
			File[] files = dir.listFiles();
			if (files != null && files.length > 0) {
				for (File aFile : files) {
					removeDirectory(aFile);
				}
			}
			dir.delete();
		} else {
			dir.delete();
		}
	}

	private static void createExcelFilesWithRunCaseVersionData(Long runCaseVersionId) throws IOException {
		Integer offset = 0;
		Integer limit = 500;
		Boolean loadMore = Boolean.TRUE;
		if (runCaseVersionId != null) {
			String runCaseVerionUrl = "http://172.20.19.162:8000/api/v1/runcaseversion/?format=json&runcaseversion="
					+ runCaseVersionId + "/";
			while (loadMore) {
				URL url = new URL(runCaseVerionUrl + "&limit=" + limit + "&offset=" + offset);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");
				conn.setReadTimeout(60000);
				conn.setConnectTimeout(60000);
				checkResponseCode(conn.getResponseCode());
				int x;
			    StringBuilder response = new StringBuilder();
				try (InputStream in = conn.getInputStream();) {
					boolean flag = true;
					while (flag) {
						;
						if (-1 != (x = in.read())) {
							response.append((char) x);
						}
					}
				} catch (IOException ex) {
			    	System.out.println();
			    }
					// System.out.println(output);
					JsonParser jsonParser = new JsonParser();
					JsonObject jsonResponseObject = (JsonObject) jsonParser.parse(response.toString());
					// System.out.println("META Information");
					Integer totalCount = new Integer(
							jsonResponseObject.get("meta").getAsJsonObject().get("total_count").getAsString());
					if (totalCount < offset) {
						loadMore = Boolean.FALSE;
					}
					// System.out.println(jsonObject.get("meta"));
					System.out.println("Test Cases : " + jsonResponseObject.getAsJsonArray("objects").size()
							+ " Offset : " + offset + " Total Count : " + totalCount);
					writeToExcel(jsonResponseObject);
				conn.disconnect();
				offset += limit;
			}
		}
	}

	private static void createFile() throws Exception {
		workBook = new XSSFWorkbook();
		sheet = workBook.createSheet("Test Runs");
	}

	private static void closeFile(String fileName) throws Exception {
		File file = new File(fileName);
		if(file.exists()) {
			file.delete();
		}
		file.createNewFile();
		FileOutputStream outStream = new FileOutputStream(file);
		workBook.write(outStream);
		outStream.close();
	}

	private static void writeToExcel(JsonObject jsonObject) {
		int count = 1;
		for (JsonElement testCase : jsonObject.getAsJsonArray("objects")) {
			JsonObject testCaseObj = testCase.getAsJsonObject().get("caseversion").getAsJsonObject();
			if (testCaseObj.get("status").getAsString().equals("active")) {
				String testCaseId = testCaseObj.get("case").getAsString();
				testCaseId = testCaseId.substring(13, testCaseId.lastIndexOf("/"));
				// System.out.println("Test Case : " + testCount);
				// System.out.println("ID : " + testCaseObj.get("case"));
				// System.out.println("Name : " + testCaseObj.get("name"));
				// System.out.println("Description : " +
				// testCaseObj.get("description"));
				// System.out.println(" * Steps * " +
				// testCaseObj.getAsJsonArray("steps").size());
				Integer stepCount = 1;
				for (JsonElement testStep : testCaseObj.getAsJsonArray("steps")) {
					JsonObject testStepObj = testStep.getAsJsonObject();
					// System.out.println("Intruction : " +
					// testStepObj.get("instruction"));
					// System.out.println("Expected : " +
					// testStepObj.get("expected"));
					XSSFRow row = sheet.createRow(count++);
					row.createCell(0).setCellValue(testCaseObj.get("name").getAsString());
					row.createCell(1).setCellValue("Step " + stepCount++);
					row.createCell(2).setCellValue(testStepObj.get("instruction").getAsString());
					row.createCell(4).setCellValue(testStepObj.get("expected").getAsString());
					row.createCell(5).setCellValue(testCaseId);
					if (stepCount == 2) {
						row.createCell(7).setCellValue(testCount);
					}
				}
				testCount++;
			}
		}
	}
}