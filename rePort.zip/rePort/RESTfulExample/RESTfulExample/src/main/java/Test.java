import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Test {
	private static Map<Integer, List<Map<Integer, List<Long>>>> productVersionHashMap = new HashMap<>();
	public static void main(String[] args) {
		List<Map<Integer, List<Long>>> runCaseIdList = new ArrayList<>();
		productVersionHashMap.put(12, runCaseIdList);
		Map<Integer, List<Long>> map = new HashMap<>();
		List<Long> runCaseVersionsIdList = new ArrayList<>();
		runCaseVersionsIdList.add(39442L);
		map.put(42, runCaseVersionsIdList);
		productVersionHashMap.get(12).add(map);
		System.out.println(productVersionHashMap.get(12).get(0).get(42));
	}
	
	public static int[] getArray() {
		int temp[] = new int[10];
		for(int count=0;count<10;count++) {
			temp[count] = count;
		}
		System.out.println(temp[1]);
		return temp;
	}
}
