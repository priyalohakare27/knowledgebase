#!/bin/bash

#
# Usage: /opt/jasper_backups/jasper_backups.sh [preinstall](or [postinstall])
#
# Example:
#   /* For doing the /opt/jasper/postgresql/bin/pg_dump backup only */
#   /opt/jasper_backups/jasper_backups.sh
#
#   /* For doing both the pg_dump backup backup plus backing up the 'jasperserver-pro'
#    * (or 'reporting') Application Directory before application/war-file installation.
#    * Note: This command should ONLY be used during application deployment.
#    */
#   /opt/jasper_backups/jasper_backups.sh preinstall
#
#   /* For doing both the pg_dump backup backup plus backing up the 'jasperserver-pro'
#    * (or 'reporting') Application Directory after application/war-file installation.
#    * Note: This command should ONLY be used during application deployment.
#    */
#   /opt/jasper_backups/jasper_backups.sh postinstall
#

IFS='
'
 
PATH=/usr/kerberos/sbin:/usr/kerberos/bin:/usr/bin:/bin:/root/bin:/sbin:/usr/sbin:/usr/bin:/usr/local/bin:.:

JASPERBK=jasper-$( date +%u ).gz

BACKUPDIR=/opt/jasper_backups
export PGPASSWORD=postgres

DB_PORT=`grep "dbPort=" /opt/jasper/buildomatic/build_conf/default/db.properties | cut -d= -f2`
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: postgres DB_PORT is ${DB_PORT}"

/opt/jasper/postgresql/bin/pg_dump -p${DB_PORT} -Upostgres jasperserver | gzip -9 > ${BACKUPDIR}/${JASPERBK}

function doFullJasperBackup()
{
    local tag= bkdir=
    tag="$1"
    bkdir="$2"

    jasper_inst_dir="/opt/jasper"
    # Just double check that /opt/jasper does exist
    if [ ! -e ${jasper_inst_dir} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* The ${jasper_inst_dir} symbolic link does not exist!"
       exit 1
    fi

    jasper_webapps_dir=`ls -d ${jasper_inst_dir}/*tomcat/webapps`
    jasper_appDir_name="reporting"
    jasper_app_dir="${jasper_webapps_dir}/${jasper_appDir_name}"
    jasper_appDir_bk_file="${bkdir}/jasperAppDir-${tag}-bk.tar.gz"
    jasper_reportServRepo_exp_zip="${bkdir}/jasperReportServRepo-${tag}-export.zip"
    jasper_reportServRepo_export_script="${jasper_inst_dir}/buildomatic/js-export.sh"

    # Just double check that the backup directory does exist
    if [ ! -d ${bkdir} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* The backup directory, '${bkdir}', does not exist!"
       exit 1
    fi

    # Just double check that the Jasper application directory does exist
    if [ ! -d ${jasper_app_dir} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: The Jasper application directory, '${jasper_app_dir}', does not exist!"
       jasper_appDir_name="jasperserver-pro"
       jasper_app_dir="${jasper_webapps_dir}/${jasper_appDir_name}"
       echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Try '${jasper_app_dir}', instead then..."
       if [ ! -d ${jasper_app_dir} ]; then
          echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* The Jasper application directory, '${jasper_app_dir}', does not exist!"
          exit 1
       fi
    fi

    echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Start backing up ${jasper_app_dir}"
    (cd ${jasper_webapps_dir}; tar -zcf ${jasper_appDir_bk_file} ${jasper_appDir_name})
    if [ $? != 0 ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* tar -zcf ${jasper_appDir_bk_file} ${jasper_appDir_name} FAILED!"
       exit 1;
    else
       echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Completed backing up ${jasper_appDir_name} (into ${jasper_appDir_bk_file})"
    fi

    # Just double check that the js-export.sh script does exist
    if [ ! -e ${jasper_reportServRepo_export_script} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* '${jasper_reportServRepo_export_script}' does not exist!"
       exit 1
    fi

    echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Start exporting the JasperReport Server Repository"
    ${jasper_reportServRepo_export_script} --everything --output-zip ${jasper_reportServRepo_exp_zip}
    if [ $? != 0 ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${jasper_reportServRepo_export_script} --everything --output-zip ${jasper_reportServRepo_exp_zip} FAILED!"
       exit 1;
    else
       echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Completed exporting the JasperReport Server Repository (into ${jasper_reportServRepo_exp_zip})"
    fi
}

# If specified, do the full backup of the Jasper by
# 1) backing up the Jasper application directory
# 2) and exporting the JasperReport Server Repository
if [ $# -eq 1 ]; then
   doFullJasperBackup $1 ${BACKUPDIR}
fi

