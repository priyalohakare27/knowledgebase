#!/usr/bin/env perl

BEGIN {
unshift @INC, "@{ [$0 =~ m|^(.*[\/\\])|] }";
};

use strict;
use warnings;

use BRS::Build;
use BRS::Release;
use BRS::Release::FullRelease;
use BRS::Release::FullRelease::Deploy;
use BRS::Utils;


my $fullRelease = new BRS::Release::FullRelease::Deploy( getArgs() ); 

$fullRelease->print_info();
print "\n";

$fullRelease->deploy();
