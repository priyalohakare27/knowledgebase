#!/bin/bash

#################################################################################################
# The purpose of this script is to automatically update QA/DEV/DEMO/STG/PROD application servers
# with the latest BRS src code whenever there's any relevant code change so that build/deployment
# scripts on these servers are always up-to-date. Therefore, this script will be executed through
# relevant Jenkins build jobs which in turn will be triggering by the post-commit hook script.
#
# Here's the flow of executions:
#
#   <Changes committed to src code repository>
#                       ||
#                       VV
#   <post-commit hook script triggers the Jenkins build, BRS-pkg-latest-code
#    to package the latest BRS source code into BRS_latestCode.tar.gz>
#                       ||
#                       VV
#   <Upon successfully completion, BRS-pkg-latest-code launch another Jenkins
#    build, BRS-update-scripts-on-appserver>
#                       ||
#                       VV
#   <BRS-update-scripts-on-appserver executes the driver script (on the build server),
#    update-BRS-scripts-on-appserver.sh>
#                       ||
#                       VV
#   <update-BRS-scripts-on-appserver.sh in turn executes this script on the given
#    remote server through ssh>
#
####################################################################################################

function Usage
{
   echo ""
   echo "Usage: $0 <APP_USR> <JOB_NAME> <BUILD_NUM> [APP_SERV_IP] [tmpDownldDir]"
   echo ""
   echo "   where"
   echo ""
   echo "         <APP_USR> : The user account under which the application instance is running"
   echo "                     (e.g. 'traksmart' for Traksmart related applications)."
   echo ""
   echo "        <JOB_NAME> : The name of Jenkins job (i.e. BRS-pkg-latest-code)to download"
   echo "                     the latest BRS src code .gz file (i.e. BRS_latestCode.tar.gz)"
   echo ""
   echo "       <BUILD_NUM> : The build number of JOB_NAME with which BRS_latestCode.tar.gz"
   echo "                     was built"
   echo ""
   echo "     [APP_SERV_IP] : The IP address of the targeted app. server (e.g. 192.168.48.90)"
   echo "                     to be updating with the latest BRS src code. This is an optional"
   echo "                     argument to be used only for server on the 192 domain"
   echo ""
   echo "    [tmpDownldDir] : The temporary directory on the targeted app. server that holds the"
   echo "                     latest BRS src code .gz file to be updating. This is an optional"
   echo "                     argument to be used only for server on the 192 domain because we"
   echo "                     will need to scp the BRS src code .gz file to app. servers that"
   echo "                     are on the 192 domain as we cannot directly wget the file (storing"
   echo "                     on the 172 domain) due to the domain difference"
   echo ""
   echo "Example:"
   echo "--------"
   echo "  $0 traksmart BRS-pkg-latest-code 3"
   echo ""
   echo "  $0 traksmart BRS-pkg-latest-code 3 192.168.48.90 /tmp/192.168.48.90-pkg-latest-code_7.2014-04-23-14-46-57"
   echo ""
   exit
}

##################
# Verify arguments
##################
if [ $# -lt 3 ] || [ $# -gt 5 ]; then
   Usage
fi

#################
# Arguments given
#################
APP_USR=$1
JOB_NAME=$2
BUILD_NUM=$3

if [ $# -eq 5 ]; then
   APP_SERV_IP=$4
   tmpDownldDir=$5
   IP_PREFIX=`echo ${APP_SERV_IP} | cut -d '.' -f1`
fi

BUILD_SERV_URL="http://172.20.19.61:9090"
BRS_CODE_GZ_FILE="BRS_latestCode.tar.gz"
INIT_PROC_SCRIPT="processInstanceServProcess.sh"
DB_BK_SCRIPT="db_backup.sh"
BRS_CODE_GZ_URL="${BUILD_SERV_URL}/job/${JOB_NAME}/${BUILD_NUM}/artifact/target/${BRS_CODE_GZ_FILE}"
HOME_DIR="/home/${APP_USR}"
BIN_DIR="${HOME_DIR}/bin"
SCRIPT_DIR="${BIN_DIR}/BRS-CD"
LOG_FILE="/tmp/update-BRS-scripts.log"
EMAIL_LIST="mailto:mchu@nexant.com"

cd ${BIN_DIR}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: wget ${BRS_CODE_GZ_URL} into ${BIN_DIR}"

if [ "${IP_PREFIX}" == "192" ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: copying ${tmpDownldDir}/${BRS_CODE_GZ_URL} into ${BIN_DIR}"
   cp -f ${tmpDownldDir}/${BRS_CODE_GZ_FILE} . 2> ${LOG_FILE}
   if [ $? -ne 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* cp ${tmpDownldDir}/${BRS_CODE_GZ_FILE} ${BIN_DIR} FAILED--Likely write permission related or due to bad ${tmpDownldDir} path!"
      cat ${LOG_FILE} | mail -s "*ALERT* cp ${tmpDownldDir}/${BRS_CODE_GZ_FILE} ${BIN_DIR} FAILED!" ${EMAIL_LIST}
      exit 1
   fi
else
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: wget ${BRS_CODE_GZ_URL} into ${BIN_DIR}"

   # Download the BRS_latestCode.tar.gz file
   wget ${BRS_CODE_GZ_URL} 2> ${LOG_FILE}
   if [ $? -ne 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${BRS_CODE_GZ_URL} FAILED--Likely connection/permission related or due to bad ${BRS_CODE_GZ_URL} path!"
      cat ${LOG_FILE} | mail -s "*ALERT* wget ${BRS_CODE_GZ_URL} FAILED!" ${EMAIL_LIST}
      exit 1
   fi
fi

cat ${LOG_FILE}
rm ${LOG_FILE}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: tar -zxvf ${BRS_CODE_GZ_FILE}"

# Untar the BRS_latestCode.tar.gz file
tar -zxvf ${BRS_CODE_GZ_FILE} 2>> ${LOG_FILE}
if [ $? -ne 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* tar -zxvf ${BRS_CODE_GZ_FILE} FAILED--Likely due to out-of-disk-space or other bizzare problems!"
   cat ${LOG_FILE} | mail -s "*ALERT* wget ${BRS_CODE_GZ_FILE} FAILED!" ${EMAIL_LIST}
   exit 1
fi
cat ${LOG_FILE}
rm ${LOG_FILE}

rm -f ${BRS_CODE_GZ_FILE}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: cp -rf ${SCRIPT_DIR}/BRS/conf ${HOME_DIR}/BRS"

# Update the conf files under relevant home dire4ctory
mkdir -p ${HOME_DIR}/BRS/conf
cp -rf ${SCRIPT_DIR}/BRS/conf/* ${HOME_DIR}/BRS/conf/ 2>> ${LOG_FILE}
if [ $? -ne 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* cp -rf ${SCRIPT_DIR}/BRS/conf ${HOME_DIR}/BRS FAILED--Likely due to out-of-disk-space or other bizzare problems!"
   cat ${LOG_FILE} | mail -s "*ALERT* cp -rf ${SCRIPT_DIR}/BRS/conf ${HOME_DIR}/BRS FAILED!" ${EMAIL_LIST}
   exit 1
fi
cat ${LOG_FILE}
rm ${LOG_FILE}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: mv BRS-CD/${INIT_PROC_SCRIPT} ${BIN_DIR}"

# Move up processInstanceServProcess.sh to ~/bin
mv BRS-CD/${INIT_PROC_SCRIPT} ${BIN_DIR} 2>> ${LOG_FILE}
if [ $? -ne 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* mv BRS-CD/${INIT_PROC_SCRIPT} ${BIN_DIR} FAILED--Likely due to out-of-disk-space or other bizzare problems!"
   cat ${LOG_FILE} | mail -s "*ALERT* mv BRS-CD/${INIT_PROC_SCRIPT} ${BIN_DIR} FAILED!" ${EMAIL_LIST}
   exit 1
fi
cat ${LOG_FILE}
rm ${LOG_FILE}

# Move up db_backup.sh to ~/bin
mv BRS-CD/${DB_BK_SCRIPT} ${BIN_DIR} 2>> ${LOG_FILE}
if [ $? -ne 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* mv BRS-CD/${DB_BK_SCRIPT} ${BIN_DIR} FAILED--Likely due to out-of-disk-space or other bizzare problems!"
   cat ${LOG_FILE} | mail -s "*ALERT* mv BRS-CD/${DB_BK_SCRIPT} ${BIN_DIR} FAILED!" ${EMAIL_LIST}
   exit 1
fi
cat ${LOG_FILE}
rm ${LOG_FILE}

echo ""
echo "Update with the latest BRS src code is COMPLETED."

