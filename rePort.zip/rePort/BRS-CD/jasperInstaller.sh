#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <INST_TYPE> <CURR_JASPER_VER> <NEW_JASPER_VER> <URIS> <DB_SOURCE> <SLAVE_DB_VALS> <APP_USR> <JASPER_INST_KIT_DIR>"
   echo ""
   echo "   where"
   echo ""
   echo "              <INST_TYPE> : Type of installation (either UPGRADE or NEW)."
   echo ""
   echo "        <CURR_JASPER_VER> : Version of the Jasper currently running on the server."
   echo ""
   echo "         <NEW_JASPER_VER> : Version of the new Jasper you are installing or upgrading to."
   echo ""
   echo "                   <URIS> : Comma separated list of Jasper folder URI path(s) that you"
   echo "                            would like to export."
   echo ""
   echo "              <DB_SOURCE> : The source of the application DB (either prod or non-prod)."
   echo "                            This is needed to determine whether to run syncTraksmart4RptTables.sh"
   echo "                            before or after importing Jasper reports/roles"
   echo ""
   echo "          <SLAVE_DB_VALS> : Specify NIL if this is for a NON-PRODUCTION server."
   echo "                            Otherwise, specify the slave DB values in this comma-separated format:"
   echo "                               db.type,db.host,db.port,db.name,db.usr,db.passwd,db.jdbcClass"
   echo ""
   echo "                <APP_USR> : The app. user account needed for sudo executing Jasper installation"
   echo "                            script on the Jasper server and retrieving app. properties"
   echo ""
   echo "    <JASPER_INST_KIT_DIR> : The directory where the Japser installation kit is located."
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 new 4.2 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports prod mysql,10.32.48.69,3306,cgv_prod_slave,cgv_prod_slave,cgv_prod_slave,com.mysql.jdbc.Driver traksmart /tmp/Jasper5.6_new_install_kit"
   echo ""
   echo "  $0 new 4.5.1 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports,/public non-prod NIL traksmart /tmp/Jasper5.6_new_upgrade_kit"
   echo ""
   exit
}

#
# Retrieve the desired property by parsing /etc/default/jetty & /etc/init.d/jetty files with the given key
#
function getPropertyFromWebConfigFile
{
   local app_usr= key= line= prop=
   app_usr="$1"
   key="$2"

   #
   # Parse the /etc/default/jetty & /etc/init.d/jetty files with the given key
   #
   line=`find /etc/default/jetty /etc/init.d/jetty | xargs grep -i "$key"| grep -v "#"`
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* find /etc/default/jetty /etc/init.d/jetty | xargs grep -i "$key"| grep -v "#" FAILED!"
      echo "Perhaps /etc/default/jetty & /etc/init.d/jetty are missing..." | /bin/mail -s "*ERROR* Failed to parse /etc/default/jetty & /etc/init.d/jetty!" ${EMAIL_LIST}
   fi

   prop=`echo $line | cut -d' ' -f1 | cut -d'=' -f2`

   echo "$prop"
}

#
# Retrieve application property values needed for updating various config files
#
function getAppPropVals
{
   local app_usr= key= line=
   app_usr="$1"
   key="$2"

   #
   # Obtain the application.properties file location by parsing /etc/default/jetty & /etc/init.d/jetty
   #
   line=`getPropertyFromWebConfigFile $app_usr $key`
   app_prop_dir=${line//\$\{JETTY_USER\}/$app_usr}
   app_prop_file="${app_prop_dir}/application.properties"
   if [ ! -s ${app_prop_file} ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${app_prop_file} is either missing or is an empty file!"
      echo "Please check if there's any typo in /etc/default/jetty or /etc/init.d/jetty." | /bin/mail -s "*ERROR* ${app_prop_file} is either missing or is an empty file!" ${EMAIL_LIST}
   fi

   #
   # Retrieve DB property values from the application.properties file
   #
   db_type=`grep db.type $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_name=`grep db.name $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_host=`grep db.host $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_port=`grep db.port $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_usr=`grep db.usr $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_passwd=`grep db.passwd $app_prop_file | grep -v "#" | cut -d'=' -f2`
   db_jdbcClass=`grep db.jdbcClass $app_prop_file | grep -v "#" | cut -d'=' -f2`

   #
   # Retrieve host name value from the application.properties file
   #
   host_name=`grep host.name $app_prop_file | grep -v "#" | cut -d'=' -f2`
}


if [ $# -ne 8 ]; then
   Usage
fi


#
# Arguments given
#
INST_TYPE=$1
CURR_JASPER_VER=$2
NEW_JASPER_VER=$3
URIS="$4"
DB_SOURCE=$5
SLAVE_DB_VALS=$6
APP_USR=$7
JASPER_INST_KIT_DIR=$8

JASPER_INST_ROOT="/opt"
JASPER_INST_LINK="${JASPER_INST_ROOT}/jasper"
CURR_JASPER_INST_NAME="jasperreports-server-${CURR_JASPER_VER}"
CURR_JASPER_INST_DIR="${JASPER_INST_ROOT}/${CURR_JASPER_INST_NAME}"
NEW_JASPER_INST_NAME="jasperreports-server-${NEW_JASPER_VER}"
NEW_JASPER_INST_DIR="${JASPER_INST_ROOT}/${NEW_JASPER_INST_NAME}"
BUILDOMATIC_DIR="${JASPER_INST_LINK}/buildomatic"
JASPER_INST_KIT_FILE="jasperreports-server-${NEW_JASPER_VER}-clean-reporting.tar.gz"
JASPER_INST_KIT="${JASPER_INST_KIT_DIR}/${JASPER_INST_KIT_FILE}"

JASPER_EXP_SCRIPT="js-export.sh"
JASPER_IMP_SCRIPT="js-import.sh"
JASPER_CTL_SCRIPT="${JASPER_INST_LINK}/ctlscript.sh"
SYNC_APP_RPT_TBLS_SCRIPT="${JASPER_INST_LINK}/syncTraksmart4RptTables.sh"
REPORTS_EXP_OUTPUT_ZIP="${NEW_JASPER_INST_DIR}/buildomatic/js-reports-export.zip"
ROLES_EXP_OUTPUT_ZIP="${NEW_JASPER_INST_DIR}/buildomatic/js-roles-export.zip"
JS_INST_LOG="/tmp/js_inst.log"
JS_EXP_LOG="/tmp/js_exp.log"
JS_IMP_LOG="/tmp/js_imp.log"
JS_CTL_LOG="/tmp/js_ctl.log"
JS_SYNC_TBLS_LOG="/tmp/js_ctl.log"
JS_CHG_CONFIG_LOG="/tmp/js_chg_config.log"

JS_TOMCAT_WEBINF_DIR="${JASPER_INST_LINK}/apache-tomcat/webapps/reporting/WEB-INF"
TBL_SYNC_PROP_FILE="${JS_TOMCAT_WEBINF_DIR}/classes/tableSyncronizer.properties"
APP_CXT_FILE="${JS_TOMCAT_WEBINF_DIR}/applicationContext-traksmart-ds.xml"
JS_CONFIG_PRPO_FILE="${JS_TOMCAT_WEBINF_DIR}/js.config.properties"
JS_QUARTZ_PRPO_FILE="${JS_TOMCAT_WEBINF_DIR}/js.quartz.properties"

EMAIL_LIST="mailto:mchu@nexant.com"

aprop="runtime_env"
rt_env=`getPropertyFromWebConfigFile $APP_USR $aprop`

#
# Preemptively verifying that slave DB values are provided for production server
#
if [ "${rt_env}" == "prod" ] && [ "${SLAVE_DB_VALS}" == "NIL" ]; then
   msg="*ERROR* You must specify slave DB values for production server! Please specify them in this (comma-separated) format: db.type,db.host,db.port,db.name,db.usr,db.passwd,db.jdbcClass, and try again."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
   echo ${msg} | /bin/mail -s "*ERROR* Slave DB values were not given for this production server Jasper ${INST_TYPE} installation!" ${EMAIL_LIST}
   exit 1
fi

#
# Verify the /opt/jasper symbolic link
#
if [ "${INST_TYPE}" == "upgrade" ]; then
   msg="Upgrading Jasper from version ${CURR_JASPER_VER} to version ${NEW_JASPER_VER} on $HOSTNAME in a moment"
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: ${msg}"
   echo "" | /bin/mail -s "*HEADS-UP* ${msg} <eom>" ${EMAIL_LIST}

   if [ ! -e ${CURR_JASPER_INST_DIR} ]; then
      msg="*ERROR* The specified current Jasper version, '${CURR_JASPER_INST_DIR}', does not exist! Please double check and provide a correct current Jasper version."
      echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
      echo ${msg} | /bin/mail -s "*ERROR* The specified current Jasper version does not exist!" ${EMAIL_LIST}
      exit 1
   fi

   if [ ! -e ${JASPER_INST_LINK} ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: The /opt/jasper symbolic link does not exist. Creating it..."
      cd $JASPER_INST_ROOT
      ln -s ${CURR_JASPER_INST_DIR} jasper
   elif [ ! -h ${JASPER_INST_LINK} ]; then
      msg="*ERROR* '${JASPER_INST_LINK}' is not a symbolic link as expected! Please change it to a symbolic link accordingly and try again."
      echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
      echo ${msg} | /bin/mail -s "*ERROR* ${JASPER_INST_LINK} is not a symbolic link!" ${EMAIL_LIST}
      exit 1
   else
      str=$(ls -l ${JASPER_INST_LINK} | awk '{print $11}')
      CURR_INST_VER=$(echo $str | cut -d'-' -f3)
      if [ "${CURR_JASPER_VER}" != "${CURR_INST_VER}" ]; then
         msg="*ERROR* The specified current Jasper version, '${CURR_JASPER_VER}', does not match the one actually installed (i.e. '${CURR_INST_VER}') on the system (which the /opt/jasper symbolic link is currently pointing to)! Please double check."
         echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
         echo ${msg} | /bin/mail -s "*ERROR* The specified current Jasper version mismatches with the actual installed one!" ${EMAIL_LIST}
         exit 1
      fi
   fi
else
   msg="Installing (new) Jasper version ${NEW_JASPER_VER} on $HOSTNAME in a moment"
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: ${msg}"
   echo "" | /bin/mail -s "*HEADS-UP* ${msg} <eom>" ${EMAIL_LIST}

   if [ -e ${JASPER_INST_LINK} ]; then
      if [ -h ${JASPER_INST_LINK} ]; then
         msg="*ERROR* The '${JASPER_INST_LINK}' symbolic link is found to be existing (i.e. Jasper already pre-installed) on the server while you request a brand new Jasper installation--Should you do a Jasper UPGRADE installation instead? Please remove '${JASPER_INST_LINK}' if you intend to have a brand new Jasper installation, and try again. Otherwise, please try again by specifying an 'upgrade' INSTALL_TYPE instead."
         subject="*ERROR* The '${JASPER_INST_LINK}' symbolic link is found to be existing/pre-installed!"
      else
         msg="*ERROR* '${JASPER_INST_LINK}' is found to be existing and is not a symbolic link (i.e. Jasper already pre-installed) on the server while you request a brand new Jasper installation! Please remove '${JASPER_INST_LINK}' if you intend to have a brand new Jasper installation, and try again. Otherwise, please change it to a symbolic link accordingly, and try again by specifying an 'upgrade' INSTALL_TYPE instead."
         subject="*ERROR* ${JASPER_INST_LINK} is found to be existing/pre-installed and is not a symbolic link!"
      fi
      echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
      echo ${msg} | /bin/mail -s "${subject}" ${EMAIL_LIST}
      exit 1
   fi
fi

#
# Copy the Jasper installation kit to the Japser installation root directory
# and untar/install the new Jasper package
#
if [ ! -e ${JASPER_INST_KIT} ]; then
   msg="*ERROR* The Jasper installation kit, ${JASPER_INST_KIT}, does not exist! This is likely due to the NEW_JASPER_VER, '${NEW_JASPER_VER}', that you specified in the argument does not match that of the Jasper installation kit. Please find out the correct version of the Jasper installation kit under the '${JASPER_INST_KIT_DIR}' directory and try again."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
   echo ${msg} | /bin/mail -s "*ERROR* The Jasper installation kit, ${JASPER_INST_KIT_FILE}, does not exist!" ${EMAIL_LIST}
   exit 1
fi

cd $JASPER_INST_ROOT
cp ${JASPER_INST_KIT} .
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Untaring ${JASPER_INST_KIT_FILE}"
echo ""
tar -zxf ${JASPER_INST_KIT_FILE} 2> ${JS_INST_LOG}
if [ $? != 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* tar -zxvf ${JASPER_INST_KIT_FILE} FAILED! Please check ${JS_INST_LOG}."
   cat ${JS_INST_LOG} | /bin/mail -s "*ERROR* Japser installation FAILED!" ${EMAIL_LIST}
   exit 1
fi

#echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Cleaning up ${JASPER_INST_KIT_FILE}"
#rm -f ${JASPER_INST_KIT_FILE}

#
# Ensure that the right new Jasper version is actually installed
#
if [ ! -e ${NEW_JASPER_INST_NAME} ]; then
   msg="*ERROR* The '${NEW_JASPER_INST_DIR}' directory does not exist! Please double check that '${JASPER_INST_KIT_FILE}' is actually an installation kit for Japser version '${NEW_JASPER_VER}' (as you specified) or you have specified a wrong new Jasper version argument?"
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${msg}"
   echo ${msg} | /bin/mail -s "*ERROR* '${NEW_JASPER_INST_NAME}' was not actually installed as expected!" ${EMAIL_LIST}
   exit 1
fi

#
# If this is for an Jasper upgrade, then exports Jasper reports & roles
#
if [ "${INST_TYPE}" == "upgrade" ]; then
   cd $BUILDOMATIC_DIR

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Exporting Japser reports: ${URIS}"
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
   ./$JASPER_EXP_SCRIPT --uris "${URIS}" --output-zip ${REPORTS_EXP_OUTPUT_ZIP} 2> ${JS_EXP_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ./JASPER_EXP_SCRIPT --uris ${URIS} --output-zip ${REPORTS_EXP_OUTPUT_ZIP} FAILED! Please check ${JS_EXP_LOG}."
      cat ${JS_EXP_LOG} | /bin/mail -s "*ERROR* Failed to export Japser reports!" ${EMAIL_LIST}
      exit 1
   fi
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"

   echo ""

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Exporting Japser roles"
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
   ./$JASPER_EXP_SCRIPT --roles --output-zip ${ROLES_EXP_OUTPUT_ZIP} 2> ${JS_EXP_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ./$JASPER_EXP_SCRIPT --roles --output-zip ${ROLES_EXP_OUTPUT_ZIP} FAILED! Please check ${JS_EXP_LOG}."
      cat ${JS_EXP_LOG} | /bin/mail -s "*ERROR* Failed to export Jasper roles!" ${EMAIL_LIST}
      exit 1
   fi
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
   echo ""

   #
   # Shutdown the current (now old) Jasper instance as it's no longer needed
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Stopping the current (now old) Jasper instance"
   ${JASPER_CTL_SCRIPT} stop 2> ${JS_CTL_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${JASPER_CTL_SCRIPT} stop FAILED! Please check ${JS_CTL_LOG}."
      cat ${JS_CTL_LOG} | /bin/mail -s "*ERROR* FAILED to stop the current/old version Japser!" ${EMAIL_LIST}
      exit 1
   fi
fi

#
# Now update the /opt/jasper symbolic link pointing to the new Jasper
#
cd $JASPER_INST_ROOT
if [ -h jasper ]; then
   rm jasper
fi
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Updating the /opt/jasper symbolic link pointing to ${NEW_JASPER_INST_DIR}"
ln -s ${NEW_JASPER_INST_DIR} jasper

aprop="nexant_app_home"
getAppPropVals $APP_USR $aprop

#
# Get the application property values
#
if [ "$rt_env" == "prod" ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: This is for upgrading a production server"
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: slave DB values: ${SLAVE_DB_VALS}"

   # For production server, slave DB values are provided through the SLAVE_DB_VALS command-line argument instead
   # as they are storing in a file on a server that OPS has not provided the access
   errStr=""
   db_type=`echo ${SLAVE_DB_VALS} | cut -d',' -f1`
   if [ -z "$db_type" ]; then
      errStr="${errStr}db_type"
   fi

   db_host=`echo ${SLAVE_DB_VALS} | cut -d',' -f2`
   if [ -z "$db_host" ]; then
      errStr="${errStr} db_host"
   fi

   db_port=`echo ${SLAVE_DB_VALS} | cut -d',' -f3`
   if [ -z "$db_port" ]; then
      errStr="${errStr} db_port"
   fi

   db_name=`echo ${SLAVE_DB_VALS} | cut -d',' -f4`
   if [ -z "$db_name" ]; then
      errStr="${errStr} db_name"
   fi

   db_usr=`echo ${SLAVE_DB_VALS} | cut -d',' -f5`
   if [ -z "$db_usr" ]; then
      errStr="${errStr} db_usr"
   fi

   db_passwd=`echo ${SLAVE_DB_VALS} | cut -d',' -f6`
   if [ -z "$db_passwd" ]; then
      errStr="${errStr} db_passwd"
   fi

   db_jdbcClass=`echo ${SLAVE_DB_VALS} | cut -d',' -f7`
   if [ -z "$db_jdbcClass" ]; then
      errStr="${errStr} db_jdbcClass"
   fi

   if [ "$errStr" ]; then
      msg="The following slave DB value(s) is/are empty: ${errStr}. Please make sure proper slave DB value(s) is/are specified and try again."
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${msg}"
      echo ${msg} | /bin/mail -s "*ERROR* Missing slave DB value(s)!" ${EMAIL_LIST}
      exit 1
   fi
fi

#
# Update tableSyncronizer.properties with the appropiate DB values
#
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Updating ${TBL_SYNC_PROP_FILE} with the appropiate DB values"
sed -i 's/db.url=.*\//'"db.url=jdbc:mysql:\/\/${db_host}:${db_port}\/"'/;s/db.name=.*/'"db.name=${db_name}"'/;s/db.driver=.*/'"db.driver=${db_jdbcClass}"'/;s/db.user=.*/'"db.user=${db_usr}"'/;s/db.password=.*/'"db.password=${db_passwd}"'/;s/db.Type=.*/'"db.Type=${db_type}"'/;' ${TBL_SYNC_PROP_FILE} 2> ${JS_CHG_CONFIG_LOG}
if [ $? != 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to update tableSyncronizer.properties with the appropiate DB values! Please check ${JS_CHG_CONFIG_LOG}."
   cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to update tableSyncronizer.properties with the appropiate DB values!" ${EMAIL_LIST}
   exit 1
fi

#
# Update applicationContext-traksmart-ds.xml with the appropiate DB values
#
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Updating ${APP_CXT_FILE} with the appropiate DB values"
sed -i 's/name=\"driverClass\" value=.*\/>/'"name=\"driverClass\" value=\"${db_jdbcClass}\" \/>"'/;s/jdbc:mysql.*\?autoReconnect=true/'"jdbc:mysql\:\/\/${db_host}:${db_port}\/${db_name}\?autoReconnect=true"'/;s/name=\"user\" value=.*\/>/'"name=\"user\" value=\"${db_usr}\" \/>"'/;s/name=\"password\" value=.*\/>/'"name=\"password\" value=\"${db_passwd}\" \/>"'/;' ${APP_CXT_FILE} 2> ${JS_CHG_CONFIG_LOG}
if [ $? != 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to update applicationContext-traksmart-ds.xml with the appropiate DB values! Please check ${JS_CHG_CONFIG_LOG}."
   cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to update applicationContext-traksmart-ds.xml with the appropiate DB values!" ${EMAIL_LIST}
   exit 1
fi

#
# If this is for staging/prod environments, we need to change 2 more property files,
# js.config.properties & js.quartz.properties, as our staging and prod environments use proxy
#
if [ "$rt_env" == "staging" ] || [ "$rt_env" == "prod" ]; then
   #
   # Update js.config.properties with the appropiate hostname
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Updating ${JS_CONFIG_PRPO_FILE} with the appropiate hostname"
   sed -i 's/deploy.base.url=.*/'"deploy.base.url=https:\/\/${host_name}\/reporting"'/g' ${JS_CONFIG_PRPO_FILE} 2> ${JS_CHG_CONFIG_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to update js.config.properties with the appropiate hostname! Please check ${JS_CHG_CONFIG_LOG}."
      cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to update js.config.properties with the appropiate DB values!" ${EMAIL_LIST}
      exit 1
   fi

   #
   # Update js.quartz.properties with the appropiate hostname
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Updating ${JS_QUARTZ_PRPO_FILE} with the appropiate hostname"
   sed -i 's/report.scheduler.web.deployment.uri=.*/'"report.scheduler.web.deployment.uri=https:\/\/${host_name}\/reporting"'/g' ${JS_QUARTZ_PRPO_FILE} 2> ${JS_CHG_CONFIG_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to update js.quartz.properties with the appropiate hostname! Please check ${JS_CHG_CONFIG_LOG}."
      cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to update js.quartz.properties with the appropiate DB values!" ${EMAIL_LIST}
      exit 1
   fi
else
 # *** FOR QA instances ***
   #
   # Remove the URL value from the deploy.base.url= line in js.config.properties.
   # i.e. change "deploy.base.url=https://staging.traksmart.com/reporting" to "deploy.base.url="
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Removing the URL value from the deploy.base.url= line in ${JS_CONFIG_PRPO_FILE}"
   sed -i 's/deploy.base.url=.*/'"deploy.base.url="'/g' ${JS_CONFIG_PRPO_FILE} 2> ${JS_CHG_CONFIG_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to remove the URL value from the deploy.base.url= line in ${JS_CONFIG_PRPO_FILE}! Please check ${JS_CHG_CONFIG_LOG}."
      cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to remove the URL value from the deploy.base.url= line in ${JS_CONFIG_PRPO_FILE}!" ${EMAIL_LIST}
      exit 1
   fi

   #
   # Remove the URL value from the report.scheduler.web.deployment.uri= line in js.quartz.properties.
   # i.e. change "report.scheduler.web.deployment.uri=https://staging.traksmart.com/reporting" to "report.scheduler.web.deployment.uri="
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Removing the URL value from the report.scheduler.web.deployment.uri= line in ${JS_QUARTZ_PRPO_FILE}"
   sed -i 's/report.scheduler.web.deployment.uri=.*/'"report.scheduler.web.deployment.uri="'/g' ${JS_QUARTZ_PRPO_FILE} 2> ${JS_CHG_CONFIG_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Failed to remove the URL value from the report.scheduler.web.deployment.uri= line in ${JS_QUARTZ_PRPO_FILE}! Please check ${JS_CHG_CONFIG_LOG}."
      cat ${JS_CHG_CONFIG_LOG} | /bin/mail -s "*ERROR* Failed to  remove the URL value from the report.scheduler.web.deployment.uri= line in ${JS_QUARTZ_PRPO_FILE}!" ${EMAIL_LIST}
      exit 1
   fi
fi

#
# Start up the new Jasper
#
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Starting the new Japser (tomcat & postgresql processes)"
${JASPER_CTL_SCRIPT} start 2> ${JS_CTL_LOG}
if [ $? != 0 ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${JASPER_CTL_SCRIPT} start FAILED! Please check ${JS_CTL_LOG}."
   cat ${JS_CTL_LOG} | /bin/mail -s "*ERROR* FAILED to start the new Japser!" ${EMAIL_LIST}
   exit 1
fi

#
# Per Oksana, if the app. DB was coming from a production server,
# the sync report tables script must be run before importing reports/roles
#
if [ "${DB_SOURCE}" == "prod" ]; then
   #
   # Run the sync report tables script
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Executing ${SYNC_APP_RPT_TBLS_SCRIPT} before importing Jasper reports/roles."
   ${SYNC_APP_RPT_TBLS_SCRIPT} 2> ${JS_SYNC_TBLS_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Executing ${SYNC_APP_RPT_TBLS_SCRIPT} FAILED! Please check ${JS_SYNC_TBLS_LOG}."
      cat ${JS_SYNC_TBLS_LOG} | /bin/mail -s "*ERROR* FAILED to execute ${SYNC_APP_RPT_TBLS_SCRIPT}!" ${EMAIL_LIST}
      exit 1
   fi
fi

#
# Now import reports/roles (for upgrade installation only)
#
if [ "${INST_TYPE}" == "upgrade" ]; then

   #
   # Import Jasper reports & roles
   #
   cd $BUILDOMATIC_DIR

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Importing Jasper reports"
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
   ./$JASPER_IMP_SCRIPT --input-zip ${REPORTS_EXP_OUTPUT_ZIP} 2> ${JS_IMP_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ./$JASPER_IMP_SCRIPT --input-zip ${REPORTS_EXP_OUTPUT_ZIP} FAILED! Please check ${JS_IMP_LOG}."
      cat ${JS_IMP_LOG} | /bin/mail -s "*ERROR* Failed to import Jasper reports!" ${EMAIL_LIST}
      exit 1
   fi
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"

   echo ""

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Importing Jasper roles"
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
   ./$JASPER_IMP_SCRIPT --input-zip ${ROLES_EXP_OUTPUT_ZIP} 2> ${JS_IMP_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ./$JASPER_IMP_SCRIPT --input-zip ${ROLES_EXP_OUTPUT_ZIP} FAILED! Please check ${JS_IMP_LOG}."
      cat ${JS_IMP_LOG} | /bin/mail -s "*ERROR* Failed to import Japser roles!" ${EMAIL_LIST}
      exit 1
   fi
   echo "-------------------------------------------------------------------------------------------------------------------------------------------------"
fi

#
# Per Oksana, if the app. DB was coming from a non production server,
# the sync report tables script should be run after importing reports/roles
#
if [ "${DB_SOURCE}" == "non-prod" ]; then

   #
   # Run the sync report tables script
   #
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Executing ${SYNC_APP_RPT_TBLS_SCRIPT} after importing Jasper reports/roles."
   ${SYNC_APP_RPT_TBLS_SCRIPT} 2> ${JS_SYNC_TBLS_LOG}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Executing ${SYNC_APP_RPT_TBLS_SCRIPT} FAILED! Please check ${JS_SYNC_TBLS_LOG}."
      cat ${JS_SYNC_TBLS_LOG} | /bin/mail -s "*ERROR* FAILED to execute ${SYNC_APP_RPT_TBLS_SCRIPT}!" ${EMAIL_LIST}
      exit 1
   fi
fi
echo ""

#echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Current Jasper status after importing reports/roles"
#${JASPER_CTL_SCRIPT} status

#
# Give some leeway time
#
sleep 60

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Current Jasper status after importing reports/roles & sleeping 60 seconds"
${JASPER_CTL_SCRIPT} status

#
# Start up the new Jasper again (as for some unknown reason the Jasper tomcat process
# will be stopped after importing reports/roles)
#
#echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Re-starting the new Japser (tomcat & postgresql processes)"
#${JASPER_CTL_SCRIPT} start 2> ${JS_CTL_LOG}
#if [ $? != 0 ]; then
#   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* ${JASPER_CTL_SCRIPT} start FAILED! Please check ${JS_CTL_LOG}."
#   cat ${JS_CTL_LOG} | /bin/mail -s "*ERROR* FAILED to start the new Japser!" ${EMAIL_LIST}
#   exit 1
#fi

msg="*COMPLETED* Jasper version '${NEW_JASPER_VER}' ${INST_TYPE} installation successfully!"
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: ${msg}"
echo "" | /bin/mail -s "${msg} <eom>" ${EMAIL_LIST}

