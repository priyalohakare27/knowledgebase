#!/bin/sh

#
# Usage: /opt/ldap_backups/ldap_backups.sh [preinstall](or [postinstall])
#
# Example:
#   /* For doing the /usr/sbin/slapcat backup only */
#   /opt/ldap_backups/ldap_backups.sh
#
#   /* 
#    * For doing both the /usr/sbin/slapcat backup & full backup of the /var/lib/ldap directory
#    * before application/war-file installation. Note: This command should ONLY be used during 
#    * application deployment (and when LDAP was already shutdown beforehand).
#    */
#   /opt/ldap_backups/ldap_backups.sh preinstall
#
#   /*
#    * For doing both the /usr/sbin/slapcat backup & full backup of the /var/lib/ldap directory
#    * after application/war-file installation. Note: This command should ONLY be used during
#    * application deployment (and when LDAP was already shutdown beforehand).
#    */   
#   /opt/ldap_backups/ldap_backups.sh postinstall
#

LDAPBK=ldap-$( date +%y%m%d-%H%M ).ldif
BACKUPDIR=/opt/ldap_backups
/usr/sbin/slapcat  -b "dc=traksmart4,dc=nexant,dc=com" -l $BACKUPDIR/$LDAPBK
gzip -9 $BACKUPDIR/$LDAPBK

function backupLdapDBdir()
{
    local tag= bkdir=
    tag="$1"
    bkdir="$2"

    ldap_dbdir_root="/var/lib"
    ldap_dbdir="${ldap_dbdir_root}/ldap"
    full_bk_file="${bkdir}/var-lib-ldap-${tag}-bk.tar.gz"

    # Just double check that the backup directory does exist
    if [ ! -d ${bkdir} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* The backup directory, '${bkdir}', does not exist!"
       exit 1
    fi

    # Just double check that the LDAP DB directory does exist
    if [ ! -d ${ldap_dbdir} ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* The LDAP DB directory, '${ldap_dbdir}', does not exist!"
       exit 1
    fi

    echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Start backing up ${ldap_dbdir}"
    (cd ${ldap_dbdir_root}; tar -zcf ${full_bk_file} ldap)
    if [ $? != 0 ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* tar -zcf ${full_bk_file} ldap FAILED!"
       exit 1;
    else
       echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Completed backing up ${ldap_dbdir} (into ${full_bk_file})"
    fi
}

# If specified, backup the whole /var/lib/ldap directory
if [ $# -eq 1 ]; then
   backupLdapDBdir $1 ${BACKUPDIR}
fi
