#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <USR> <APP_SERV_IP> <JOB_NAME> <BUILD_NUM> <CUSTOMER> <TRIGGER_OTHER_BUILD> <MANUAL_STOP_APPINST> <MANUAL_START_APPINST> <MANUAL_STOP_LDAP> <MANUAL_START_LDAP> <MANUAL_STOP_INTALIO> <MANUAL_START_INTALIO> <MANUAL_STOP_JASPER> <MANUAL_START_JASPER> <MANUAL_SWITCHOFF_RTVSCAN> <MANUAL_SWITCHON_RTVSCAN> <DO_EMAIL_NOTIFIY> <EMAIL_TO> <EMAIL_CC> <DB_USR> <DB_PASSWD> <NEW_DOWNLOAD> <NEW_DOWNLOAD_CMS>"
   echo ""
   echo "   where"
   echo ""
   echo "                <USR> : The user account under which the QA instance is running"
   echo "                        (e.g. traksmart for Traksmart related applications)."
   echo ""
   echo "        <APP_SERV_IP> : The IP address of the targeted QA server (e.g. 172.20.19.178)"
   echo "                        for this deployment."
   echo ""
   echo "           <JOB_NAME> : The name of Jenkins job (e.g. TS-rel-4.4.1) that builds the"
   echo "                        artifact for this deployment."
   echo ""
   echo "          <BUILD_NUM> : The Jenkins build number (e.g. 1) of ARTIFACT_JOB_NAME associated"
   echo "                        with the artifact for this deployment."
   echo ""
   echo "           <CUSTOMER> : Specify whether this deployment should also include customizations"
   echo "                        for the given customer (e.g. PSEG) or NONE if none customizations"
   echo ""
   echo " <TRIGGER_OTHER_BUILD>: Specify the build job name (e.g. cms) to be triggered. This option is"
   echo "                        ONLY used when we also need to trigger another build during a"
   echo "                        deployment (Currently, This is for deploying a CMS build along"
   echo "                        with a Tradeally deployment. Default value is NONE"
   echo "                        (i.e. Do not trigger another build)"
   echo ""
   echo " <MANUAL_STOP_APPINST>: Specify whether to manually stop the application instance"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 0/FALSE (i.e. stopping the"
   echo "                        application instance automatically)"
   echo ""
   echo "<MANUAL_START_APPINST>: Specify whether to manually start the application instance"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 0/FALSE (i.e. starting the"
   echo "                        application instance automatically)"
   echo ""
   echo "    <MANUAL_STOP_LDAP>: Specify whether to manually stop LDAP"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. stopping LDAP manually)"
   echo ""
   echo "   <MANUAL_START_LDAP>: Specify whether to manually start LDAP"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. starting LDAP manually)"
   echo ""
   echo " <MANUAL_STOP_INTALIO>: Specify whether to manually stop Intalio"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. stopping Intalio manually)"
   echo ""
   echo "<MANUAL_START_INTALIO>: Specify whether to manually start Intalio"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. starting Intalio manually)"
   echo ""
   echo "  <MANUAL_STOP_JASPER>: Specify whether to manually stop Jasper"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. stopping Jasper manually)"
   echo ""
   echo " <MANUAL_START_JASPER>: Specify whether to manually start Jasper"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. starting Jasper manually)"
   echo ""
   echo "  <MANUAL_SWITCHOFF_RTVSCAN>: Specify whether to manually switch off rtvscan"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. switching off rtvscan manually)"
   echo ""
   echo "  <MANUAL_SWITCHON_RTVSCAN>: Specify whether to manually switch on rtvscan"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 1/TRUE (i.e. switching on rtvscan manually)"
   echo ""
   echo "    <DO_EMAIL_NOTIFIY>: Specify whether to send relevant (HEAD-UP/COMPLETION) email"
   echo "                        notification (1=>TRUE; 0=>FALSE). Default is 1/TRUE"
   echo "                        (i.e. to always send email notification)"
   echo ""
   echo "            <EMAIL_TO>: Specify the email To lits for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo ""
   echo "            <EMAIL_CC>: Specify the email CC lits for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo "" 
   echo "            <DB_USR>:   Specify the DB user for specific for DB backup"
   echo "" 
   echo "           <DB_PASSWD>: Specify the DB password for specific for DB backup"
   echo ""
   echo "        <ERR_EMAIL_TO>: Specify the email To lits for sending deployment errors/problems"
   echo "                        email notification"
   echo ""
   echo "        <ERR_EMAIL_CC>: Specify the email CC lits for sending deployment errors/problems"
   echo "                        email notification"
   echo ""
   echo "        <NEW_DOWNLOAD>: Specify whether to download (&, for SAC servers, scp) artifact/war-file."
   echo "                        By default, always download/scp artifact/war-file. The only time that"
   echo "                        you don't is when the same artifact/war-file already in-placed (e.g."
   echo "                        When a deployment attempt failed due to other cause after the same"
   echo "                        artifact/war-file was already downloaded/scp'ed to the app. server)."
   echo ""
   echo "    <NEW_DOWNLOAD_CMS>: Specify whether to download (&, for SAC servers, scp) CMS war-file."
   echo "                        The default is NOT to download/scp CMS artifact/war-file because CMS"
   echo "                        seldom get updated."
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 traksmart 172.20.19.136 TS-rel-5.1.2 10 PSEG NONE 0 0 1 1 1 1 1 1 1 QATeam@nexant.com traksmartdevteam@nexant.com mchu@nexant.com mchu@nexant.com NO NO"
   echo ""
   echo "  $0 traksmart 172.20.19.233 TS-rel-5.1.2 10 CGV NONE 0 0 1 1 1 1 1 1 1 QATeam@nexant.com traksmartdevteam@nexant.com mchu@nexant.com mchu@nexant.com NO NO"
   echo ""
   echo "  $0 traksmart 192.168.55.149 TS-rel-5.2.0 641 NONE 0 0 1 1 1 1 1 1 1 QATeam@nexant.com traksmartdevteam@nexant.com mchu@nexant.com techopsgroup@nexant.com YES NO"
   echo ""
   exit
}

if [ $# -ne 25 ]; then
   Usage
fi

#################
# Arguments given 
#################
USR=$1
APP_SERV_IP_STR=$2
JOB_NAME=$3
BUILD_NUM=$4
CUSTOMER=$5
TRIGGER_OTHER_BUILD=$6
MANUAL_STOP_APPINST=$7
MANUAL_START_APPINST=$8
MANUAL_STOP_LDAP=$9
MANUAL_START_LDAP=${10}
MANUAL_STOP_INTALIO=${11}
MANUAL_START_INTALIO=${12}
MANUAL_STOP_JASPER=${13}
MANUAL_START_JASPER=${14}
MANUAL_SWITCHOFF_RTVSCAN=${15}
MANUAL_SWITCHON_RTVSCAN=${16}
DO_EMAIL_NOTIFIY=${17}
EMAIL_TO=${18}
EMAIL_CC=${19}
ERR_EMAIL_TO=${20}
ERR_EMAIL_CC=${21}
DB_USR=${22}
DB_PASSWD=${23}
NEW_DOWNLOAD=${24}
NEW_DOWNLOAD_CMS=${25}

# Remove the description string of the application server IP argument
APP_SERV_IP=`echo ${APP_SERV_IP_STR} | cut -d '=' -f2`

# Make sure the application server IP is valid beforehand...
IP_PREFIX=`echo ${APP_SERV_IP} | cut -d '.' -f1`

# According to TECHOPS, Nexant will only use either IP prefix '172' or '192'
if [ "${IP_PREFIX}" != "172" ] && [ "${IP_PREFIX}" != "192" ]; then
   errMsg="*ERROR* The IP prefix, '${IP_PREFIX}', of the given application server IP, '${APP_SERV_IP}', is invalid -- It must be either '172' or '192'! Please verify."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${errMsg}"
   echo "${errMsg}" | /bin/mail -s "*ERROR* Invalid application server IP (prefix) is given!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
   exit 1
fi

echo "Checking 'ping -c 1 -W 5 ${APP_SERV_IP}' ..."
ping -c 1 -W 5 ${APP_SERV_IP}
if [ $? != 0 ]; then
   errMsg="*ERROR* The given application server IP, '${APP_SERV_IP}', is not ping'able/accessible! Please verify."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${errMsg}"
   echo "${errMsg}" | /bin/mail -s "*ERROR* Invalid/Inaccessible application server IP is given!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
   exit 1
fi

###########################
# Jenkins build server info
###########################
BLD_SERV_IP="http://172.20.19.61"
BLD_SERV_PORT="9090"

#########################################
# The deployment script that does the job 
#########################################
DEPLOY_SCRIPT="/home/${USR}/bin/BRS-CD/deploy.pl"

EMAIL_LIST="mailto:mchu@nexant.com"

#################################
# Default deployemnt command-line 
#################################
cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --manual_stop_ldap $MANUAL_STOP_LDAP --manual_start_ldap $MANUAL_START_LDAP --manual_stop_intalio $MANUAL_STOP_INTALIO --manual_start_intalio $MANUAL_START_INTALIO --manual_stop_jasper $MANUAL_STOP_JASPER --manual_start_jasper $MANUAL_START_JASPER --manual_switchoff_rtvscand $MANUAL_SWITCHOFF_RTVSCAN --manual_switchon_rtvscand $MANUAL_SWITCHON_RTVSCAN --do_email_notification $DO_EMAIL_NOTIFIY --email_to_list ${EMAIL_TO} --email_cc_list ${EMAIL_CC} --deployerr_mail_to ${DERR_EMAIL_TO} --deployerr_mail_cc ${ERR_EMAIL_CC}"

###################################################
# Get the artifact name based on the build job name
###################################################
PROJ_NAME=${JOB_NAME:0:2}
if [ "${PROJ_NAME}" == "TS" ]; then
   if [ "$USR" != "traksmart" ]; then
      echo "*ERROR* The given (Jenkins) build job, ${JOB_NAME}, does not match the given application user, '${USR}'! Please make sure that the specified build job & application user do match."  | /bin/mail -s "*ALERT* (Jenkins) Build job and application user mismatch!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
      exit 1
   fi
   ARTIFECT_NAME="traksmart4.war"
elif [ "${PROJ_NAME}" == "TA" ]; then
   if [ "$USR" != "tradeally" ]; then
      echo "*ERROR* The given (Jenkins) build job, ${JOB_NAME}, does not match the given application user, '${USR}'! Please make sure that the specified build job & application user do match."  | /bin/mail -s "*ALERT* (Jenkins) Build job and application user mismatch!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
      exit 1
   fi
   ARTIFECT_NAME="tradeally.war"
elif [ "${PROJ_NAME}" == "TR" ]; then
   if [ "$USR" != "trl" ]; then
      echo "*ERROR* The given (Jenkins) build job, ${JOB_NAME}, does not match the given application user, '${USR}'! Please make sure that the specified build job & application user do match."  | /bin/mail -s "*ALERT* (Jenkins) Build job and application user mismatch!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
      exit 1
   fi
   ARTIFECT_NAME="trl.war"
elif [ "${PROJ_NAME}" == "DR" ]; then
   if [ "$USR" != "dr360" ]; then
      echo "*ERROR* The given (Jenkins) build job, ${JOB_NAME}, does not match the given application user, '${USR}'! Please make sure that the specified build job & application user do match."  | /bin/mail -s "*ALERT* (Jenkins) Build job and application user mismatch!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
      exit 1
   fi
   ARTIFECT_NAME="dr360.war"
elif [ "${PROJ_NAME}" == "GR" ]; then
   if [ "$USR" != "dev_user" ]; then
      echo "*ERROR* The given (Jenkins) build job, ${JOB_NAME}, does not match the given application user, '${USR}'! Please make sure that the specified build job & application user do match."  | /bin/mail -s "*ALERT* (Jenkins) Build job and application user mismatch!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
      exit 1
   fi
   ARTIFECT_NAME="nexant-dm360.war"
#elif [ "${PROJ_NAME}" == "ES" ]; then
#   ARTIFECT_NAME="goldengate.war"
else
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Unknown job name, '$JOB_NAME', please verify and try again."
   exit 1 
fi

#######################################################################
# Check if the application server on which the artifact to be deploying
# is located in a different network domain (i.e. Its IP address starts
# with 192 or anything other than 172) of the build server/artifact
# repository. If so, we will need to scp the artifact to it as it is
# not possible to directly wget the artifact from either the build 
# server or artifact repository (which are locating in the 172 domain)
#######################################################################
if [ "${IP_PREFIX}" == "192" ]; then
   # Switch off rtvscan so that it won't slow down copying the
   # artifact/war-file to the remote server
   if [ "${MANUAL_SWITCHOFF_RTVSCAN}" == "0" ]; then
      switchoff_vscan="sudo /etc/init.d/rtvscand stop"
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} $switchoff_vscan"
      /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} $switchoff_vscan 
      MANUAL_SWITCHOFF_RTVSCAN=1
   fi
   tmpDownldDir="/tmp/${APP_SERV_IP}_${JOB_NAME}_${BUILD_NUM}"
   if [ "${NEW_DOWNLOAD}" == "YES" ]; then
      /bin/mkdir -p ${tmpDownldDir}
      cd ${tmpDownldDir}; 
      ARTIFECT_URL="${BLD_SERV_IP}:${BLD_SERV_PORT}/job/${JOB_NAME}/${BUILD_NUM}/artifact/target/$ARTIFECT_NAME"
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Downloading ${ARTIFECT_URL} to ${tmpDownldDir}"
      /usr/bin/wget ${ARTIFECT_URL} 2>> ./wget_errlog 
      if [ $? != 0 ]; then
         echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${ARTIFECT_URL} FAILED--Likely due to either bad build job name or bad build number was given or connection/permission related! Please double check the URL: ${ARTIFECT_URL}."
         echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${ARTIFECT_URL} FAILED--Likely due to bad build job name or bad build number was given or connection/permission related! Please double check the URL: ${ARTIFECT_URL}." >> ./console.log
         /bin/cat ./wget_errlog >> ./console.log
         /bin/cat ./console.log | /bin/mail -s "*ALERT* Problem downloading ${ARTIFECT_URL}--wget ${ARTIFECT_URL} FAILED!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
         cd ../;
         /bin/rm -rf ${tmpDownldDir} 
         exit 1
      fi

      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir}"
      /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir} 

      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}"
      /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}
      /bin/rm -rf ${tmpDownldDir} 
   fi

   if [ "${PROJ_NAME}" == "TA" ] && [ "${TRIGGER_OTHER_BUILD}" == "cms"]; then
      if [ "${NEW_DOWNLOAD_CMS}" == "YES" ]; then
         /bin/mkdir -p ${tmpDownldDir}
         cd ${tmpDownldDir}
         CMS_ARTIFECT_NAME="cms.war"
         CMS_ARTIFECT_URL="${BLD_SERV_IP}:${BLD_SERV_PORT}/job/cms/lastSuccessfulBuild/artifact/target/$CMS_ARTIFECT_NAME"
         echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Downloading ${CMS_ARTIFECT_URL} to ${tmpDownldDir}"
         /usr/bin/wget ${CMS_ARTIFECT_URL} 2>> ./wget_errlog
         if [ $? != 0 ]; then
            echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${CMS_ARTIFECT_URL} FAILED--Likely due to bad build job name or bad build number was given or connection/permission related! Please double check the URL: ${CMS_ARTIFECT_URL}."
            echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${CMS_ARTIFECT_URL} FAILED--Likely due to bad build job name or bad build number was given or connection/permission related! Please double check the URL: ${CMS_ARTIFECT_URL}." >> ./console.log
            /bin/cat ./wget_errlog >> ./console.log
            /bin/cat ./console.log | /bin/mail -s "*ALERT* Problem downloading ${CMS_ARTIFECT_URL}--wget ${CMS_ARTIFECT_URL} FAILED!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
            cd ../;
            /bin/rm -rf ${tmpDownldDir}
            exit 1
         fi
         echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir}"

         /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir}
         echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${CMS_ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}"
         /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${CMS_ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}
         /bin/rm -rf ${tmpDownldDir}
      fi
   fi

   cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --manual_stop_ldap $MANUAL_STOP_LDAP --manual_start_ldap $MANUAL_START_LDAP --manual_stop_intalio $MANUAL_STOP_INTALIO --manual_start_intalio $MANUAL_START_INTALIO --manual_stop_jasper $MANUAL_STOP_JASPER --manual_start_jasper $MANUAL_START_JASPER --manual_switchoff_rtvscand $MANUAL_SWITCHOFF_RTVSCAN --manual_switchon_rtvscand $MANUAL_SWITCHON_RTVSCAN --do_email_notification $DO_EMAIL_NOTIFIY --artifact_download_dir ${tmpDownldDir} --email_to_list ${EMAIL_TO} --email_cc_list ${EMAIL_CC} --deployerr_mail_to ${ERR_EMAIL_TO} --deployerr_mail_cc ${ERR_EMAIL_CC} --db_usr ${DB_USR} --db_passwd ${DB_PASSWD}"
fi

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}"

/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
