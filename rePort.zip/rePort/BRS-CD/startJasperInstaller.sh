#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <INST_TYPE> <CURR_JASPER_VER> <NEW_JASPER_VER> <URIS> <DB_SOURCE> <SLAVE_DB_VALS> <SCP_NEW_INST_KIT> <APP_USR> <JASPER_SERV_IP>"
   echo ""
   echo "   where"
   echo ""
   echo "            <INST_TYPE> : Type of installation (either UPGRADE or NEW)."
   echo ""
   echo "      <CURR_JASPER_VER> : Version of the Jasper currently running on the server."
   echo ""
   echo "       <NEW_JASPER_VER> : Version of the new Jasper you are installing or upgrading to."
   echo ""
   echo "                 <URIS> : Comma separated list of Jasper folder URI path(s) that you"
   echo "                          would like to export."
   echo ""
   echo "            <DB_SOURCE> : The source of the application DB (either prod or non-prod)."
   echo "                          This is needed to determine whether to run syncTraksmart4RptTables.sh"
   echo "                          before or after importing Jasper reports/roles"
   echo ""
   echo "        <SLAVE_DB_VALS> : Specify NIL if this is for a NON-PRODUCTION server."
   echo "                          Otherwise, specify the slave DB values in this comma-separated"
   echo "                          format: db.type,db.host,db.port,db.name,db.usr,db.passwd,db.jdbcClass"
   echo ""
   echo "      <SCP_NEW_INST_KIT>: Specify whether to scp new Jasper installation kit to the Jasper server."
   echo "                          By default, always scp new Jasper installation kit unless it's already there."
   echo ""
   echo "              <APP_USR> : The app. user account needed for sudo executing Jasper installation"
   echo "                          script on the Jasper server"
   echo ""
   echo "       <JASPER_SERV_IP> : IP address of the Jasper server."
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 NEW 4.2 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports prod mysql,10.32.48.69,3306,cgv_prod_slave,cgv_prod_slave,cgv_prod_slave,com.mysql.jdbc.Driver YES traksmart 172.20.19.122"
   echo ""
   echo "  $0 NEW 4.5.1 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports,/public non-prod NIL NO traksmart 172.20.19.150"
   echo ""
   exit
}

if [ $# -ne 9 ]; then
   Usage
fi

#################
# Arguments given 
#################
INST_TYPE=$1
CURR_JASPER_VER=$2
NEW_JASPER_VER=$3
URIS="$4"
DB_SOURCE=$5
SLAVE_DB_VALS=$6
SCP_NEW_INST_KIT=$7
APP_USR=$8
JASPER_SERV_IP=$9

EMAIL_LIST="mailto:mchu@nexant.com"
JASPER_INST_KIT_ROOT="/home/jenkins/data/Jasper"
JASPER_INST_KIT="${JASPER_INST_KIT_ROOT}/v${NEW_JASPER_VER}/jasperreports-server-${NEW_JASPER_VER}-clean-reporting.tar.gz"
JASPER_INST_KIT_DIR="/tmp/Jasper${NEW_JASPER_VER}_${INST_TYPE}_install_kit"
JASPER_INST_SCRIPT="/home/${APP_USR}/bin/runJasperInstaller.sh"

if [ "${SCP_NEW_INST_KIT}" == "YES" ]; then
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${JASPER_SERV_IP} /bin/mkdir -p ${JASPER_INST_KIT_DIR}"
   /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${JASPER_SERV_IP} /bin/mkdir -p ${JASPER_INST_KIT_DIR} 

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${JASPER_INST_KIT} jenkins@${JASPER_SERV_IP}:${JASPER_INST_KIT_DIR}"
   /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${JASPER_INST_KIT} jenkins@${JASPER_SERV_IP}:${JASPER_INST_KIT_DIR}
fi

cmd="sudo -u ${APP_USR} ${JASPER_INST_SCRIPT} ${INST_TYPE} ${CURR_JASPER_VER} ${NEW_JASPER_VER} \"${URIS}\" ${DB_SOURCE} ${SLAVE_DB_VALS} ${APP_USR} ${JASPER_INST_KIT_DIR}"

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${JASPER_SERV_IP} ${cmd}"

/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${JASPER_SERV_IP} ${cmd}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
