#!/bin/bash
#
# backupDB.sh
#   Being called by the auto-deployment script during application database backup.
#   This is to allow running DB backup in the background (as app. DB backup takes
#   much longer time to backup) so that LDAP/Intalio/documents-dir(/perhaps Jasper
#   backup as needed) backups can be done concurrently with app. DB backup, in order
#   to reduce total backup time.
#

#
# Issues usage message
#
function Usage
{
   echo ""
   echo "Usage: $0 <db_type> <db_usr> <db_passwd> <db_host> <db_name> <back_dir> <tag>"
   echo ""
   echo "   where"
   echo ""
   echo "        <db_type>   : DB type (e.g. mysql, sqlserver, oracle)"
   echo "        <db_usr>    : DB user"
   echo "        <db_passwd> : DB password"
   echo "        <db_host>   : DB host"
   echo "        <db_name>   : DB name"
   echo "        <back_dir>  : The directory to store the DB backup file"
   echo "        <tag>       : The tag (either preinstall or postinstall) to distinguish"
   echo "                      whether the backup is done pre or post war-file installation"
   echo ""
   exit 1
}

#
# Verifies number of arguments
#
if [ $# -ne 7 ]; then
   Usage
fi

RETVAL=0

#
# Clean up the status file for new backup
#
BACKUP_DIR="$6"
mkdir -p $BACKUP_DIR
RETVAL=$?
DB_BK_FILE="${BACKUP_DIR}/DB_BACKUP_STATUS"
DB_BK_ERRLOG="${BACKUP_DIR}/DB_BACKUP_STDERR"
if [ $RETVAL -eq 0 ]; then
  if [ -e $DB_BK_FILE ] ; then
    rm -f $DB_BK_FILE
  fi
else
  exit $RETVAL
fi

#
# Backup the given mysql DB
#
function backupMysqlDB()
{
    local db_user= db_passwd= db_host= db_name= back_dir= tag=
    db_user="$1"
    db_passwd="$2"
    db_host="$3"
    db_name="$4"
    back_dir="$5"
    tag="$6"

    bk_prog=/usr/bin/mysqldump
    if [ -e $bk_prog ] ; then
       bk_file="${back_dir}/${db_name}-${tag}.sql.gz"
       $bk_prog -f --user=$db_user --password=$db_passwd --host=$db_host $db_name | gzip > ${bk_file} 2> $DB_BK_ERRLOG
       RETVAL=$?
       if [ $RETVAL -eq 0 ]; then
          echo "DB_BK_SUCCEED" > ${DB_BK_FILE}
       else
          echo "DB_BK_FAILED" > ${DB_BK_FILE}
       fi
    else
       echo "NO_BACKUP_PROG" > ${DB_BK_FILE}
       RETVAL=1
    fi

    return $RETVAL
}

#
# Backup per dtatbase type
#
case "$1" in
    mysql)
        backupMysqlDB $2 $3 $4 $5 $6 $7
        RETVAL=$?
        ;;
    sqlserver)
        ;;
    oracle)
        ;;
    *)
        Usage
esac

exit $RETVAL

