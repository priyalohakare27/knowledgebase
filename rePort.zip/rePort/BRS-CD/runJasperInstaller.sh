#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <INST_TYPE> <CURR_JASPER_VER> <NEW_JASPER_VER> <URIS> <DB_SOURCE> <SLAVE_DB_VALS> <APP_USR> <JASPER_INST_KIT_DIR>"
   echo ""
   echo "   where"
   echo ""
   echo "              <INST_TYPE> : Type of installation (either UPGRADE or NEW)."
   echo ""
   echo "        <CURR_JASPER_VER> : Version of the Jasper currently running on the server."
   echo ""
   echo "         <NEW_JASPER_VER> : Version of the new Jasper you are installing or upgrading to."
   echo ""
   echo "                   <URIS> : Comma seperated list of Jasper folder URI path(s) that you"
   echo "                            would like to export."
   echo ""
   echo "              <DB_SOURCE> : The source of the application DB (either prod or non-prod)."
   echo "                            This is needed to determine whether to run syncTraksmart4RptTables.sh"
   echo "                            before or after importing Jasper reports/roles"
   echo ""
   echo "        <SLAVE_DB_VALS> : Specify NIL if this is for a NON-PRODUCTION server."
   echo "                          Otherwise, specify the slave DB values in this comma-separated"
   echo "                          format: db.type,db.host,db.port,db.name,db.usr,db.passwd,db.jdbcClass"
   echo ""
   echo "                <APP_USR> : The app. user account needed for sudo executing Jasper installation"
   echo "                            script on the Jasper server and retrieving app. properties"
   echo ""
   echo "    <JASPER_INST_KIT_DIR> : The directory where the Japser installation kit is located."
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 new 4.2 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports prod mysql,10.32.48.69,3306,cgv_prod_slave,cgv_prod_slave,cgv_prod_slave,com.mysql.jdbc.Driver traksmart /tmp/Jasper5.6_new_install_kit"
   echo ""
   echo "  $0 new 4.5.1 5.6 /organizations/organization_1/I_Reports,/organizations/organization_1/Reports,/organizations/organization_1/adhoc,/public non-prod NIL traksmart /tmp/Jasper5.6_new_upgrade_kit"
   echo ""
   exit
}


if [ $# -ne 8 ]; then
   Usage
fi

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Calling sudo /root/scripts/jasperInstaller.sh \"$1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\""
echo ""
sudo /root/scripts/jasperInstaller.sh "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8"

