#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <APP_USR> <APP_SERV_IP> <JOB_NAME> <BUILD_NUM>"
   echo ""
   echo "   where"
   echo ""
   echo "            <APP_USR> : The user account under which the application instance is running"
   echo "                        (e.g. 'traksmart' for Traksmart related applications)."
   echo ""
   echo "        <APP_SERV_IP> : The IP address of the targeted app. server (e.g. 172.20.19.128)"
   echo "                        to be updating with the latest BRS src code"
   echo ""
   echo "           <JOB_NAME> : The name of Jenkins job (i.e. BRS-pkg-latest-code) to download"
   echo "                        the latest BRS src code .gz file (i.e. BRS_latestCode.tar.gz)"
   echo ""
   echo "          <BUILD_NUM> : The build number of JOB_NAME with which BRS_latestCode.tar.gz"
   echo "                        was built"
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 traksmart 172.20.19.136 BRS-pkg-latest-code 3"
   echo ""
   echo "  $0 traksmart 172.20.19.233 BRS-pkg-latest-code 3"
   echo ""
   exit
}

if [ $# -ne 4 ]; then
   Usage
fi

#################
# Arguments given 
#################
APP_USR=$1
APP_SERV_IP=$2
JOB_NAME=$3
BUILD_NUM=$4

#####################################
# The update script that does the job 
#####################################
UPDATE_SCRIPT="/home/${APP_USR}/bin/update-BRS-scripts.sh"

#############################
# Default update command-line 
#############################
cmd="sudo -u $APP_USR $UPDATE_SCRIPT $APP_USR $JOB_NAME $BUILD_NUM"

#########################
# All other relevant info
#########################
BUILD_SERV_URL="http://172.20.19.61:9090"
BRS_CODE_GZ_FILE="BRS_latestCode.tar.gz"
BRS_CODE_GZ_URL="${BUILD_SERV_URL}/job/${JOB_NAME}/${BUILD_NUM}/artifact/target/${BRS_CODE_GZ_FILE}"
HOME_DIR="/home/${APP_USR}"
BIN_DIR="${HOME}/bin"
SCRIPT_DIR="${BIN_DIR}/BRS-CD"
LOG_FILE="/tmp/update-BRS-scripts-on-appserver.log"

EMAIL_LIST="mailto:mchu@nexant.com"

#######################################################################
# Check if the application server on which the latest BRS source code 
# to be updating is located in a different network domain (i.e. Its IP 
# address starts with 192 or anything other than 172) of the build 
# server. If so, we will need to scp the BRS source code gz file to it 
# as it is not possible to directly wget the file from the build server
# which is locating in the 172 domain.
#######################################################################
IP_PREFIX=`echo ${APP_SERV_IP} | cut -d '.' -f1`
if [ "${IP_PREFIX}" == "192" ]; then
   tmpDownldDir="/tmp/${APP_SERV_IP}_${JOB_NAME}_${BUILD_NUM}.$(date +%Y-%m-%d-%H-%M-%S)"
   /bin/mkdir -p ${tmpDownldDir}
   cd ${tmpDownldDir};

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: wget ${BRS_CODE_GZ_URL} into ${tmpDownldDir}"

   # Download the BRS_latestCode.tar.gz file
   wget ${BRS_CODE_GZ_URL} 2>> ${LOG_FILE}
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${BRS_CODE_GZ_URL} FAILED--Likely connection/permission related or due to bad ${BRS_CODE_GZ_URL} path!"
      cat ${LOG_FILE} | mail -s "*ALERT* wget ${BRS_CODE_GZ_URL} FAILED!" ${EMAIL_LIST}
      cd ../
      rm -rf ${tmpDownldDir}   
      exit 1;
   fi

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir}"

   /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir} 

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${BRS_CODE_GZ_FILE} jenkins@${APP_SERV_IP}:${tmpDownldDir}"
   /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${BRS_CODE_GZ_FILE} jenkins@${APP_SERV_IP}:${tmpDownldDir}

   cmd="sudo -u $APP_USR $UPDATE_SCRIPT $APP_USR $JOB_NAME $BUILD_NUM $APP_SERV_IP ${tmpDownldDir}"

   cd ../
   /bin/rm -rf ${tmpDownldDir}
fi

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}"

/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
