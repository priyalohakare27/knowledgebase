# Class for Deploy related functionalities
package BRS::Release::FullRelease::Deploy;

use strict;
use warnings;
use Switch;
use List::Util 'max';
use Cwd;
use Carp;
use File::Basename;
use BRS::Release::FullRelease;
our @ISA = qw(BRS::Release::FullRelease);

use BRS::Utils;


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class) = shift;

  my $self = $class->SUPER::new( @_ );

  $self->init( @_ );

  bless( $self, $class );

  return( $self );
}

##############################################################
# Destructor
##############################################################
sub DESTROY
{
   my ($self) = shift;

   &removeFile( $self->deploy_state_file ) if( defined( $self->deploy_state_file ) && -r $self->deploy_state_file );
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Check/enforce mandatory options as Getopt::Long::GetOptions doesn't
   # do so -- That's why it's called GetOptions??
   Usage( "\n***ERROR: You must specify an application user ID (e.g. traksmart) under which the application is running***\n\n" ) unless defined( $args->{app_usr} );
   Usage( "\n***ERROR: You must specify at least one application server IP address (e.g. 172.20.19.128) on which the artifact is to be deployed***\n\n" ) unless defined( $args->{app_serv_ip} );

   # Initialize common build/release data through the parent class
   $self->SUPER::init( $args );

   # Set the default values, which will be overwritten by those specifying in the
   # ${home}/BRS/conf/.Deploy.conf file (if any), which in turn will be overwritten
   # by those specifying through the command-line options
   max_ping_tries( $self, 60 ); # Max. number of tries on ping'ing an app. instance
   sleep_time( $self, 15); # Number of seconds to sleep befre re-ping'ing

   # web server (e.g. Jetty, Tomcat, etc) related script/config files (default is Jetty)
   web_serv_name( $self, "jetty" );
   web_serv_script( $self, "/etc/init.d/jetty" );
   web_serv_config_file( $self, "/etc/default/jetty" );

   # LDAP control (start/stop/restart/status) script
   ldap_ctl_script( $self, "/etc/init.d/ldap" );

   # Intalio control (start/stop/restart/status) script
   intalio_ctl_script( $self, "/etc/init.d/cloud" );

   # Jasper control (start/stop/restart/status) script
   jasper_ctl_script( $self, "/opt/jasper/ctlscript.sh" );

   # LDAP backup script
   ldap_bk_script( $self, "/opt/ldap_backups/ldap_backups.sh" );

   # Intalio backup script
   intalio_bk_script( $self, "/etc/cron.d/intalio-cloud-backup" );

   # Jasper backup script
   jasper_bk_script( $self, "/opt/jasper_backups/jasper_backups.sh" );

   # rtvscand control (start/stop/restart/status) script
   rtvscand_ctl_script( $self, "/etc/init.d/rtvscand" );

   # Set the data specific to this Deploy object
   # with the ones specified on the command-line
   app_usr( $self, $args->{app_usr} );
   app_serv_ip( $self, $args->{app_serv_ip} );
   artifact_download_dir( $self, $args->{artifact_download_dir} );
   custom_customer( $self, $args->{custom_customer} );
   trigger_other_build( $self, $args->{trigger_other_build} );
   do_email_notification( $self, $args->{do_email_notification} );
   manual_stop_appInst( $self, $args->{manual_stop_appInst} );
   manual_start_appInst( $self, $args->{manual_start_appInst} );
   manual_stop_intalio( $self, $args->{manual_stop_intalio} );
   manual_start_intalio( $self, $args->{manual_start_intalio} );
   manual_stop_jasper( $self, $args->{manual_stop_jasper} );
   manual_start_jasper( $self, $args->{manual_start_jasper} );
   manual_stop_ldap( $self, $args->{manual_stop_ldap} );
   manual_start_ldap( $self, $args->{manual_start_ldap} );
   manual_switchoff_rtvscand( $self, $args->{manual_switchoff_rtvscand} );
   manual_switchon_rtvscand( $self, $args->{manual_switchon_rtvscand} );
   manual_bk_ldap( $self, $args->{manual_bk_ldap} );
   manual_bk_intalio( $self, $args->{manual_bk_intalio} );
   manual_bk_jasper( $self, $args->{manual_bk_jasper} );
   manual_bk_docsdir( $self, $args->{manual_bk_docsdir} );
   manual_bk_appdb( $self, $args->{manual_bk_appdb} );

   my $home = "/home/".$self->app_usr;

   my ($default_brs_data, $tmpStr, $msg);

   my $configFilePath = ${home}."/BRS/conf/.Deploy.conf";
   inst_proc_script( $self, "${home}/bin/processInstanceServProcess.sh" );

   # Default DB backup related objects
   db_bk_script( $self, "${home}/bin/db_backup.sh" );
   db_bkdir( $self, "${home}/appDB_backups" );
   ldap_full_bkdir( $self, "${home}/ldap_full_backups" );
   db_bk_status_file( $self, $self->db_bkdir . "/DB_BACKUP_STATUS" );
   db_bk_stderr_file( $self, $self->db_bkdir . "/DB_BACKUP_STDERR" );

   # Default LDAP full backup directory -- by backing up the whole /var/lib/ldap directory per TECHOPS
   ldap_full_bkdir( $self, "${home}/ldap_full_backups" );

   # In case the deployment configuration file is missing or empty, so that we can still send email to the right person(s)
   deployerr_mail_to( $self, $args->{deployerr_mail_to} );
   my $res = &isValidEmailAddress( $self->deployerr_mail_to );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email TO list, " . $res . " (as specified in " . $configFilePath . ", is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   deployerr_mail_cc( $self, $args->{deployerr_mail_cc} );
   $res = &isValidEmailAddress( $self->deployerr_mail_cc );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email CC list, " . $res . " (as specified in " . $configFilePath . ", is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   # Override the default config file with the one specified in command-line, if any
   $configFilePath = $args->{config_file} if defined( $args->{config_file} );

   my ($ip1, $ip2, $ip3, $ip4) = split( /\./, $self->app_serv_ip );
   runtime_env( $self, ($ip1 =~ "172") ? "qa" : "nonqa" );

   if ( -r $configFilePath )
   {
       # Retrieve default common build/release data from the config file
       $default_brs_data = readConfigFile( $configFilePath );

       # Double check just in case
       unless( %{$default_brs_data} )
       {
          $msg = "Nothing was read/retrieved from the deployment config file, " . $configFilePath . "--Likely due to the file is either empty or corrupted! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Deployment config file seems to be either empty or corrupted!", $msg );
          exit(1);
       }

       # Retrieve email TO/CC lists (for sending email about deployment errors) from the default config file
       my ($deployerrMailTO, $deployerrMailCC) = &getEmailList( "deployerr", $self->runtime_env, $default_brs_data );
       deployerr_mail_to( $self, $deployerrMailTO );
       deployerr_mail_cc( $self, $deployerrMailCC );

       max_ping_tries( $self, $default_brs_data->{$self->max_ping_tries} );
       sleep_time( $self, $default_brs_data->{$self->sleep_time} );

       inst_proc_script( $self, "${home}/bin/$default_brs_data->{inst_proc_script}" );

       db_bk_script( $self, "${home}/bin/$default_brs_data->{db_bk_script}" );

       web_serv_name( $self, $default_brs_data->{$self->web_serv_name} );
       web_serv_script( $self, $default_brs_data->{web_serv_script} );
       web_serv_config_file( $self, $default_brs_data->{web_serv_config_file} );

       ldap_ctl_script( $self, $default_brs_data->{ldap_ctl_script} );
       intalio_ctl_script( $self, $default_brs_data->{intalio_ctl_script} );
       jasper_ctl_script( $self, $default_brs_data->{jasper_ctl_script} );
       rtvscand_ctl_script( $self, $default_brs_data->{rtvscand_ctl_script} );

       ldap_bk_script( $self, $default_brs_data->{ldap_bk_script} );
       intalio_bk_script( $self, $default_brs_data->{intalio_bk_script} );
       jasper_bk_script( $self, $default_brs_data->{jasper_bk_script} );

       unless( $default_brs_data->{$self->app_serv_ip} )
       {
          $msg = "The IP address, ". $self->app_serv_ip . ", that associates with the instance URL line is not found in " . $configFilePath . ". Perhaps this is a new application server that its instance URL line has not been added! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* IP address not found in the deployment config file missing!", $msg );
          exit(1);
       }
       instance_url( $self, $default_brs_data->{$self->app_serv_ip} );
       instance_name( $self, $default_brs_data->{$self->app_serv_ip} );
   }
   else
   {
       $msg = "The deployment config file, " . $configFilePath . ", is missing! Perhaps it was removed accidently? Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Deployment config file is missing!", $msg );
       exit(1);
   }

   # Override the default values with the ones specified in command-line, if any
   deployerr_mail_to( $self, $args->{deployerr_mail_to} );
   $res = &isValidEmailAddress( $self->deployerr_mail_to );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email TO list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   deployerr_mail_cc( $self, $args->{deployerr_mail_cc} );
   $res = &isValidEmailAddress( $self->deployerr_mail_cc );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email CC list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   max_ping_tries( $self, $args->{max_ping_tries} );
   sleep_time( $self, $args->{sleep_time} );

   inst_proc_script( $self, $args->{inst_proc_script} );
   unless ( &isValidScript( $self->inst_proc_script ) )
   {
       $msg = "The given instance server processing script, " . $self->inst_proc_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid instance server processing script!", $msg );
       exit(1);
   }

   db_bk_script( $self, $args->{db_bk_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless ( &isValidScript( $self->db_bk_script ) )
      {
          $msg = "The given DB backup script, " . $self->db_bk_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid DB backup script!", $msg );
          exit(1);
      }
   }

   web_serv_name( $self, $args->{web_serv_name} );

   # Handling the case where multiple QA instances are running on the same box
   # in which the web sever config files are named with "-<ip addr> extension
   # TODO: Request OPS to avoid the above situation if possible
   if ( $self->app_serv_ip =~ "172.20.19.210" ||
           $self->app_serv_ip =~ "172.20.19.217")
   {
       web_serv_script( $self, $self->web_serv_script . "-" . $self->app_serv_ip);
   }
   else
   {
       web_serv_script( $self, $args->{web_serv_script} );
   }

   unless ( &isValidScript( $self->web_serv_script ) )
   {
       $msg = "The given web server start/stop control script, " . $self->web_serv_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid web server start/stop control script!", $msg );
       exit(1);
   }

   web_serv_config_file( $self, $args->{web_serv_config_file} );
   unless( &isValidScript( $self->web_serv_config_file ) )
   {
       &LOG( \*STDERR, "WARNING: The given web server default config file, '". $self->web_serv_config_file ."', either does not exist or is an empty one! Please verify if something is not right.\n\n" );
   }

   ldap_ctl_script( $self, $args->{ldap_ctl_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless( &isValidScript( $self->ldap_ctl_script ) )
      {
          $msg = "The given LDAP start/stop control script, " . $self->ldap_ctl_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid LDAP start/stop control script!", $msg );
          exit(1);
      }
   }

   jasper_ctl_script( $self, $args->{jasper_ctl_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless( &isValidScript( $self->jasper_ctl_script ) )
      {
          $msg = "The given Jasper start/stop control script, " . $self->jasper_ctl_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid Jasper start/stop control script!", $msg );
          exit(1);
      }
   }

   rtvscand_ctl_script( $self, $args->{rtvscand_ctl_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless( &isValidScript( $self->rtvscand_ctl_script ) )
      {
          $msg = "The given rtvscand start/stop control script, " . $self->rtvscand_ctl_script . ", either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file!";
          &LOG(\*STDERR, "*WARNING* " . $msg . " Deployment will go on but expect some delay due to the virus scan. Please verify and fix it.\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid rtvscand start/stop control script!", $msg );
          #exit(1);
      }
   }

   ldap_bk_script( $self, $args->{ldap_bk_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless ( &isValidScript( $self->ldap_bk_script ) )
      {
          $msg = "The given LDAP backup script, '". $self->ldap_bk_script ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid LDAP backup script!", $msg );
          exit(1);
      }
   }

   jasper_bk_script( $self, $args->{jasper_bk_script} );
   unless ( $self->runtime_env =~ /qa|dev/ )
   {
      unless( &isValidScript( $self->jasper_bk_script ) )
      {
          $msg = "The given Jasper backup script, '". $self->jasper_bk_script ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify."; 
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid Jasper backup script!", $msg );
          exit(1);
      }
   }

   # Set the default values
   nexant_app_home( $self, "/home/".$self->app_usr."/nexant_app_home/QA.".$ip4 );

   my $key = substr( $self->build_job, 0, 2 );

   # Ensure that build_job & app_usr do match
   unless( &isBuildJobAndAppUsrMatch( $key, $self->app_usr ) )
   {
       $msg = "The given build job, " . $self->build_job . ", and application user, " . $self->app_usr . ", mismatch--Make sure you specify the right build job for the application user! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Build job & application user mismatch!", $msg );
       exit(1);
   }
   app_name( $self, &genAppName($key) );
   artifact_name( $self, $self->app_name.".war" );
   artifact_dir( $self, $self->build_job."_build-".$self->build_num );

   # Override with the ones in command-line arguments
   db_bk_script( $self, $args->{db_bk_script} );
   db_bkdir( $self, $args->{db_bkdir} );
   ldap_full_bkdir( $self, $args->{ldap_full_bkdir} );

   # Should not allow user to specify the DB backup status & stderr files
   # as they should be specified in the db_backup.sh to avoid inconsistence
   #db_bk_status_file( $self, $args->{db_bk_status_file} );
   #db_bk_stderr_file( $self, $args->{db_bk_stderr_file} );

   my $flist;

   if ( $self->app_serv_ip =~ "172.20.19.210" || $self->app_serv_ip =~ "172.20.19.217")
   {
       # For QA .210 & .217, /etc/default/jetty is not being used
       $flist = $self->web_serv_script;
   }
   else
   {
       $flist = $self->web_serv_script . " " . $self->web_serv_config_file;
   }

   my $web_serv_home = $self->web_serv_name . "_home";
   web_serv_home( $self, &getPropFromWebConfigFile($self, $flist, uc($web_serv_home) ) );

   # This is also not likely to happen--but just in case
   unless( -e $self->web_serv_home && -d $self->web_serv_home )
   {
       $msg = "The web server home, ". $self->web_serv_home .", either does not exist or is not a directory--Something is terribly wrong! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Web server home/installation directory is missing!", $msg );
       exit(1);
   }

   my $nex_app_hame = &getPropFromWebConfigFile($self, $flist, "^NEXANT_APP_HOME");
   if ( $nex_app_hame )
   {
      nexant_app_home( $self, $nex_app_hame );
      runtime_env( $self, &getPropFromWebConfigFile($self, $flist, "^RUNTIME_ENV" ) );
      app_prop_file( $self, $self->nexant_app_home . "/application.properties");
   }
   else
   {
      app_prop_file( $self, $self->web_serv_home . "/lastBuild/" . $self->app_name . "/WEB-INF/classes/application.properties");
   }

   unless( -s $self->app_prop_file && -f $self->app_prop_file )
   {
       $msg = "The application.properties file, " . $self->app_prop_file . ", either does not exist or is not an non-empty plain file! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* The application.properties file is missing!", $msg );
       exit(1);
   }

   my $app_props = readConfigFile( $self->app_prop_file );

   # Double check just in case
   unless( %{$app_props} )
   {
       $msg = "Nothing was read/retrieved from the application.properties file, " . $self->app_prop_file . "--Likely due to the file is either empty or corrupted! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Failed to read from the application.properties file!", $msg );
       exit(1);
   }

   # Replace all '.' in a hash key with '_' (e.g. db.name to db_name)
   %{$app_props} = map {
                        (my $new = $_) =~ s/\./\_/g;
                        $new => $app_props->{$_}
                      } keys %{$app_props};

   # Set the values obtained from the application.properties file
   integration_host( $self, $app_props->{integration_host} );
   integration_ip_internal( $self, $app_props->{integration_ip_internal} );
   jasper_hostname( $self, $app_props->{jasper_hostname} );
   ldap_host( $self, $app_props->{ldap_host} );
   db_type( $self, $app_props->{db_type} );
   db_host( $self, $app_props->{db_host} );
   db_port( $self, $app_props->{db_port} );
   db_name( $self, $app_props->{db_name} );

   # For SAC (e.g. staging/production) servers, we will use a DB user & passwd created specifically 
   # for DB backup instead of the DB user & passwd specifying in the application.properties file
   # due to accessibility problem--mysqldump: Got error: 1044. And the special DB user & passwd will
   # will be given manually through the deployment script arguments instead of stroing in a file 
   # that will be checkined into SVN
   db_usr( $self, $app_props->{db_usr} );
   db_passwd( $self, $app_props->{db_passwd} );

   # File that keeps track of the deployemnt state
   my $depStatFile = ${home} . "/.Deploy.state." . $self->app_serv_ip . "_" . $self->build_job . "_" . $self->build_num;
   deploy_state_file( $self, $depStatFile );

   # Retrieve email TO/CC lists from the default config file
   $key = substr( $self->build_job, 0, 2 );
   my ($email_to, $email_cc) = &getEmailList( $key, $self->runtime_env, $default_brs_data );
   email_to_list( $self, $email_to );
   email_cc_list( $self, $email_cc );

   # Override with those given in the command-line arguments if any
   email_to_list( $self, $args->{email_to_list} );
   $res = &isValidEmailAddress( $self->email_to_list );
   unless( $res =~ "VALID" )
   {
       $msg = "The email TO list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Non \@nexant.com email TO addresses were specified!", $msg );
       exit(1);
   }

   email_cc_list( $self, $args->{email_cc_list} );
   $res = &isValidEmailAddress( $self->email_cc_list );
   unless( $res =~ "VALID" )
   {
       $msg = "The email CC list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Non \@nexant.com email CC addresses were specified!", $msg );
       exit(1);
   }

   intalio_ctl_script( $self, $args->{intalio_ctl_script} );
   unless( $self->runtime_env =~ /qa|dev/ )
   {
      unless( &isValidRemoteScript( $self->intalio_ctl_script, $self->app_usr, $self->integration_ip_internal ) )
      {
          $msg = "The given script, '". $self->intalio_ctl_script ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
          &LOG( \*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Invalid Intalio start/stop control script!", $msg );
          exit(1);
      }
   }

   intalio_bk_script( $self, $args->{intalio_bk_script} );
   unless( $self->runtime_env =~ /qa|dev/ )
   {
      unless(  &isValidRemoteScript( $self->intalio_bk_script, $self->app_usr, $self->integration_ip_internal ) )
      {
          $msg = "The given script, '". $self->intalio_bk_script ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";

          &LOG( \*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Missing or Invalid Intalio backup script!", $msg );
          exit(1);
      }
   }

   db_usr( $self, $args->{db_usr} );
   db_passwd( $self, $args->{db_passwd} );

   # Initiate the deployment state (for a brand new deployment)
   curr_deploy_state( $self, "NEW\n" );
}

##############################################################
# Method to get a property (e.g. nexant_app_home for the
# application.properties file path) by parsing the web server
# (e.g. Jetty) config file(s) (e.g. /etc/init.d/jetty and/or
# /etc/default/jetty)
##############################################################
#sub getPropFromWebConfigFile($$;$)
sub getPropFromWebConfigFile
{
   my ($self, $fileList, $propName) = @_;
   my $app_usr = $self->app_usr;
   my $msg;

   # Find/filter the web server config file(s) that specifies given property
   my ($fline, @flines);
   if ( $propName =~ "JETTY_HOME" )
   {
       @flines = split(/\s+/, $fileList);
       foreach $fileList (@flines)
       {
           &LOG(\*STDOUT, "INFO: Attempting to retrieve web serv home ('$propName'), from '$fileList'\n");
           #$fline =`cd /; grep "$propName=" $fileList | grep -v "#" | grep "jetty-distribution"`;
           $fline =`cd /; grep "$propName=" $fileList | grep -v "#" | grep "jetty-"`;
           #last if ($fline =~ "jetty-distribution");
           last if ($fline =~ "jetty-");
       }
   }
   else
   {
       &LOG(\*STDOUT, "INFO: Retriving '$propName' from '$fileList'\n");
       $fline=`cd /; find $fileList | xargs grep "$propName=" | grep -v "#"`;
       # If couldn't find the property name in uppercase, try lowercase one
       unless( $fline )
       {
           $propName = lc($propName);
           $fline=`cd /; find $fileList | xargs grep "$propName=" | grep -v "#"`;
       }
   }

   unless( $fline )
   {
       $msg = "Failed to retrieve property, '" . $propName . "' from " . $fileList . "! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Failed to obtain a property from config file!", $msg );
       exit(1);
   }

   $fline = &trim( $fline );

   my ($dummy, $propFilePath);

   # Filter out the "<config file name>:" string part from search result
   # performed on multiple web server config files
   if ( index( $fline, ":" ) >= 0 )
   {
      # Get ride of the config file name part and retrieve the
      # "nexant_app_home=<path of the application.properties file> part
      # (e.g. "nexant_app_home=/home/${JETTY_USER}/nexant_app_home/QA.150")
      ($dummy, $fline) = split( ':', $fline );
      ($fline, $dummy) = split( /\n/, $fline );
   }

   # Now get the actual path of the application.properties file
   # (on the right-hand side of '=')
   # (e.g. "/home/${JETTY_USER}/nexant_app_home/QA.150")
   ($dummy, $propFilePath) = split( '=', $fline );

   unless( $propFilePath )
   {
       $msg = "Failed to retrieve the application.properties file path from " . $fileList . "! Please verify.";
       &LOG( \*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Failed to obtain the application.properties file path from config file!", $msg );
       exit(1);
   }

   if ( $propName =~ "JETTY_HOME" )
   {
      return( $propFilePath );
   }

   if ( $propFilePath && $app_usr )
   {
       # Replace any variable string (e.g. ${JETTY_USER}) in the
       # path of the application.properties file with the relevant
       # application user (e.g. traksmart)
       $propFilePath =~ s/\/home\/(.*?)\//\/home\/$app_usr\//g;
   }
   return( $propFilePath );
}

###############################################################
# Method to update the current deployment state according to
# the deployment state file.
###############################################################
sub updateCurrDeployStateFromFile
{
   my ($self) = shift;

   my $deployStateRef = readConfigFile( $self->deploy_state_file );
   curr_deploy_state( $self, $deployStateRef->{curr_deploy_state} );
}

#################################################################
# Method to determine/handle whether this is a re-deployemnt of
# the same build to the same server (which was terminated earlier
# due to certain reason) or this is a brand new deployemnt
#################################################################
sub handleDeployState
{
   my ($self) = shift;

   my $cmd;
   if( -r $self->deploy_state_file )
   {
      &LOG( \*STDOUT, "INFO: The depoyment state file, '". $self->deploy_state_file ."', does already exist (i.e. This is a re-deployment of the same build to the same application server).\n" );

      # Update the deployment state accordingly
      &updateCurrDeployStateFromFile( $self );
   }
   else
   {
      &LOG( \*STDOUT, "INFO: The depoyment state file, '". $self->deploy_state_file ."', does NOT exist (i.e. This is a brand new deployemnt).\n" );

      # Update the deployment state file accordingly
      $cmd = "echo curr_deploy_state=NEW > " . $self->deploy_state_file;
      &execCmd( "$cmd" );
   }
}


##########################################################################
# installArtifact( <obj> )
#    Retrieves and installs the artifact (e.g. a .war file)
#
# <obj>
#    This reference of this Deploy object
#
##########################################################################
sub installArtifact
{
    my ($self) = shift;
    my $web_serv_home = $self->web_serv_home;
    my $appName = $self->app_name;
    my $artifact_name = $self->artifact_name;
    my $artifactDir = $self->artifact_dir;
    my $runtime_env = $self->runtime_env;
    my $build_serv_url = $self->build_serv_url;
    my $build_job = $self->build_job;
    my $build_num = $self->build_num;
    my $artifact_download_dir = $self->artifact_download_dir;
    my $custom_customer = $self->custom_customer;

    my ($tmpNameBackup, $artifactLoc, $timestamp, $cmd);

    my $lastBuildPath = $web_serv_home . "/lastBuild";
    my $prevLnName = "previousBuild";

    # Create the "lastBuild" directory if not already exists
    unless( -e $lastBuildPath )
    {
        &createDir( $lastBuildPath );
    }

    # Retriving the needed info
    my $artifactDirPath = ${lastBuildPath}."/".${artifactDir};

    &LOG( \*STDOUT, "INFO: Artifact installation root directory: ${lastBuildPath}\n");
    &LOG( \*STDOUT, "INFO: application name: '${appName}'\n" );
    &LOG( \*STDOUT, "INFO: artifact names: '${artifact_name}'\n" );
    &LOG( \*STDOUT, "INFO: cd into '${lastBuildPath}'.\n" );

    # cd to the "lastBuild" directory to create sym. link pointing to the
    # new artifact directory
    &changeDir( $lastBuildPath );

    # Since CMS & TradeAlly are running under the same web server installation,
    # it's necessary to distinguish the "previousBuild" sym. link
    if ( $appName =~ "cms" )
    {
        $prevLnName = "previousBuild-cms";
    }

    # First, check to see if the app. dir (e.g. traksmart4) exists. If so,
    # check to see if it's a symbloic link or not. If it's not a sym. link,
    # then this is wrong and should be changed to a sym. link and pointing
    # to the artifact we're about to deploy.
    if( -e $appName )
    {
        # If the app. dir is a sym. link, then rename it to "previousBuild",
        # so that it can be used for rolling back a deployment, as needed
        if( -l $appName )
        {
           &LOG( \*STDOUT, "INFO: Renaming the '$appName' sym. link to '$prevLnName'.\n");
           &moveFile( $appName, $prevLnName );
        }
        # Otherwise, rename it to $appName_<timestamp> and points "previousBuild" to it
        # This should be a rare case with auto-deployment in place--unless someone
        # manually changed a sym. link to a real file name by accident
        else
        {
           $timestamp = &getFileModifyTime($appName, 'str');
           $tmpNameBackup = $appName . "_" . $timestamp;

           &LOG( \*STDOUT, "INFO: '$appName' is not a sym. link as expected--Renaming it to '$tmpNameBackup'.\n");
           &moveFile( $appName, $tmpNameBackup );

           &removeFile( $prevLnName ) if( -e $prevLnName );

           &LOG( \*STDOUT, "INFO: Creating sym. link '$prevLnName' pointing to '$tmpNameBackup'.\n");
           &createSymLink( $tmpNameBackup, $prevLnName );
        }
    }

    # Check to see if the directory to be created for storing the artifact (warfile)
    # for this deployment already exists--not likely but potentially possible.
    # If so, just rename it to ${artifactDirPath}_<timestamp>
    if( -e $artifactDirPath )
    {
        $timestamp = &getFileModifyTime($artifactDir, 'str');
        $tmpNameBackup = ${lastBuildPath} . "/" . $artifactDir . "_" . $timestamp;

        &LOG( \*STDOUT, "INFO: '$artifactDirPath' already existed (while shouldn't be); renaming it to '$tmpNameBackup'.\n");
        &moveFile( $artifactDirPath, $tmpNameBackup );

        # If the "previousBuild" symlink is pointing the same directory
        # then will need to re-pointing to the renamed one
        if ( -l "previousBuild" )
        {
            if ( &readSymLink("previousBuild") eq $artifactDir )
            {
                &removeFile( "previousBuild" );
                &LOG( \*STDOUT, "INFO: Re-creating sym. link 'previousBuild' to point to '$tmpNameBackup'.\n");
                &createSymLink( basename($tmpNameBackup), "previousBuild" );
            }
        }
    }

    &LOG( \*STDOUT, "INFO: Creating '$artifactDirPath'.\n");

    # Now, create the artifact directory
    &createDir( $artifactDirPath );

    &LOG( \*STDOUT, "INFO: cd into '${artifactDirPath}'.\n" );

    # cd to the artifact directory and install the artifact
    &changeDir( $artifactDirPath );

    # Obtain the location path to the artifact for this deployment based on
    # the deployment environment--For QA, the artifact will be getting from
    # the specific build server location (through wget directly), while for
    # Demo, Staging & Production (or any application servers locating outside
    # the network domain of the Maven Nexus repository), we will first retrieve
    # the artifact from the respective Maven Nexus repository, and then scp to
    # a temporary artifact download directory of the server and go from there
    if( $runtime_env =~ /qa|dev/ )
    {
       $artifactLoc = $build_serv_url . "/job/" . $build_job . "/" . $build_num . "/artifact/target/" . $artifact_name;
       $cmd = "wget $artifactLoc 2> /dev/null";
    }
    else
    {
       $artifactLoc = $artifact_download_dir . "/" . $artifact_name;

       # This situation should be rare. The deployment log should provided some clues
       # whether the file was successfully wget or scp'ed to the app. server or not.
       # If so, it's likely that someone accidently removed it right in the midst of
       # deployment or, during a demo/staging/prod deployment, /tmp just happened to
       # automatically get cleaned-up/flushed by the system
       unless( -e $artifactLoc )
       {
          my $msg = "The artifact/war-file for this deployment, " . $artifactLoc . ", does not exist! Something is not right. Please check the deployment log in the build tool (e.g. Jenkins)--It is possible that someone accidently removed it. Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* The path to the artifact/war-file for this deployment does not exist!", $msg );
          exit(1);
       }
       $cmd = "cp -f ${artifactLoc} ${artifactDirPath}/";
    }

    &LOG( \*STDOUT, "INFO: Downloading/Copying '$artifactLoc' to '${artifactDirPath}/.'\n");
    &execCmd( "$cmd" );

    &LOG( \*STDOUT, sprintf( "INFO: Start installing artifact, '%s', under '%s'.\n", ${artifact_name}, ${artifactDirPath} ) );

    # unzip the artifact
    &execCmd( "unzip $artifact_name" );

    # If customer customizations is needed, launch a build to generate
    # a tar.gz with customization files, to be downloaded and untar
    # into the artifact directory
    if ( $custom_customer !~ "NONE" )
    {
        my $VERSION = &getRelVersion( $build_job );
        $cmd = $build_serv_url . "/job/TS-Customize/buildWithParameters?CUSTOMER=" . $custom_customer . "\&RELEASE=".$VERSION;
        &LOG( \*STDOUT, "INFO: Launching curl \"$cmd\" to generate the customizations tar.gz file.\n");
        &execCmd( "curl --user jenkins:J3nK1nS \"$cmd\"" );

        sleep 5;

        my $customZipFile = $custom_customer . "_Customizations.tar.gz";
        my $customZipFilePath = $build_serv_url . "/job/TS-Customize/lastBuild/artifact/target/$customZipFile";

        &LOG( \*STDOUT, "INFO: Downloading '$customZipFilePath'.\n");

        # wget the customizations zip file
        &execCmd( "wget $customZipFilePath" );

        &LOG( \*STDOUT, "INFO: Installing '$customZipFilePath'.\n");

        # untar the customizations zip file
        &execCmd( "tar -zxvf $customZipFile" );
    }

    # Remove the artifact
    &removeFile( $artifact_name );

    # cd to the "lastBuild" directory to create sym. link pointing to the
    # new artifact directory
    &changeDir( $lastBuildPath );

    &LOG( \*STDOUT, "INFO: Creating sym. link '$appName' pointing to '$artifactDir'.\n");

    # Create the sym. link by pointing to the new artifact directory
    &createSymLink( $artifactDir, $appName );

    &LOG( \*STDOUT, "INFO: Completed installing '$artifact_name'.\n\n" );
}

###############################################################
# Method to deploy the artifact to the given application server
###############################################################
sub deploy
{
    my ($self) = shift;

    my ($instance, $cmd, $msg);

    # Verify if this is a re-deployemnt of the same build to the same server
    # (which was terminated earlier due to various reason). If so, just pick
    # up from where it left off, otherwise, do a brand new deployment
    &handleDeployState( $self );

    # Only handle email notification situation when the relevant flag is set (to TRUE).
    # Currently, the flag is only set to FALSE when we're deploying CMS together with
    # TradeAlly
    if ( $self->do_email_notification )
    {
       # If the deployment state is not NEW, it must be either in HEADS-UP(email)_SENT
       # state or in a later state. But whichever state it is in, HEADS-UP email should
       # have already been sent
       if( $self->curr_deploy_state !~ "NEW" )
       {
           &LOG(\*STDOUT, "INFO: deployment HEADS-UP email has already been sent.\n");
       }
       # Send deployement heads-up email as needed
       else
       {
           &LOG(\*STDOUT, "INFO: Sending deployment HEADS-UP email.\n");
           &sendEmail( $self->email_to_list, $self->email_cc_list, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num,, "HEADS-UP") );

           $cmd = "echo curr_deploy_state=HEADS-UP_SENT > " . $self->deploy_state_file;
           &execCmd( "$cmd" );

           # Update the deployment state file accordingly
           curr_deploy_state( $self, "HEADS-UP_SENT\n" );
       }
    }

    # Automatically stop the application instance as needed, unless it's specified
    # to manually stop the application instance (This should be rare -- One example
    # would be when we're deploying a CMS build together with Tradeally in which
    # the application instance should have already been stopped when the CMS/Tradeally
    # deployment process started earlier)
    unless( $self->manual_stop_appInst )
    {
       &LOG(\*STDOUT, "INFO: Shutting down ". $self->instance_name ."(IP: ". $self->app_serv_ip .")'s ". $self->web_serv_name ." process.\n");
       &processInstanceServProcess( $self->inst_proc_script, $self->web_serv_name, $self->app_usr, $self->app_serv_ip, "stop");

       $instance = $self->instance_url;

       # Due to fire wall rules, wget on Staging/Production servers' DNS URLs won't work
       # One way to get around this: wget http://localhost:8080/<app_name>/unprotected/login.do
       if ( $self->runtime_env =~ m/staging|prod/i )
       {
          $instance = "http://localhost:8080/" . $self->app_name . "/unprotected/login.do";
       }

       # Pings the staus of the applicationb instance repeatedly until either
       # it's shutdown or timeout after the given time period.
       if ( &waitInstance( $instance, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "application", "shutdown" ) =~ "TIMEOUT" )
       {
           # Sending out failure email and abort deployment if the application instance failed to be shutdwon
           # after certain time--This situation should be rare but if so happen relevant parties will be notified
           # for further investigation...
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "APP_SHUTDOWN_FAILED") );

           &LOG( \*STDERR, "*ERROR* Failed to shutdwon ". $self->instance_name ."'s ". $self->web_serv_name ." process! Please verify. Abort deployment... \n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s ". $self->web_serv_name ." process is shutdown now.\n" );
       $cmd = "echo curr_deploy_state=APP_INSTANCE_SHUTDOWN > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "APP_INSTANCE_SHUTDOWN\n" );
    }

    # If specified, stop LDAP and backup atomatically
    unless( $self->manual_stop_ldap )
    {
       # Whenever we auto stop LDAP, it implies auto-backup & auto-start of LDAP,
       # auto-stop & auto-backup of Intalio, auto-backup of the documents directory
       # and auto-backup of the application database, as LDAP/Intalio/app. DB/documents
       # must be backed up altogether
       manual_start_ldap( $self, 0 );
       manual_bk_ldap( $self, 0 );

       # Some servers such as Ameren, LES, GA Power do not use Intalio
       #manual_stop_intalio( $self, 0 );
       #manual_bk_intalio( $self, 0 );

       #manual_bk_docsdir( $self, 0 );
       #manual_bk_appdb( $self, 0 );

       &LOG(\*STDOUT, "INFO: Shutting down ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .").\n" );

       &processInstanceServProcess( $self->inst_proc_script, "ldap", $self->app_usr, $self->ldap_host, "stop");

       # Pings the staus of the LDAP instance repeatedly until either it's shutdown or
       # timeout after the given time period.
       if ( &waitInstance( $self->ldap_ctl_script, $self->ldap_host, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "ldap", "shutdown" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "LDAP_SHUTDOWN_FAILED") );
           &LOG( \*STDERR, "*ERROR* Failed to shutdwon ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .")! Please verify. Abort deployment...\n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .") is shutdown now.\n" );
       $cmd = "echo curr_deploy_state=LDAP_SHUTDOWN > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "LDAP_SHUTDOWN\n" );
    }

    # If specified, stop Intalio and backup atomatically
    unless( $self->manual_stop_intalio )
    {
       # Since the LDAP case already handle beforehand, now whenever we auto stop Intalio,
       # it implies auto-start & auto-backup of Intalio, auto-backup of the documents dir
       # and auto-backup of the application database, as LDAP/Intalio/app. DB/documents
       # must be backed up altogether
       manual_start_intalio( $self, 0 );
       manual_bk_intalio( $self, 0 );

       #manual_bk_docsdir( $self, 0 );
       #manual_bk_appdb( $self, 0 );

       &LOG(\*STDOUT, "INFO: Shutting down ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ".$self->integration_ip_internal. ").\n");
       &processInstanceServProcess( $self->inst_proc_script, "intalio", $self->app_usr, $self->integration_ip_internal, "stop");

       # Pings the staus of the Intalio instance repeatedly until either it's shutdown or timeout after the given time period.
       if ( &waitInstance( $self->intalio_ctl_script, $self->integration_ip_internal, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "intalio", "shutdown" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "Intalio_SHUTDOWN_FAILED") );
           &LOG( \*STDERR, "*ERROR* Failed to shutdwon ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ".$self->integration_ip_internal. ")! Please verify. Abort deployment... \n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ".$self->integration_ip_internal. ") is shutdown now.\n" );
       $cmd = "echo curr_deploy_state=INTALIO_SHUTDOWN > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "INTALIO_SHUTDOWN\n" );
    }

    # If specified, stop Jasper and backup atomatically
    unless( $self->manual_stop_jasper )
    {
       manual_start_jasper( $self, 0 );
       manual_bk_jasper( $self, 0 );

       &LOG(\*STDOUT, "INFO: Shutting down ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .").\n" );

       # The Jasper start/stop control script shutdown both tomcat & postgresql by default, but the Jasper backup script
       # require postgresql to be running, so for backup purpose, one should only shutdown tomcat
       &processInstanceServProcess( $self->inst_proc_script, "jasper-tomcat", $self->app_usr, $self->jasper_hostname, "stop");

       # Pings the staus of the Jasper instance repeatedly until either it's shutdown or timeout after the given time period.
       if ( &waitInstance( $self->jasper_ctl_script, $self->jasper_hostname, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "jasper-tomcat", "shutdown" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "Jasper_SHUTDOWN_FAILED") );
           &LOG( \*STDERR,  "*ERROR* Failed to shutdwon ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .")! Please verify. Abort deployment... \n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .") is shutdown now.\n" );
       $cmd = "echo curr_deploy_state=JASPER_SHUTDOWN > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "JASPER_SHUTDOWN\n" );
    }

    # If specified, switch off rtvscand atomatically
    unless( $self->manual_switchoff_rtvscand )
    {
       # If specified to atomatically switch off rtvscand, then we should atomatically switch on rtvscand
       manual_switchon_rtvscand( $self, 0 );

       &LOG(\*STDOUT, "INFO: Switching off rtvscand.\n" );

       &processInstanceServProcess( $self->inst_proc_script, "rtvscand", $self->app_usr, $self->app_serv_ip, "stop");

       # Pings the staus of rtvscand repeatedly until either it's switched off or timeout after the given time period.
       if ( &waitInstance( $self->rtvscand_ctl_script, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "rtvscand", "shutdown" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "rtvscand_SWITCH-OFF_FAILED") );
           &LOG( \*STDERR,  "*WARNING* Failed to switch off rtvscand! Deployment will go on although it will be taking longer time to complete due to the virus scan but please verify and fix it.\n" );
           #exit(1);
       }

       &LOG( \*STDOUT, "INFO: rtvscand is switched off now.\n" );
       $cmd = "echo curr_deploy_state=rtvscand_SWITCHED-OFF > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "rtvscand_SWITCHED-OFF\n" );
    }

    # Trigger another build--This is ONLY used when we also need to trigger another build during a deployment
    # (Currently, This is for deploying a CMS build along # with a Tradeally deployment)
    if ( ($self->app_name =~ "tradeally") && ($self->trigger_other_build =~ "cms") && ($self->runtime_env =~ /qa|dev/) )
    {
       &triggerBuild($self);
    }

    # If specified, back up the application database
    unless( $self->manual_bk_appdb )
    {
       &LOG( \*STDOUT, "INFO: Backing up ". $self->instance_name ."'s application database.\n" );

       # Since DB backup usually takes the longerest time to complete, it will be done in the background process
       # so that other backup tasks for LDAP, Intalio, etc can be done concurrently
       &backupDB( $self->db_bk_script, $self->db_type, $self->db_usr, $self->db_passwd, $self->db_host, $self->db_name, $self->db_bkdir, "preinstall" );
    }

    # If specified, back up the LDAP
    unless( $self->manual_bk_ldap )
    {
       &LOG( \*STDOUT, "INFO: Backing up ". $self->instance_name ."'s LDAP instance.\n" );
       $cmd = "sudo " . $self->ldap_bk_script;
       &execCmd( "$cmd" );
       &LOG( \*STDOUT, "INFO: Completed backing up ". $self->instance_name ."'s LDAP instance.\n" );
    }

    # If specified, back up the Intalio
    unless( $self->manual_bk_intalio )
    {
       &LOG( \*STDOUT, "INFO: Backing up ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ". $self->integration_ip_internal .").\n" );
       # The "-t -t" option somehow does not work well with Intalio (see SCM-3663)
       #$cmd = "ssh -t -t -i /home/" . $self->app_usr . "/.ssh/id_rsa_" . $self->app_usr . " " . $self->app_usr ."@" . $self->integration_ip_internal ." sudo " . $self->intalio_bk_script;
       #$cmd = "ssh -i /home/" . $self->app_usr . "/.ssh/id_rsa_" . $self->app_usr . " " . $self->app_usr ."@" . $self->integration_ip_internal ." sudo " . $self->intalio_bk_script;
       $cmd = "ssh " . $self->app_usr ."@" . $self->integration_ip_internal ." sudo " . $self->intalio_bk_script;

       &execCmd( "$cmd" );
       &LOG( \*STDOUT, "INFO: Completed backing up ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ". $self->integration_ip_internal .").\n" );
    }

    # If specified, back up the documents directory
    unless( $self->manual_bk_docsdir )
    {
       &backupDocsDir($self);
    }

    # If specified, back up the Jasper
    unless( $self->manual_bk_jasper )
    {
       &LOG( \*STDOUT, "INFO: Backing up ". $self->instance_name ."'s Jasper instance.\n" );
       $cmd = "sudo " . $self->jasper_bk_script;
       &execCmd( "$cmd" );
       &LOG( \*STDOUT, "INFO: Completed backing up ". $self->instance_name ."'s Jasper instanc.\n" );
    }

    # Now that all other backups are completed, it's time to check the application DB backup status
    unless( $self->manual_bk_appdb )
    {
       # For DB backup, the longest time is ~30 minutes so far, so set the max. wait time to one hour
       # but we'll need to revisit this from time to time as database size grows
       my $maxPingTries = $self->max_ping_tries * 4;
       my $bk_status = &waitDBbackup($self->db_bk_status_file, $maxPingTries, $self->sleep_time);
       switch( $bk_status )
       {
          case "DB_BK_SUCCEED"
          {
              &LOG( \*STDOUT, "INFO: Completed backing up ". $self->instance_name ."'s application database.\n\n" );
          }
          case "DB_BK_FAILED"
          {
              my $fd = &openFile( $self->db_bk_stderr_file, "<" );
              my @errMsg = <$fd>;
              $msg = "Failed to backup ". $self->instance_name ."'s application database due to the following error:";
              &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Failed to backup application database!",
                 $msg . "<br><br><b><font color=#ff0000>" . @errMsg . "</b></font>");
              &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
              print "*******************************************************************************************************\n";
              print "@errMsg\n";
              print "*******************************************************************************************************\n";
              exit(1);
          }
          case "NO_BACKUP_PROG"
          {
              $msg = "Unable to backup ". $self->instance_name ."'s application database due to the database backup program is missing!";
              &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Unable to backup application database!", $msg );
              &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
              exit(1);
          }
          case "TIMEOUT"
          {
              $msg = "Timeout backing up ". $self->instance_name ."'s application database as it was taking longer than expected time! Please verify.";
              &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Timeout backing up application database!", $msg );
              &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
              exit(1);
          }
       }
    }

    &LOG(\*STDOUT, "INFO: Start installing the artifact/war-file.\n");

    # Install the artifact
    &installArtifact($self);

    # If specified, start up LDAP atomatically
    unless( $self->manual_start_ldap )
    {
       &LOG(\*STDOUT, "INFO: Starting up ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .").\n");
       &processInstanceServProcess( $self->inst_proc_script, "ldap", $self->app_usr, $self->ldap_host, "start");

       # Pings the staus of the LDAP instance repeatedly until either
       # it's startup or timeout after the given time period.
       if ( &waitInstance( $self->ldap_ctl_script, $self->ldap_host, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "ldap", "startup" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "LDAP_STARTUP_FAILED") );
           &LOG( \*STDERR, "*ERROR* Failed to startup ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .")! Please verify. Abort deployment...\n\n", $self->ldap_ctl_script );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s LDAP instance (on ". $self->ldap_host .") is startup now.\n" );
       $cmd = "echo curr_deploy_state=LDAP_STARTUP > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "LDAP_STARTUP\n" );
    }

    # If specified, start up Intalio atomatically
    unless( $self->manual_start_intalio )
    {
       &LOG(\*STDOUT, "INFO: Starting up ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ". $self->integration_ip_internal .").\n");
       &processInstanceServProcess( $self->inst_proc_script, "intalio", $self->app_usr, $self->integration_ip_internal, "start");

       # Pings the staus of the Intalio instance repeatedly until either
       # it's startup or timeout after the given time period.
       if ( &waitInstance( $self->intalio_ctl_script, $self->integration_ip_internal, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "intalio", "startup" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "Intalio_STARTUP_FAILED") );
           &LOG( \*STDERR, "*ERROR* Failed to startup ". $self->instance_name ."'s Intalio instance remotely on ". $self->integration_host ." (IP: ".$self->integration_ip_internal .")! Please verify. Abort deployment...\n\n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s Intalio instance on ". $self->integration_host ." (IP: ". $self->integration_ip_internal .") is startup now.\n" );
       $cmd = "echo curr_deploy_state=INTALIO_STARTUP > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "INTALIO_STARTUP\n" );
    }

    # If specified, start up Jasper atomatically
    unless( $self->manual_start_jasper )
    {
       &LOG(\*STDOUT, "INFO: Starting up ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .").\n");
       &processInstanceServProcess( $self->inst_proc_script, "jasper-tomcat", $self->app_usr, $self->jasper_hostname, "start");

       # Pings the staus of the Jasper instance repeatedly until either
       # it's startup or timeout after the given time period.
       if ( &waitInstance( $self->jasper_ctl_script, $self->jasper_hostname, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "jasper-tomcat", "startup" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "Jasper_STARTUP_FAILED") );
           &LOG( \*STDERR, "*ERROR* Failed to startup ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .")! Please verify. Abort deployment...\n\n" );
           exit(1);
       }

       &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s Jasper tomcat process (on ". $self->jasper_hostname .") is startup now.\n" );
       $cmd = "echo curr_deploy_state=JASPER_STARTUP > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "JASPER_STARTUP\n" );
    }

    # Automatically stop the application instance as needed, unless it's specified
    # to manually stop the application instance (This should be rare -- One example
    # would be when we're deploying a CMS build together with Tradeally in which
    # the application instance should only be started after both CMS & Tradeally
    # builds have already been deployed to the same webapps directory on the same VM)
    unless( $self->manual_start_appInst )
    {
       &LOG(\*STDOUT, "INFO: Starting up ". $self->instance_name ."(IP: ". $self->app_serv_ip . ")'s ". $self->app_name ."/". $self->web_serv_name ." process.\n");

       # Start up the specific application instance
       &processInstanceServProcess( $self->inst_proc_script, $self->web_serv_name, $self->app_usr, $self->app_serv_ip, "start");

       &LOG( \*STDOUT, "INFO: Ping'ing the startup status of ". $self->instance_name ."'s ". $self->web_serv_name ." instance: ". $self->instance_url ."\n");

       $instance = $self->instance_url;

       # Due to fire wall rules, wget on Staging/Production servers' DNS URLs won't work
       # One way to get around this: wget http://localhost:8080/<app_name>/unprotected/login.do
       if ( $self->runtime_env =~ m/staging|prod/i )
       {
          $instance = "http://localhost:8080/" . $self->app_name . "/unprotected/login.do";
       }

       # Pings the staus of the applicationb instance repeatedly until either
       # it's shutdown or timeout after the given time period.
       if ( &waitInstance( $instance, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "application", "startup" ) =~ "TIMEOUT" )
       {
           # Sending out failure email and abort deployment if the application instance
           # failed to start after certain time--This will usually be caused by some
           # application-related exceptions/errors, database connection timeout during
           # application start-up, or application taking longer than maximum wait time
           # (i.e. 15 minutes) to start up
           &sendEmail( $self->email_to_list, $self->email_cc_list, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "APP_STARTUP_FAILED") );

           &LOG( \*STDERR, "*ERROR* Failed to start up ". $self->instance_name ."'s ". $self->web_serv_name ." instance. Please verify. Abort deployment...\n\n" );
           exit(1);
       }
    }

    # If specified, switch on rtvscand atomatically
    unless( $self->manual_switchon_rtvscand )
    {
       &LOG(\*STDOUT, "INFO: Switching on rtvscand.\n" );

       &processInstanceServProcess( $self->inst_proc_script, "rtvscand", $self->app_usr, $self->app_serv_ip, "start");

       # Pings the staus of rtvscand repeatedly until either it's stopped or timeout after the given time period.
       if ( &waitInstance( $self->rtvscand_ctl_script, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "rtvscand", "startup" ) =~ "TIMEOUT" )
       {
           &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "rtvscand_SWITCH-ON_FAILED") );
           &LOG( \*STDERR,  "*WARNING* Failed to switch on rtvscand! Deployment will go on but please verify and fix it.\n" );
           #exit(1);
       }

       &LOG( \*STDOUT, "INFO: rtvscand is switched back on now.\n" );
       $cmd = "echo curr_deploy_state=rtvscand_SWITCHED-ON > " . $self->deploy_state_file;
       &execCmd( "$cmd" );

       # Update the deployment state file accordingly
       curr_deploy_state( $self, "rtvscand_SWITCHED-ON\n" );
    }

    &LOG(\*STDOUT, "INFO: Deployment of " . $self->build_job . " build #" . $self->build_num . " to the " .$self->instance_name . " (IP: " . $self->app_serv_ip . ") server is COMPLETED SUCCESSFULLY.\n");

    # Only handle email notification situation when the relevant flag is set (to TRUE).
    # Currently, the flag is only set to FALSE when we're deploying CMS together with
    # TradeAlly
    if ( $self->do_email_notification )
    {
       &LOG(\*STDOUT, "INFO: Sending completion email to " . $self->email_to_list . " " . $self->email_cc_list .".\n");

       # Send deployement done email
       &sendEmail( $self->email_to_list, $self->email_cc_list, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num,, "DEPLOY-DONE") ) if ( $self->trigger_other_build =~ "NONE" );
    }

    # Remove the deployment state file
    &removeFile( $self->deploy_state_file ) if( -r $self->deploy_state_file );
}


##############################################################
# Method to set/get the maximum number of tries on ping'ing an
# application instance.
#
# If a maximum number of tries is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub max_ping_tries
{
   my ($self, $max_ping_tries) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called max_ping_tries() with a class! Please cal with an object instead.";
   }

   $self->{_max_ping_tries} = $max_ping_tries if defined( $max_ping_tries ) && $max_ping_tries;
   return( $self->{_max_ping_tries} );
}

##############################################################
# Method to set/get the number of seconds to sleep
#
# If a number of seconds to sleep is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub sleep_time
{
   my ($self, $sleep_time) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called sleep_time() with a class! Please cal with an object instead.";
   }

   $self->{_sleep_time} = $sleep_time if defined( $sleep_time ) && $sleep_time;
   return( $self->{_sleep_time} );
}

##############################################################
# Method to set/get the path of the deployment state file
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub deploy_state_file
{
   my ($self, $deploy_state_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called deploy_state_file() with a class! Please cal with an object instead.";
   }

   $self->{_deploy_state_file} = $deploy_state_file if defined( $deploy_state_file ) && $deploy_state_file;
   return( $self->{_deploy_state_file} );
}

##############################################################
# Method to set/get the current deployment state.
#
# If a deployment state is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub curr_deploy_state
{
   my ($self, $curr_deploy_state) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called curr_deploy_state() with a class! Please cal with an object instead.";
   }

   $self->{_curr_deploy_state} = $curr_deploy_state if defined( $curr_deploy_state ) && $curr_deploy_state;
   return( $self->{_curr_deploy_state} );
}

##############################################################
# Method to set/get the path of the application instance
# processing ((re)start/stop) script.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub inst_proc_script
{
   my ($self, $inst_proc_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called inst_proc_script() with a class! Please cal with an object instead.";
   }

   $self->{_inst_proc_script} = $inst_proc_script if defined( $inst_proc_script ) && $inst_proc_script;
   return( $self->{_inst_proc_script} );
}

##############################################################
# Method to set/get the path of the DB backup script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_bk_script
{
   my ($self, $db_bk_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_bk_script() with a class! Please cal with an object instead.";
   }

   $self->{_db_bk_script} = $db_bk_script if defined( $db_bk_script ) && $db_bk_script;
   return( $self->{_db_bk_script} );
}

##############################################################
# Method to set/get the web server name.
#
# If a web server name is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub web_serv_name
{
   my ($self, $web_serv_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_name() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_name} = $web_serv_name if defined( $web_serv_name ) && $web_serv_name;
   return( $self->{_web_serv_name} );
}

##############################################################
# Method to set/get the path of the web server (re)start/stop
# script.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub web_serv_script
{
   my ($self, $web_serv_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_script() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_script} = $web_serv_script if defined( $web_serv_script ) && $web_serv_script;
   return( $self->{_web_serv_script} );
}

##############################################################
# Method to set/get the path of the web server config file.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub web_serv_config_file
{
   my ($self, $web_serv_config_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_config_file() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_config_file} = $web_serv_config_file if defined( $web_serv_config_file ) && $web_serv_config_file;
   return( $self->{_web_serv_config_file} );
}

##############################################################
# Method to set/get the path of the LDAP (re)start/stop script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub ldap_ctl_script
{
   my ($self, $ldap_ctl_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called ldap_ctl_script() with a class! Please cal with an object instead.";
   }

   $self->{_ldap_ctl_script} = $ldap_ctl_script if defined( $ldap_ctl_script ) && $ldap_ctl_script;
   return( $self->{_ldap_ctl_script} );
}

##############################################################
# Method to set/get the path of the Intalio (re)start/stop
# script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub intalio_ctl_script
{
   my ($self, $intalio_ctl_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called intalio_ctl_script() with a class! Please cal with an object instead.";
   }

   $self->{_intalio_ctl_script} = $intalio_ctl_script if defined( $intalio_ctl_script ) && $intalio_ctl_script;
   return( $self->{_intalio_ctl_script} );
}

##############################################################
# Method to set/get the path of the Jasper (re)start/stop
# script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub jasper_ctl_script
{
   my ($self, $jasper_ctl_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called jasper_ctl_script() with a class! Please cal with an object instead.";
   }

   $self->{_jasper_ctl_script} = $jasper_ctl_script if defined( $jasper_ctl_script ) && $jasper_ctl_script;
   return( $self->{_jasper_ctl_script} );
}

##############################################################
# Method to set/get the path of the rtvscand (re)start/stop
# script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub rtvscand_ctl_script
{
   my ($self, $rtvscand_ctl_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called rtvscand_ctl_script() with a class! Please cal with an object instead.";
   }

   $self->{_rtvscand_ctl_script} = $rtvscand_ctl_script if defined( $rtvscand_ctl_script ) && $rtvscand_ctl_script;
   return( $self->{_rtvscand_ctl_script} );
}

##############################################################
# Method to set/get the path of the LDAP backup script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub ldap_bk_script
{
   my ($self, $ldap_bk_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called ldap_bk_script() with a class! Please cal with an object instead.";
   }

   $self->{_ldap_bk_script} = $ldap_bk_script if defined( $ldap_bk_script ) && $ldap_bk_script;
   return( $self->{_ldap_bk_script} );
}

##############################################################
# Method to set/get the path of the Intalio backup script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub intalio_bk_script
{
   my ($self, $intalio_bk_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called intalio_bk_script() with a class! Please cal with an object instead.";
   }

   $self->{_intalio_bk_script} = $intalio_bk_script if defined( $intalio_bk_script ) && $intalio_bk_script;
   return( $self->{_intalio_bk_script} );
}

##############################################################
# Method to set/get the path of the Jasper backup script
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub jasper_bk_script
{
   my ($self, $jasper_bk_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called jasper_bk_script() with a class! Please cal with an object instead.";
   }

   $self->{_jasper_bk_script} = $jasper_bk_script if defined( $jasper_bk_script ) && $jasper_bk_script;
   return( $self->{_jasper_bk_script} );
}

##############################################################
# Method to set/get the deployerr email-to list.
#
# If an email-to list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub deployerr_mail_to
{
   my ($self, $deployerr_mail_to) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called deployerr_mail_to() with a class! Please cal with an object instead.";
   }

   $self->{_deployerr_mail_to} = $deployerr_mail_to if defined( $deployerr_mail_to ) && $deployerr_mail_to;
   return( $self->{_deployerr_mail_to} );
}

##############################################################
# Method to set/get the deployerr email-cc list.
#
# If an email-cc list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub deployerr_mail_cc
{
   my ($self, $deployerr_mail_cc) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called deployerr_mail_cc() with a class! Please cal with an object instead.";
   }

   $self->{_deployerr_mail_cc} = $deployerr_mail_cc if defined( $deployerr_mail_cc ) && $deployerr_mail_cc;
   return( $self->{_deployerr_mail_cc} );
}

##############################################################
# Method to set/get the email-to list.
#
# If an email-to list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub email_to_list
{
   my ($self, $email_to_list) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called email_to_list() with a class! Please cal with an object instead.";
   }

   $self->{_email_to_list} = $email_to_list if defined( $email_to_list ) && $email_to_list;
   return( $self->{_email_to_list} );
}

##############################################################
# Method to set/get the email-cc list.
#
# If an email-cc list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub email_cc_list
{
   my ($self, $email_cc_list) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called email_cc_list() with a class! Please cal with an object instead.";
   }

   $self->{_email_cc_list} = $email_cc_list if defined( $email_cc_list ) && $email_cc_list;
   return( $self->{_email_cc_list} );
}

##############################################################
# Method to set/get the application user ID (e.g. traksmart)
# under which the application is running.
#
# If an user ID is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub app_usr
{
   my ($self, $app_usr) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_usr() with a class! Please cal with an object instead.";
   }

   $self->{_app_usr} = $app_usr if defined( $app_usr ) && $app_usr;
   return( $self->{_app_usr} );
}

##############################################################
# Method to set/get the application server IP address on which
# the artifact is to be deployed.
#
# If a application server IP address is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub app_serv_ip
{
   my ($self, $app_serv_ip) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_serv_ip() with a class! Please cal with an object instead.";
   }

   $self->{_app_serv_ip} = $app_serv_ip if defined( $app_serv_ip ) && $app_serv_ip;
   return( $self->{_app_serv_ip} );
}

##############################################################
# Method to set/get the download directory to retrieve the
# artifact for deployment
#
# If a artifact_download_dir is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub artifact_download_dir
{
   my ($self, $artifact_download_dir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called artifact_download_dir() with a class! Please cal with an object instead.";
   }

   $self->{_artifact_download_dir} = $artifact_download_dir if defined( $artifact_download_dir ) && $artifact_download_dir;
   return( $self->{_artifact_download_dir} );
}

##############################################################
# Method to set/get the customer (e.g. CGV, PSEG) that needs
# customizations; default to NONE (i.e. no customizations
# is needed.
#
# If a customer or NONE is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub custom_customer
{
   my ($self, $custom_customer) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called custom_customer() with a class! Please cal with an object instead.";
   }

   $self->{_custom_customer} = $custom_customer if defined( $custom_customer ) && $custom_customer;
   return( $self->{_custom_customer} );
}

##############################################################
# Method to set/get the trigger_other_build value based on the
# need whether to trigger another build during a deployment
# (Currently, This is for deploying a CMS build along with a
# Tradeally deployment. Default value is NONE (i.e. Do not
# trigger another build).
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub trigger_other_build
{
   my ($self, $trigger_other_build) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called trigger_other_build() with a class! Please cal with an object instead.";
   }

   $self->{_trigger_other_build} = $trigger_other_build if defined( $trigger_other_build ) && $trigger_other_build;
   return( $self->{_trigger_other_build} );
}

##############################################################
# Method to set/get the do_email_notification flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub do_email_notification
{
   my ($self, $do_email_notification) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called do_email_notification() with a class! Please cal with an object instead.";
   }

   $self->{_do_email_notification} = $do_email_notification if defined( $do_email_notification ) && $do_email_notification;
   return( $self->{_do_email_notification} );
}

##############################################################
# Method to set/get the manual_stop_appInst flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_stop_appInst
{
   my ($self, $manual_stop_appInst) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_stop_appInst() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_stop_appInst} = $manual_stop_appInst if defined( $manual_stop_appInst );
   return( $self->{_manual_stop_appInst} );
}

##############################################################
# Method to set/get the manual_start_appInst flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_start_appInst
{
   my ($self, $manual_start_appInst) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_start_appInst() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_start_appInst} = $manual_start_appInst if defined( $manual_start_appInst );
   return( $self->{_manual_start_appInst} );
}

##############################################################
# Method to set/get the manual_stop_intalio flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_stop_intalio
{
   my ($self, $manual_stop_intalio) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_stop_intalio() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_stop_intalio} = $manual_stop_intalio if defined( $manual_stop_intalio );
   return( $self->{_manual_stop_intalio} );
}

##############################################################
# Method to set/get the manual_start_intalio flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_start_intalio
{
   my ($self, $manual_start_intalio) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_start_intalio() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_start_intalio} = $manual_start_intalio if defined( $manual_start_intalio );
   return( $self->{_manual_start_intalio} );
}

##############################################################
# Method to set/get the manual_stop_jasper flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_stop_jasper
{
   my ($self, $manual_stop_jasper) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_stop_jasper() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_stop_jasper} = $manual_stop_jasper if defined( $manual_stop_jasper );
   return( $self->{_manual_stop_jasper} );
}

##############################################################
# Method to set/get the manual_start_jasper flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_start_jasper
{
   my ($self, $manual_start_jasper) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_start_jasper() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_start_jasper} = $manual_start_jasper if defined( $manual_start_jasper );
   return( $self->{_manual_start_jasper} );
}

##############################################################
# Method to set/get the manual_stop_ldap flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_stop_ldap
{
   my ($self, $manual_stop_ldap) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_stop_ldap() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_stop_ldap} = $manual_stop_ldap if defined( $manual_stop_ldap );
   return( $self->{_manual_stop_ldap} );
}

##############################################################
# Method to set/get the manual_start_ldap flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_start_ldap
{
   my ($self, $manual_start_ldap) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_start_ldap() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_start_ldap} = $manual_start_ldap if defined( $manual_start_ldap );
   return( $self->{_manual_start_ldap} );
}

##############################################################
# Method to set/get the manual_switchoff_rtvscand flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_switchoff_rtvscand
{
   my ($self, $manual_switchoff_rtvscand) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_switchoff_rtvscand() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_switchoff_rtvscand} = $manual_switchoff_rtvscand if defined( $manual_switchoff_rtvscand );
   return( $self->{_manual_switchoff_rtvscand} );
}

##############################################################
# Method to set/get the manual_switchon_rtvscand flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_switchon_rtvscand
{
   my ($self, $manual_switchon_rtvscand) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_switchon_rtvscand() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_switchon_rtvscand} = $manual_switchon_rtvscand if defined( $manual_switchon_rtvscand );
   return( $self->{_manual_switchon_rtvscand} );
}

##############################################################
# Method to set/get the manual_bk_ldap flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_bk_ldap
{
   my ($self, $manual_bk_ldap) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_bk_ldap() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_bk_ldap} = $manual_bk_ldap if defined( $manual_bk_ldap );
   return( $self->{_manual_bk_ldap} );
}

##############################################################
# Method to set/get the manual_bk_intalio flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_bk_intalio
{
   my ($self, $manual_bk_intalio) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_bk_intalio() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_bk_intalio} = $manual_bk_intalio if defined( $manual_bk_intalio );
   return( $self->{_manual_bk_intalio} );
}

##############################################################
# Method to set/get the manual_bk_jasper flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_bk_jasper
{
   my ($self, $manual_bk_jasper) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_bk_jasper() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_bk_jasper} = $manual_bk_jasper if defined( $manual_bk_jasper );
   return( $self->{_manual_bk_jasper} );
}

##############################################################
# Method to set/get the manual_bk_docsdir flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_bk_docsdir
{
   my ($self, $manual_bk_docsdir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_bk_docsdir() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_bk_docsdir} = $manual_bk_docsdir if defined( $manual_bk_docsdir );
   return( $self->{_manual_bk_docsdir} );
}

##############################################################
# Method to set/get the manual_bk_appdb flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub manual_bk_appdb
{
   my ($self, $manual_bk_appdb) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called manual_bk_appdb() with a class! Please cal with an object instead.";
   }

   # The number 0 is actually defined value (i.e. not undef) in Perl
   $self->{_manual_bk_appdb} = $manual_bk_appdb if defined( $manual_bk_appdb );
   return( $self->{_manual_bk_appdb} );
}

##############################################################
# Method to set/get the application name (e.g. traksmart4).
#
# If an application name is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub app_name
{
   my ($self, $app_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_name() with a class! Please cal with an object instead.";
   }

   $self->{_app_name} = $app_name if defined( $app_name ) && $app_name;
   return( $self->{_app_name} );
}

##############################################################
# Method to set/get the artifact name (e.g. traksmart4.war).
#
# If an artifact name is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub artifact_name
{
   my ($self, $artifact_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called artifact_name() with a class! Please cal with an object instead.";
   }

   $self->{_artifact_name} = $artifact_name if defined( $artifact_name ) && $artifact_name;
   return( $self->{_artifact_name} );
}

##############################################################
# Method to set/get the artifact directory (e.g. traksmart4)
# sitting under the JETTY_HOME/webapps directory.
#
# If an artifact directory is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub artifact_dir
{
   my ($self, $artifact_dir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called artifact_dir() with a class! Please cal with an object instead.";
   }

   $self->{_artifact_dir} = $artifact_dir if defined( $artifact_dir ) && $artifact_dir;
   return( $self->{_artifact_dir} );
}

##############################################################
# Method to set/get the (QA/Demo/Staging/Production) instance
# URL.
#
# If an instance URL is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub instance_url
{
   my ($self, $instance_ln) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called instance_url() with a class! Please cal with an object instead.";
   }


   my $dummy;
   if ( defined($instance_ln) && $instance_ln )
   {
       $instance_ln = &trim($instance_ln);
       ($self->{_instance_url}, $dummy) = split( ';', $instance_ln );
   }
   return( $self->{_instance_url} );
}

##############################################################
# Method to set/get the (QA/Demo/Staging/Production) instance
# name.
#
# If an instance name is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub instance_name
{
   my ($self, $instance_ln) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called instance_name() with a class! Please cal with an object instead.";
   }


   my $dummy;
   if ( defined($instance_ln) && $instance_ln )
   {
       $instance_ln = &trim($instance_ln);
       ($dummy, $self->{_instance_name}) = split( ';', $instance_ln );
   }
   return( $self->{_instance_name} );
}

##############################################################
# Method to set/get the nexant_app_home path (under which the
# application.properties is located).
#
# If a nexant_app_home path is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub nexant_app_home
{
   my ($self, $nexant_app_home) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called nexant_app_home() with a class! Please cal with an object instead.";
   }

   $self->{_nexant_app_home} = $nexant_app_home if defined( $nexant_app_home ) && $nexant_app_home;
   return( $self->{_nexant_app_home} );
}

##############################################################
# Method to set/get the runtime_env (e.g. qa, staging, etc)
# as specified in the "-Druntime.environment=" JAVA_OPTIONS.
#
# If a runtime_env is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub runtime_env
{
   my ($self, $runtime_env) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called runtime_env() with a class! Please cal with an object instead.";
   }

   $self->{_runtime_env} = $runtime_env if defined( $runtime_env ) && $runtime_env;
   return( $self->{_runtime_env} );
}

##############################################################
# Method to set/get the web server home.
#
# If a web server home is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub web_serv_home
{
   my ($self, $web_serv_home) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_home() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_home} = $web_serv_home if defined( $web_serv_home ) && $web_serv_home;
   return( $self->{_web_serv_home} );
}

##############################################################
# Method to set/get the path of application.properties file.
#
# If an application.properties file is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub app_prop_file
{
   my ($self, $app_prop_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_prop_file() with a class! Please cal with an object instead.";
   }

   $self->{_app_prop_file} = $app_prop_file if defined( $app_prop_file ) && $app_prop_file;
   return( $self->{_app_prop_file} );
}

##############################################################
# Method to set/get the integration/Intalio host.
#
# If an integration/Intalio host is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub integration_host
{
   my ($self, $integration_host) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called integration_host() with a class! Please cal with an object instead.";
   }

   $self->{_integration_host} = $integration_host if defined( $integration_host ) && $integration_host;
   return( $self->{_integration_host} );
}

##############################################################
# Method to set/get the integration/Intalio host IP address
#
# If an integration/Intalio host IP is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub integration_ip_internal
{
   my ($self, $integration_ip_internal) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called integration_ip_internal() with a class! Please cal with an object instead.";
   }

   $self->{_integration_ip_internal} = $integration_ip_internal if defined( $integration_ip_internal ) && $integration_ip_internal;
   return( $self->{_integration_ip_internal} );
}

##############################################################
# Method to set/get the jasper hostname.
#
# If a jasper hostname is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub jasper_hostname
{
   my ($self, $jasper_hostname) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called jasper_hostname() with a class! Please cal with an object instead.";
   }

   $self->{_jasper_hostname} = $jasper_hostname if defined( $jasper_hostname ) && $jasper_hostname;
   return( $self->{_jasper_hostname} );
}

##############################################################
# Method to set/get the ldap host.
#
# If a ldap host is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub ldap_host
{
   my ($self, $ldap_host) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called ldap_host() with a class! Please cal with an object instead.";
   }

   $self->{_ldap_host} = $ldap_host if defined( $ldap_host ) && $ldap_host;
   return( $self->{_ldap_host} );
}

##############################################################
# Method to set/get the db type.
#
# If a db type is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_type
{
   my ($self, $db_type) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_type() with a class! Please cal with an object instead.";
   }

   $self->{_db_type} = $db_type if defined( $db_type ) && $db_type;
   return( $self->{_db_type} );
}

##############################################################
# Method to set/get the db host.
#
# If a db host is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_host
{
   my ($self, $db_host) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_host() with a class! Please cal with an object instead.";
   }

   $self->{_db_host} = $db_host if defined( $db_host ) && $db_host;
   return( $self->{_db_host} );
}

##############################################################
# Method to set/get the db port.
#
# If a db port is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_port
{
   my ($self, $db_port) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_port() with a class! Please cal with an object instead.";
   }

   $self->{_db_port} = $db_port if defined( $db_port ) && $db_port;
   return( $self->{_db_port} );
}

##############################################################
# Method to set/get the db name.
#
# If a db name is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_name
{
   my ($self, $db_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_name() with a class! Please cal with an object instead.";
   }

   $self->{_db_name} = $db_name if defined( $db_name ) && $db_name;
   return( $self->{_db_name} );
}

##############################################################
# Method to set/get the db usr.
#
# If a db usr is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_usr
{
   my ($self, $db_usr) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_usr() with a class! Please cal with an object instead.";
   }

   $self->{_db_usr} = $db_usr if defined( $db_usr ) && $db_usr;
   return( $self->{_db_usr} );
}

##############################################################
# Method to set/get the db passwd.
#
# If a db passwd is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub db_passwd
{
   my ($self, $db_passwd) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_passwd() with a class! Please cal with an object instead.";
   }

   $self->{_db_passwd} = $db_passwd if defined( $db_passwd ) && $db_passwd;
   return( $self->{_db_passwd} );
}

##############################################################
# Method to set/get the path of db backup directory.
#
# If a db backup directory is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub db_bkdir
{
   my ($self, $db_bkdir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_bkdir() with a class! Please cal with an object instead.";
   }

   $self->{_db_bkdir} = $db_bkdir if defined( $db_bkdir ) && $db_bkdir;
   return( $self->{_db_bkdir} );
}

##############################################################
# Method to set/get the path of ldap full backup directory.
#
# If a ldap full backup directory is given, set the value;
# otherwise, just returns the existing data.
##############################################################
sub ldap_full_bkdir
{
   my ($self, $ldap_full_bkdir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called ldap_full_bkdir() with a class! Please cal with an object instead.";
   }

   $self->{_ldap_full_bkdir} = $ldap_full_bkdir if defined( $ldap_full_bkdir ) && $ldap_full_bkdir;
   return( $self->{_ldap_full_bkdir} );
}

##############################################################
# Method to set/get the path of db backup status file.
#
# If a db backup status file is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub db_bk_status_file
{
   my ($self, $db_bk_status_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_bk_status_file() with a class! Please cal with an object instead.";
   }

   $self->{_db_bk_status_file} = $db_bk_status_file if defined( $db_bk_status_file ) && $db_bk_status_file;
   return( $self->{_db_bk_status_file} );
}

##############################################################
# Method to set/get the path of db backup stderr file.
#
# If a db backup stderr file is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub db_bk_stderr_file
{
   my ($self, $db_bk_stderr_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called db_bk_stderr_file() with a class! Please cal with an object instead.";
   }

   $self->{_db_bk_stderr_file} = $db_bk_stderr_file if defined( $db_bk_stderr_file ) && $db_bk_stderr_file;
   return( $self->{_db_bk_stderr_file} );
}

##############################################################
# Prints the Release object info
##############################################################
sub print_info
{
   my $self = shift;

   $self->SUPER::print_info();

   printf( "app_usr: '%s'\napp_serv_ip: '%s'\ncustom_customer: '%s'\napp_name: '%s'\nartifact_name: '%s'\nartifact_dir: '%s'\ninstance_url: '%s'\ninstance_name: '%s'\nweb_serv_name: '%s'\nweb_serv_home: '%s'\nnexant_app_home: '%s'\nruntime_env: '%s'\nweb_serv_script: '%s'\nweb_serv_config_file: '%s'\ninst_proc_script: '%s'\ndb_bk_script: '%s'\nldap_ctl_script: '%s'\nintalio_ctl_script: '%s'\njasper_ctl_script: '%s'\nldap_bk_script: '%s'\nintalio_bk_script: '%s'\njasper_bk_script: '%s'\nartifact_download_dir: '%s'\napp_prop_file: '%s'\n(Intalio) integration_host: '%s'\n(Intalio) integration_ip_internal: '%s'\njasper_hostname: '%s'\nldap_host: '%s'\ndb_type: '%s'\ndb_host: '%s'\ndb_port: '%s'\ndb_name: '%s'\ndb_usr: '%s'\ndb_passwd: '%s'\ndb_bkdir: '%s'\ndb_bk_status_file: '%s'\ndb_bk_stderr_file: '%s'\nldap_full_bkdir: '%s'\ndeploy_state_file: '%s'\ntrigger_other_build: '%s'\ndo_email_notification: '%s'\nmanual_stop_appInst: '%s'\nmanual_start_appInst: '%s'\nmanual_stop_intalio: '%s'\nmanual_start_intalio: '%s'\nmanual_stop_jasper: '%s'\nmanual_start_jasper: '%s'\nmanual_stop_ldap: '%s'\nmanual_start_ldap: '%s'\nmanual_switchoff_rtvscand: '%s'\nmanual_switchon_rtvscand: '%s'\nmanual_bk_ldap: '%s'\nmanual_bk_intalio: '%s'\nmanual_bk_jasper: '%s'\nmanual_bk_docsdir: '%s'\nmanual_bk_appdb: '%s'\nmax_ping_tries: %d\nsleep_time: %d\n", $self->app_usr, $self->app_serv_ip, $self->custom_customer, $self->app_name, $self->artifact_name, $self->artifact_dir, $self->instance_url, $self->instance_name, $self->web_serv_name, $self->web_serv_home, $self->nexant_app_home, $self->runtime_env, $self->web_serv_script, $self->web_serv_config_file, $self->inst_proc_script, $self->db_bk_script, $self->ldap_ctl_script, $self->intalio_ctl_script, $self->jasper_ctl_script, $self->ldap_bk_script, $self->intalio_bk_script, $self->jasper_bk_script, $self->artifact_download_dir, $self->app_prop_file, $self->integration_host, $self->integration_ip_internal, $self->jasper_hostname, $self->ldap_host, $self->db_type, $self->db_host, $self->db_port, $self->db_name, $self->db_usr, '******', $self->db_bkdir, $self->db_bk_status_file, $self->db_bk_stderr_file, $self->ldap_full_bkdir, $self->deploy_state_file, $self->trigger_other_build, $self->do_email_notification ? 'TRUE' : 'FALSE', $self->manual_stop_appInst ? 'TRUE' : 'FALSE', $self->manual_start_appInst ? 'TRUE' : 'FALSE', $self->manual_stop_intalio ? 'TRUE' : 'FALSE', $self->manual_start_intalio ? 'TRUE' : 'FALSE', $self->manual_stop_jasper ? 'TRUE' : 'FALSE', $self->manual_start_jasper ? 'TRUE' : 'FALSE', $self->manual_stop_ldap ? 'TRUE' : 'FALSE', $self->manual_start_ldap ? 'TRUE' : 'FALSE', $self->manual_switchoff_rtvscand ? 'TRUE' : 'FALSE', $self->manual_switchon_rtvscand ? 'TRUE' : 'FALSE', $self->manual_bk_ldap ? 'TRUE' : 'FALSE',  $self->manual_bk_intalio ? 'TRUE' : 'FALSE',  $self->manual_bk_jasper ? 'TRUE' : 'FALSE', $self->manual_bk_docsdir ? 'TRUE' : 'FALSE', $self->manual_bk_appdb ? 'TRUE' : 'FALSE', $self->max_ping_tries, $self->sleep_time );
}

1;



