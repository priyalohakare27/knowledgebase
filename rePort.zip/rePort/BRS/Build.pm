package BRS::Build; # Base class for Build related functionalities

use strict;
use warnings;
use BRS;
our @ISA = qw(BRS);

use BRS::Utils;


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class) = shift;

  my $self = $class->SUPER::new( @_ ); 

  $self->init( @_ );

  bless( $self, $class );

  return( $self );
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Check/enforce mandatory options as Getopt::Long::GetOptions doesn't 
   # do so -- That's why it's called GetOptions??
   Usage( "\n***ERROR: The Subversion repository path is missing***\n" ) unless defined( $args->{svn_repo_path} );
   Usage( "\n***ERROR: The Subversion transaction ID is missing***\n" ) unless defined( $args->{svn_txn_id} );

   # Initialize common build/release data through the parent class 
   $self->SUPER::init( $args );

   # Set the data specific to this Build object 
   # with the ones specified on the command-line   
   svn_repo_path($self, $args->{svn_repo_path} );
   svn_txn_id($self, $args->{svn_txn_id} );
}

##############################################################
# Method to set/get the Subversion repository path.  
#
# If a Subversion repository path is given, set the value; 
# otherwise just returns the existing data.
##############################################################
sub svn_repo_path
{
   my ($self, $svn_repo_path) = @_;
   $self->{_svn_repo_path} = $svn_repo_path if defined( $svn_repo_path );
   return( $self->{_svn_repo_path} );
}

##############################################################
# Method to set/get the Subversion transaction ID.  
#
# If a Subversion transaction ID is given, set the value; 
# otherwise just returns the existing data.
##############################################################
sub svn_txn_id
{
   my ($self, $svn_txn_id) = @_;
   $self->{_svn_txn_id} = $svn_txn_id if defined( $svn_txn_id );
   return( $self->{_svn_txn_id} );
}

##############################################################
# Prints the Build object info
##############################################################
sub print_info
{
   my $self = shift;

   $self->SUPER::print_info();
   printf( "svn_repo_path: '%s'\nsvn_txn_id: '%s'\n", $self->svn_repo_path, $self->svn_txn_id);
}

1;
