#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <SERV_NAME> <APP_USR> <APP_SERV_IP> <ACTION> [VERSION]"
   echo ""
   echo "   where"
   echo ""
   echo "        <SERV_NAME>   : The name of a server process--One of jetty, tomcat, ldap,"
   echo "                        intalio (cloud) & jasper--to be start/stop/restart"
   echo ""
   echo "        <APP_USR>     : The user name (e.g. traksmart) under which the application is running"
   echo ""
   echo "        <APP_SERV_IP> : The IP address of an instances--This is used for the situation"
   echo "                        that multiple instances are running on the same machine"
   echo "                        (e.g. QA .210 & .217) that their startup scripts are named"
   echo "                        by an IP address file extension"
   echo ""
   echo "        <ACTION>      : One of the following actions:"
   echo ""
   echo "           stop    -- stops the application (e.g. traksmart4, dr360, etc) instance"
   echo "           start   -- starts the application (e.g. traksmart4, dr360, etc) instance"
   echo "           restart -- restarts (stop&start)the application (e.g. traksmart4, dr360, etc) instance"
   echo ""
   echo "        [VERSION]     : Release/version string (e.g. 5.5, 5.6, etc)"
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 jetty traksmart 172.20.19.210 stop [5.6]"
   echo ""
   echo "  $0 tomcat dev_user 172.20.19.62 start"
   echo ""
   echo "  $0 ldap traksmart 172.20.19.139 stop"
   echo ""
   echo "  $0 intalio traksmart 172.20.19.239 stop"
   echo ""
   echo "  $0 jasper-all traksmart 172.20.19.239 stop"
   echo ""
   echo "  $0 jasper-tomcat traksmart 172.20.19.239 stop"
   echo ""
   echo "  $0 jasper-postgresql traksmart 172.20.19.239 stop"
   echo ""
   exit
}

if [ $# -lt 4 ]; then
   Usage
fi

SERV_NAME=$1
APP_USR=$2
APP_SERV_IP=$3
ACTION=$4
VERSION=$5
WORKFLOW_ENGINE=$6

STARTUP_SCRIPT="/etc/init.d/$SERV_NAME"
cmd="${STARTUP_SCRIPT} $ACTION $WORKFLOW_ENGINE"
echo "$SERV_NAME"
echo "$ACTION"
echo "$VERSION"
echo "$WORKFLOW_ENGINE"


case "$SERV_NAME" in
    jetty)
       if [ "$APP_SERV_IP" == "172.20.18.53" ]; then
          if [ ! -z ${VERSION} ]; then
             if [ "${VERSION}" != "HEAD" ]; then 
                
					echo "$VERSION"
					#VER=$(echo ${VERSION} | cut -d'.' -f0-2)
					#In Unbuntu, fields and positions of the cut command are numbered from 1
					VER=$(echo ${VERSION} | cut -d'.' -f1-3)
					STARTUP_SCRIPT="${STARTUP_SCRIPT}_${APP_USR}${VER}"
					cmd="${STARTUP_SCRIPT} $ACTION $WORKFLOW_ENGINE"
					echo "Running sudo ${cmd}"
             fi
          fi
	  if [ "$ACTION" == "stop" ]; then 
          	ps -ef | grep NEXANT_APP_HOME | grep -v 'grep' | awk '{print $2}'| xargs kill
	   	echo "Killing existing process"
            #cmd="${STARTUP_SCRIPT} $ACTION"
            #echo "Running sudo ${cmd}"
           # echo "Stopping process "     
          else
               echo "Running sudo ${cmd}"
	        sudo ${cmd}
          fi
       fi


      # cmd="${STARTUP_SCRIPT} $ACTION"
      # echo "Running sudo ${cmd} ..."
      # sudo ${cmd}
       ;;
    tomcat)
       # Until OPS/GRID360 development fixes the tomcat setup/config.
       # problem, we will need to start/stop tomcat this way
       STARTUP_SCRIPT_LOC="/app/apache-tomcat/bin"
       if [ "$ACTION" == "stop" ]; then
          STARTUP_SCRIPT="shutdown.sh"
       else
          STARTUP_SCRIPT="startup.sh"
       fi
       echo "Running sudo ./${STARTUP_SCRIPT} ..."
       (cd $STARTUP_SCRIPT_LOC; sudo ./${STARTUP_SCRIPT})
       ;;
    ldap)
       echo "Running sudo ${cmd} ..."
       sudo ${cmd}
       ;;
    intalio)
       STARTUP_SCRIPT="/etc/init.d/cloud"
       # The "-t -t" option somehow does not work well with Intalio (see SCM-3663)
       #cmd="ssh -t -t -i /home/${APP_USR}/.ssh/id_rsa_${APP_USR} ${APP_USR}@${APP_SERV_IP} sudo ${STARTUP_SCRIPT} $ACTION"
       #cmd="ssh -i /home/${APP_USR}/.ssh/id_rsa_${APP_USR} ${APP_USR}@${APP_SERV_IP} sudo ${STARTUP_SCRIPT} $ACTION"
       cmd="ssh ${APP_USR}@${APP_SERV_IP} sudo ${STARTUP_SCRIPT} $ACTION"
       echo "Running ${cmd} ..."
       ${cmd}
       ;;
    jasper-all)
       STARTUP_SCRIPT="/etc/init.d/jasper"
       cmd="${STARTUP_SCRIPT} $ACTION"
       echo "Running sudo ${cmd} ..."
       sudo ${cmd}
       ;;
    jasper-tomcat)
       # /etc/init.d/jasper always shutdown/startup both tomcat & postgresql altogether
       # but cannot handle shutdown/startup only the tomcat or postgresql process
       STARTUP_SCRIPT="/opt/jasper/ctlscript.sh"
       cmd="${STARTUP_SCRIPT} $ACTION tomcat"
       echo "Running sudo ${cmd} ..."
       sudo ${cmd}
       ;;
    jasper-postgresql)
       # /etc/init.d/jasper always shutdown/startup both tomcat & postgresql altogether
       # but cannot handle shutdown/startup only the tomcat or postgresql process
       STARTUP_SCRIPT="/opt/jasper/ctlscript.sh"
       cmd="${STARTUP_SCRIPT} $ACTION postgresql"
       echo "Running sudo ${cmd} ..."
       sudo ${cmd}
       ;;
    rtvscand)
       echo "Running sudo ${cmd} ..."
       sudo ${cmd}
       ;;
    *)
       echo "Unknown server process--Must be one of jetty, tomcat, ldap, intalio, or jasper"
       Usage
       ;;
esac

#echo "Running sudo ${STARTUP_SCRIPT} $ACTION ..."
#sudo ${STARTUP_SCRIPT} $ACTION

