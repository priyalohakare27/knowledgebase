# Class for Full Release related functionalities
package BRS::Release::FullRelease; 

use strict;
use warnings;
use BRS::Release;
our @ISA = qw(BRS::Release);


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class) = shift;

#print "FullRelease->new\n";

  my $self = $class->SUPER::new( @_ );

  $self->init( @_ );

  bless( $self, $class );

  return( $self );
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Initialize data through the parent class 
   $self->SUPER::init( $args );
}

1;
