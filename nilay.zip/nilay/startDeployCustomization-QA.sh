#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <APP_SERV_IP> <JOB_NAME> <CUSTOMER> <EMAIL_TO> <EMAIL_CC> <WORKFLOW_ENGINE>"
   echo ""
   echo "   where"
   echo ""
   echo "        <APP_SERV_IP> : The IP address of the targeted QA server (e.g. 172.20.19.178)"
   echo "                        for this deployment."
   echo ""
   echo "           <JOB_NAME> : The name of Jenkins job (e.g. TS-rel-4.4.1) that builds the"
   echo "                        artifact for this deployment."
   echo ""
   echo "           <CUSTOMER> : Specify whether this deployment should also include customizations"
   echo "                        for the given customer (e.g. PSEG) or NONE if none customizations"
   echo ""
   echo "            <EMAIL_TO>: Specify the email To list for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo ""
   echo "            <EMAIL_CC>: Specify the email CC list for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo "Examples:"
   echo "---------"
   echo "  $0 172.20.19.136 TS-rel-5.1.2 PSEG QATeam@nexant.com traksmartdevteam@nexant.com"
   echo ""
   echo "  $0 172.20.19.233 TS-rel-5.1.2 CGV QATeam@nexant.com traksmartdevteam@nexant.com"
   echo ""
   echo "  $0 192.168.55.149 TS-rel-5.2.0 QATeam@nexant.com traksmartdevteam@nexant.com"
   echo ""
   exit
}

if [ $# -ne 6 ]; then
   Usage
fi

#################
# Arguments given 
#################
APP_SERV_IP=$1
JOB_NAME=$2
CUSTOMER=$3
EMAIL_TO=$4
EMAIL_CC=$5
WORKFLOW_ENGINE=$6

###########################
# Jenkins build server info
###########################
BLD_SERV_IP="http://172.20.19.67"
BLD_SERV_PORT="8080"

#########################################
# The deployment script that does the job 
#########################################
DEPLOY_SCRIPT="/home/${USR}/bin/BRS-CD/deployCustomization.pl"

EMAIL_LIST="mailto:mchu@nexant.com"

#################################
# Default deployemnt command-line 
#################################
cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --custom_customer $CUSTOMER --email_to_list ${EMAIL_TO} --email_cc_list ${EMAIL_CC} --workflow_engine ${WORKFLOW_ENGINE}"

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}"

/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
