#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <USR> <APP_SERV_IP> <JOB_NAME> <BUILD_NUM> <CUSTOMER> <EMAIL_TO> <EMAIL_CC> <TRIGGER_OTHER_BUILD> <MANUAL_STOP_APPINST> <MANUAL_START_APPINST>"
   echo ""
   echo "   where"
   echo ""
   echo "                <USR> : The user account under which the QA instance is running"
   echo "                        (e.g. traksmart for Traksmart related applications)."
   echo ""
   echo "        <APP_SERV_IP> : The IP address of the targeted QA server (e.g. 172.20.19.178)"
   echo "                        for this deployment."
   echo ""
   echo "           <JOB_NAME> : The name of Jenkins job (e.g. TS-rel-4.4.1) that builds the"
   echo "                        artifact for this deployment."
   echo ""
   echo "          <BUILD_NUM> : The Jenkins build number (e.g. 1) of ARTIFACT_JOB_NAME associated"
   echo "                        with the artifact for this deployment."
   echo ""
   echo "           <CUSTOMER> : Specify whether this deployment should also include customizations"
   echo "                        for the given customer (e.g. PSEG) or NONE if none customizations"
   echo ""
   echo "            <EMAIL_TO>: Specify the email To lits for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo ""
   echo "            <EMAIL_CC>: Specify the email CC lits for sending deployment HEADS-UP"
   echo "                        and COMPLETION email notification"
   echo ""
   echo " <TRIGGER_OTHER_BUILD>: Specify the build job name (e.g. cms) to be triggered. This option is"
   echo "                        ONLY used when we also need to trigger another build during a"
   echo "                        deployment (Currently, This is for deploying a CMS build along"
   echo "                        with a Tradeally deployment. Default value is NONE"
   echo "                        (i.e. Do not trigger another build)"
   echo ""
   echo " <MANUAL_STOP_APPINST>: Specify whether to manually stop the application instance"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 0/FALSE (i.e. stopping the"
   echo "                        application instance automatically)"
   echo ""
   echo "<MANUAL_START_APPINST>: Specify whether to manually start the application instance"
   echo "                        (1=>TRUE; 0=>FALSE). Default is 0/FALSE (i.e. starting the"
   echo "                        application instance automatically)"
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 traksmart 172.20.19.136 TS-rel-5.1.2 10 PSEG QATeam@nexant.com traksmartdevteam@nexant.com NONE NO NO"
   echo ""
   echo "  $0 traksmart 172.20.19.233 TS-rel-5.1.2 10 CGV QATeam@nexant.com traksmartdevteam@nexant.com NONE NO NO"
   echo ""
   echo "  $0 traksmart 192.168.55.149 TS-rel-5.2.0 641 QATeam@nexant.com traksmartdevteam@nexant.com NONE NO NO"
   echo ""
   echo "  $0 tradeally 172.20.19.106 TA-TRUNK 30 NONE QATeam@nexant.com traksmartdevteam@nexant.com cms NO NO"
   echo ""
   exit
}

#######################################################################
# Converts the strings "YES" & "NO" to 1 & 0, respectively
#######################################################################
function convertValue
{
   local _resVal=$1
   local _res

   if [ "$_resVal" == "YES" ]; then
      _res=1
   else
      _res=0
   fi

   eval $_resVal=\$_res
}

if [ $# -le 9 ]; then
   Usage
fi

#################
# Arguments given 
#################
USR=$1
APP_SERV_IP=$2
JOB_NAME=$3
BUILD_NUM=$4
CUSTOMER=$5
EMAIL_TO=$6
EMAIL_CC=$7
TRIGGER_OTHER_BUILD=$8
MANUAL_STOP_APPINST=$9
convertValue MANUAL_STOP_APPINST

MANUAL_START_APPINST=${10}
convertValue MANUAL_START_APPINST

WORKFLOW_ENGINE=${11}

###########################
# Jenkins build server info
###########################
BLD_SERV_IP="http://172.20.19.67"
BLD_SERV_PORT="8080"

#########################################
# The deployment script that does the job 
#########################################
DEPLOY_SCRIPT="/home/${USR}/bin/BRS-CD/deploy.pl"

EMAIL_LIST="mailto:mchu@nexant.com"

#################################
# Default deployemnt command-line 
#################################
if [ "$APP_SERV_IP" == "172.20.19.195" ]; then
   MANUAL_STOP_LDAP=0
   MANUAL_START_LDAP=0
   MANUAL_STOP_INTALIO=0
   MANUAL_START_INTALIO=0
   MANUAL_STOP_JASPER=1
   MANUAL_START_JASPER=1
   DB_USR=backup
   DB_PASSWD=cBju4guhFX5Aa5V

   cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --email_to_list ${EMAIL_TO} --email_cc_list ${EMAIL_CC} --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --manual_stop_ldap $MANUAL_STOP_LDAP --manual_start_ldap $MANUAL_START_LDAP --manual_stop_intalio $MANUAL_STOP_INTALIO --manual_start_intalio $MANUAL_START_INTALIO --manual_stop_jasper $MANUAL_STOP_JASPER --manual_start_jasper $MANUAL_START_JASPER --db_usr ${DB_USR} --db_passwd ${DB_PASSWD}"
else
   cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --email_to_list ${EMAIL_TO} --email_cc_list ${EMAIL_CC} --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --workflow_engine $WORKFLOW_ENGINE"
fi

###################################################
# Get the artifact name based on the build job name
###################################################
PROJ_NAME=${JOB_NAME:0:2}
if [ "${PROJ_NAME}" == "TS" ]; then
   ARTIFECT_NAME="traksmart4.war"
elif [ "${PROJ_NAME}" == "TA" ]; then
   ARTIFECT_NAME="tradeally.war"
elif [ "${PROJ_NAME}" == "TI" ]; then
   ARTIFECT_NAME="tims.war"
elif [ "${PROJ_NAME}" == "TR" ]; then
   ARTIFECT_NAME="trl.war"
elif [ "${PROJ_NAME}" == "DR" ]; then
   ARTIFECT_NAME="dr360.war"
elif [ "${PROJ_NAME}" == "GR" ]; then
   ARTIFECT_NAME="nexant-dm360.war"
elif [ "${PROJ_NAME}" == "ES" ]; then
   ARTIFECT_NAME="goldengate.war"
else
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Unknown job name, '$JOB_NAME', please verify and try again."
   exit 1 
fi

#######################################################################
# Check if the application server on which the artifact to be deploying
# is located in a different network domain (i.e. Its IP address starts
# with 192 or anything other than 172) of the build server/artifact
# repository. If so, we will need to scp the artifact to it as it is
# not possible to directly wget the artifact from either the build 
# server or artifact repository (which are locating in the 172 domain)
#######################################################################
IP_PREFIX=`echo ${APP_SERV_IP} | cut -d '.' -f1`
if [ "${IP_PREFIX}" == "192" ]; then
   tmpDownldDir="/tmp/${APP_SERV_IP}_${JOB_NAME}_${BUILD_NUM}.$(date +%Y-%m-%d-%H-%M-%S)"
   /bin/mkdir -p ${tmpDownldDir}
   cd ${tmpDownldDir}; 
   ARTIFECT_URL="${BLD_SERV_IP}:${BLD_SERV_PORT}/job/${JOB_NAME}/${BUILD_NUM}/artifact/target/$ARTIFECT_NAME"
   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Downloading ${ARTIFECT_URL} to ${tmpDownldDir}"
   /usr/bin/wget ${ARTIFECT_URL} 2>> ./wget_errlog 
   if [ $? != 0 ]; then
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${ARTIFECT_URL} FAILED--Likely connection/permission related or due to bad ${ARTIFECT_URL} path!"
      echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${ARTIFECT_URL} FAILED--Likely connection/permission related or due to bad ${ARTIFECT_URL} path!" >> ./console.log
      /bin/cat ./wget_errlog >> ./console.log
      /bin/cat ./console.log | /bin/mail -s "*ALERT* Problem downloading ${ARTIFECT_URL}--wget ${ARTIFECT_URL} FAILED!" ${EMAIL_LIST}
      cd ../;
      /bin/rm -rf ${tmpDownldDir} 
      exit 1
   fi

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir}"

   /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir} 

   echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}"
   /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir}

   if [ "${PROJ_NAME}" == "TA" ] && [ "${TRIGGER_OTHER_BUILD}" == "cms"]; then
      tmpDownldDir_cms="/tmp/${APP_SERV_IP}_CMS_${BUILD_NUM}.$(date +%Y-%m-%d-%H-%M-%S)"
      /bin/mkdir -p ${tmpDownldDir_cms}
      cd ${tmpDownldDir_cms}
      CMS_ARTIFECT_NAME="cms.war"
      CMS_ARTIFECT_URL="${BLD_SERV_IP}:${BLD_SERV_PORT}/job/TA-CMS/lastSuccessfulBuild/artifact/target/$CMS_ARTIFECT_NAME"
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Downloading ${CMS_ARTIFECT_URL} to ${tmpDownldDir_cms}"
      /usr/bin/wget ${CMS_ARTIFECT_URL} 2>> ./wget_errlog
      if [ $? != 0 ]; then
         echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${CMS_ARTIFECT_URL} FAILED--Likely connection/permission related or due to bad ${CMS_ARTIFECT_URL} path!"
         echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${CMS_ARTIFECT_URL} FAILED--Likely connection/permission related or due to bad ${CMS_ARTIFECT_URL} path!" >> ./console.log
         /bin/cat ./wget_errlog >> ./console.log
         /bin/cat ./console.log | /bin/mail -s "*ALERT* Problem downloading ${CMS_ARTIFECT_URL}--wget ${CMS_ARTIFECT_URL} FAILED!" ${EMAIL_LIST}
         cd ../;
         /bin/rm -rf ${tmpDownldDir_cms}
         exit 1
      fi
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir_cms}"

      /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} /bin/mkdir -p ${tmpDownldDir_cms}
      echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${CMS_ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir_cms}"
      /usr/bin/scp -i /home/jenkins/.ssh/id_rsa_jenkins ${CMS_ARTIFECT_NAME} jenkins@${APP_SERV_IP}:${tmpDownldDir_cms}

      cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --artifact_download_dir ${tmpDownldDir}"
      /bin/rm -rf ${tmpDownldDir_cms}
   else
      cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --build_num $BUILD_NUM --custom_customer $CUSTOMER --trigger_other_build $TRIGGER_OTHER_BUILD --manual_stop_appInst $MANUAL_STOP_APPINST --manual_start_appInst $MANUAL_START_APPINST --artifact_download_dir ${tmpDownldDir}"
   fi

   /bin/rm -rf ${tmpDownldDir}
fi

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: Running /usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}"

/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins jenkins@${APP_SERV_IP} ${cmd}

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
