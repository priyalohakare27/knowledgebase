#! /bin/bash

#################
# Arguments given
#################
BUILD_JOB='Jasper-Upgrade'
JASPER_BUILD_NO='6'
TARGET_IP='172.20.19.126'
TARGET_SERVER_USERNAME='jenkins'
CONNECTION_IP_PORT='fostsdb02:3306'
CONNECTION_DB='ts5_qa_126'
CONNECTION_USERNAME='ts5_qa_126'
CONNECTION_PASSWORD='ts5_qa_126'


echo "${TARGET_SERVER_USERNAME}"

APPCONTEXTDSPATH="./jasperreports-server-6.3.0/apache-tomcat/webapps/reporting/WEB-INF/applicationContext-traksmart-ds.xml"

echo "Copy Paste zip from Jenkins server to the target server.."



## Unzip the jasper_6_3_goldenzip.tar.gz in /opt/
/usr/bin/ssh -t -t -i /home/jenkins/.ssh/id_rsa_jenkins ${TARGET_SERVER_USERNAME}@${TARGET_IP} <<- 'ENDSSH'
	cd /opt/
	wget http://172.20.19.67:8080/view/Report_Jasper/job/Jasper-Upgrade/lastSuccessfulBuild/artifact/jasper_6_3_goldenzip.tar.gz
	tar zxvf jasper_6_3_goldenzip.tar.gz
	
	#Replace database details in applicationContext-traksmart-ds.xml with input params
	sed -ie "s/<con_ip_and_port>/$CONNECTION_IP_PORT/g" $APPCONTEXTDSPATH && sed -ie "s/<con_db_name>/$CONNECTION_DB/g" $APPCONTEXTDSPATH && sed -ie "s/<con_usr>/$CONNECTION_USERNAME/g" $APPCONTEXTDSPATH && sed -ie "s/<con_pass>/$CONNECTION_PASSWORD/g" $APPCONTEXTDSPATH

	# Run the export command on 5.6 server and export everything in js-export5.6.zip file
	echo "Export data from 5.6 server using option 'export-everything' into file js-export5.6.zip..........."
	/opt/jasperreports-server-5.6/apache-ant/bin/ant --noconfig -nouserlib -f /opt/jasperreports-server-5.6/buildomatic/build.xml export-everything -DexportFile=js-export5.6.zip && cp /opt/jasperreports-server-5.6/buildomatic/js-export5.6.zip /opt/

	echo "Export completed"

	echo "Stopping the 5.6 server......."
	/opt/jasperreports-server-5.6/ctlscript.sh stop

	echo "Server stopped successfully"

	echo "Start the 6.3 server....."
	/opt/jasperreports-server-6.3.0/ctlscript.sh start

	#Import the zip file in destination server
	echo "Starting the import process......."
	
	/opt/jasperreports-server-6.3.0/buildomatic/js-import.sh --input-zip /opt/js-export5.6.zip --update --skip-themes --include-access-events --include-monitoring-events

	#Restart the server
	echo "Restarting the 6.3 server......"
	
	/opt/jasperreports-server-6.3.0/ctlscript.sh restart

ENDSSH

echo "Deployment completed successfully"
echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
