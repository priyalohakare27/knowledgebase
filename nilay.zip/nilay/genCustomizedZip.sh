#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <JOB_NAME> <BRANCH_NAME> <NAME>"
   echo ""
   echo "   where"
   echo ""
   echo "        <JOB_NAME> : This current Jenkins job name (e.g. TS-Customize) in which"
   echo "                     the target custimize zip file is being generated"
   echo ""
   echo "     <BRANCH_NAME> : The release branch name (which can be found under http://172.20.19.61:18080/svn/)"
   echo "                     from which the customzed files are to be pulled and packaged into"
   echo "                     the customization zip file"
   echo ""
   echo "           <NAME> : The name (e.g. CGV, questar_pdf, BRS) associated with the customization zip"
   echo "                    file to be generated"
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 TS-Customize 23 ts-rel-5.2.1 PSEG"
   echo ""
   echo "  $0 TS-Customize 32 ts-rel-5.2.1 questar_pdf"
   echo ""
   echo "  $0 BRS-pkg-latest-code 12 HEAD BRS"
   exit
}

if [ $# -ne 3 ]; then
   Usage
fi

JOB_NAME=$1
BRANCH_NAME=$2
NAME=$3

PREFIX=${BRANCH_NAME:0:6}
if [ "${PREFIX}" == "ts-rel" ]; then
   REL=$(echo $BRANCH_NAME | cut -d'-' -f3)
elif [ "${PREFIX}" == "releas" ]; then
   REL=$(echo $BRANCH_NAME | cut -d'-' -f2)
else
   REL="HEAD"
fi

SVN_URL="http://172.20.19.61:18080/svn"
JENKINS_JOB_ROOT="/var/lib/jenkins/jobs"
WORKSPACE="${JENKINS_JOB_ROOT}/${	}/workspace"
TYPE="Customizations"
TMP_DIR="/tmp/${TYPE}"
TARGET_DIR="${WORKSPACE}/target"
TARGET_ZIPFILE="${TARGET_DIR}/${NAME}_${TYPE}_${REL}.tar.gz"

PROJ_REPO_SUBDIR="branches/${BRANCH_NAME}"

PREFIX=${JOB_NAME:0:2}
if [ "${PREFIX}" == "TS" ]; then
   PROJ_REPO_ROOT="traksmart4"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="traksmart"
   fi
elif [ "${PREFIX}" == "TA" ]; then
   PROJ_REPO_ROOT="tradeally"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="trunk"
   fi 
elif [ "${PREFIX}" == "TR" ]; then
   PROJ_REPO_ROOT="tech_ref_lib"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="trl"
   fi
elif [ "${PREFIX}" == "DR" ]; then
   PROJ_REPO_ROOT="traksmart4"
   PROJ_REPO_SUBDIR="branches/dr360"
elif [ "${PREFIX}" == "GR" ]; then
   PROJ_REPO_ROOT="dms"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="grid360"
   fi
elif [ "${PREFIX}" == "ES" ]; then
   PROJ_REPO_ROOT="esb"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="goldengate"
   fi
elif [ "${PREFIX}" == "BR" ]; then
   PROJ_REPO_ROOT="buildrelease"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="BRS-CD"
   fi
   TMP_DIR="/tmp/${TYPE}-BRS"
   TARGET_ZIPFILE="${TARGET_DIR}/${NAME}_latestCode.tar.gz"
else
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Unknown job name, '$JOB_NAME', please verify and try again."
   exit 1
fi

SRC="*" 
case $NAME in
    BRS)
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}"
        ;;
    *pdf)
        SUB_DIR="src/main/webapp/WEB-INF" 
        REAL_NAME=`echo ${NAME} | awk -F'_' '{print $1}'`
        SRC="WEB-INF/ui/pdf/${REAL_NAME}" 
        TMP_DIR="/tmp/${TYPE}-${NAME}"
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}/${SUB_DIR}"
        ;;
    *) 
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}/${TYPE}/${NAME}"
        ;;
esac

echo ""

# Cleaning up first
if [ -d ${TARGET_DIR} ]; then
   echo "INFO: Cleaning up previous/old ${TARGET_DIR}..."
   /bin/rm -rf ${TARGET_DIR}
fi

if [ -d ${TMP_DIR} ]; then
   echo "INFO: Cleaning up previous/old ${TMP_DIR}..."
   /bin/rm -rf ${TMP_DIR}
fi

echo "INFO: Creating ${TMP_DIR} to hold the checkout of the ${TYPE} directory..." 
/bin/mkdir -p ${TMP_DIR}

echo "INFO: Creating ${TARGET_DIR} to hold the target ${TYPE} zip file..." 
/bin/mkdir -p ${TARGET_DIR}

echo "INFO: svn co ${SRC_URL} into ${TMP_DIR}..."
echo ""
echo "-----------------------------------------------------------------------------------"
cd ${TMP_DIR}
/opt/csvn/bin/svn co --username jenkins --password J3nK1nS ${SRC_URL}
if [ $? != 0 ]; then
   echo "***ERROR: Failed to svn co ${SRC_URL} into ${TMP_DIR}..."
   exit 1
fi

echo "-----------------------------------------------------------------------------------"
echo ""
echo "INFO: First removing any .svn files/dirs ..."
echo ""
echo ""
/usr/bin/find . -name ".svn" -exec /bin/rm -rf {} \; -print

case "$NAME" in
    BRS|*pdf)
        cd ${TMP_DIR}
        ;;
    *)  cd ${TMP_DIR}/${NAME}
        ;;
esac

CURR_DIR=`pwd`

echo ""
echo ""
echo "-----------------------------------------------------------------------------------"
echo "INFO: Packaging ${TARGET_ZIPFILE} with ${NAME} ${TYPE} files..."
echo "      (/bin/tar -zcvf ${TARGET_ZIPFILE} ${SRC})"
echo "-----------------------------------------------------------------------------------"
echo ""
/bin/tar -zcvf ${TARGET_ZIPFILE} ${SRC} 
if [ $? != 0 ]; then
   echo "***ERROR: Failed to tar up ${TARGET_ZIPFILE} under ${CURR_DIR}..."
   exit 1
fi

echo "-----------------------------------------------------------------------------------"
echo ""
echo "... Done"
