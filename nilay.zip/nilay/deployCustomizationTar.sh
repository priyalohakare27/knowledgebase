#!/bin/bash

function Usage
{
   echo ""
   echo "Usage: $0 <JOB_NAME> <USR> <BRANCH_NAME> <APP_SERV_IP> <NAME>  "
   echo ""
   echo "   where"
   echo ""
   echo "        <JOB_NAME> : This current Jenkins job name (e.g. TS-Customize) in which"
   echo "                     the target customize zip file is being generated"
   echo ""
   echo "        <USR> : The user account under which the QA instance is running"
   echo "                        (e.g. traksmart for Traksmart related applications)." 
   echo ""
   echo "     <BRANCH_NAME> : The release branch name (which can be found under http://172.20.19.61:18080/svn/)"
   echo "                     from which the customized files are to be pulled and packaged into"
   echo "                     the customization zip file"
   echo ""
   echo "           <NAME> : The name (e.g. CGV, questar_pdf, BRS) associated with the customization zip"
   echo "                    file to be generated"
   echo ""
   echo "           <APP_SERV_IP> : The IP (e.g. 172.20.19.126) associated with the Customer"
   echo ""
   echo "Examples:"
   echo "---------"
   echo "  $0 TS-Customize traksmart ts-rel-5.2.1 172.20.19.136 PSEG"
   echo ""
   echo "  $0 TS-Customize traksmart ts-rel-5.2.1 172.20.19.240 questar"
   echo ""
   echo "  $0 BRS-pkg-latest-code HEAD BRS"
   exit
}

if [ $# -ne 5 ]; then
   Usage
fi

JOB_NAME=$1
BRANCH_NAME=$2
NAME=$3
APP_SERV_IP=$4
USR=$5

PREFIX=${BRANCH_NAME:0:6}
if [ "${PREFIX}" == "ts-rel" ]; then
   REL=$(echo $BRANCH_NAME | cut -d'-' -f3)   #6.3
elif [ "${PREFIX}" == "releas" ]; then
   REL=$(echo $BRANCH_NAME | cut -d'-' -f2)
else
   REL="HEAD"
fi


###########################
# Jenkins build server info
###########################
BLD_SERV_IP="http://172.20.19.61"
BLD_SERV_PORT="9090"


SVN_URL="http://172.20.19.61:18080/svn"
JENKINS_JOB_ROOT="/jobs"
WORKSPACE="${JENKINS_JOB_ROOT}/${JOB_NAME}/ws/target" #/jobs/TS-Customize/ws/target
TYPE="Customizations"
TMP_DIR="/tmp/${TYPE}" #/temp/Customizations
TARGET_DIR="${WORKSPACE}/target"  #/jobs/TS-Customize/ws/target
TARGET_ZIPFILE="${BLD_SERV_IP}:${BLD_SERV_PORT}${TARGET_DIR}/${NAME}_${TYPE}_${REL}.tar.gz"  #http://172.20.19.61:9090/job/TS-Customize/ws/target/prpa_Customizations_6.4.0.tar.gz



PROJ_REPO_SUBDIR="branches/${BRANCH_NAME}"  #branches/ts-rel-6.3

PREFIX=${JOB_NAME:0:2}
if [ "${PREFIX}" == "TS" ]; then
   PROJ_REPO_ROOT="traksmart4"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="traksmart"
   fi
elif [ "${PREFIX}" == "TA" ]; then
   PROJ_REPO_ROOT="tradeally"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="trunk"
   fi 
elif [ "${PREFIX}" == "TR" ]; then
   PROJ_REPO_ROOT="tech_ref_lib"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="trl"
   fi
elif [ "${PREFIX}" == "DR" ]; then
   PROJ_REPO_ROOT="traksmart4"
   PROJ_REPO_SUBDIR="branches/dr360"
elif [ "${PREFIX}" == "GR" ]; then
   PROJ_REPO_ROOT="dms"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="grid360"
   fi
elif [ "${PREFIX}" == "ES" ]; then
   PROJ_REPO_ROOT="esb"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="goldengate"
   fi
elif [ "${PREFIX}" == "BR" ]; then
   PROJ_REPO_ROOT="buildrelease"
   if [ "${BRANCH_NAME}" == "HEAD" ]; then
      PROJ_REPO_SUBDIR="BRS-CD"
   fi
   TMP_DIR="/tmp/${TYPE}-BRS"
   TARGET_ZIPFILE="${TARGET_DIR}/${NAME}_latestCode.tar.gz"
else
   echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* Unknown job name, '$JOB_NAME', please verify and try again."
   exit 1
fi

SRC="*" 
case $NAME in     
    BRS)
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}" 
        ;;
    *pdf)
        SUB_DIR="src/main/webapp/WEB-INF" 
        REAL_NAME=`echo ${NAME} | awk -F'_' '{print $1}'`
        SRC="WEB-INF/ui/pdf/${REAL_NAME}" 
        TMP_DIR="/tmp/${TYPE}-${NAME}" #temp/Customizations-pseg
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}/${SUB_DIR}" 
        ;;
    *) 
        SRC_URL="${SVN_URL}/${PROJ_REPO_ROOT}/${PROJ_REPO_SUBDIR}/${TYPE}/${NAME}"  #http://172.20.19.61:18080/svn/traksmart4/traksmart/Customizations/pseg
        ;;
esac

echo ""

# Cleaning up first
if [ -d ${TARGET_DIR} ]; then
   echo "INFO: Cleaning up previous/old ${TARGET_DIR}..."
   /bin/rm -rf ${TARGET_DIR}
fi

if [ -d ${TMP_DIR} ]; then
   echo "INFO: Cleaning up previous/old ${TMP_DIR}..."
   /bin/rm -rf ${TMP_DIR}
fi

echo "INFO: Creating ${TMP_DIR} to hold the checkout of the ${TYPE} directory..." 
/bin/mkdir -p ${TMP_DIR}

echo "INFO: Creating ${TARGET_DIR} to hold the target ${TYPE} zip file..." 
/bin/mkdir -p ${TARGET_DIR}

echo "INFO: svn co ${SRC_URL} into ${TMP_DIR}..." #checkout
echo ""
echo "-----------------------------------------------------------------------------------"
cd ${TMP_DIR}
/opt/csvn/bin/svn co --username jenkins --password J3nK1nS ${SRC_URL} #http://172.20.19.61:18080/svn/traksmart4/traksmart//Customizations/pseg
if [ $? != 0 ]; then
   echo "***ERROR: Failed to svn co ${SRC_URL} into ${TMP_DIR}..."
   exit 1
fi

echo "-----------------------------------------------------------------------------------"
echo ""
echo "INFO: First removing any .svn files/dirs ..."
echo ""
echo ""
/usr/bin/find . -name ".svn" -exec /bin/rm -rf {} \; -print

case "$NAME" in
    BRS|*pdf)
        cd ${TMP_DIR}
        ;;
    *)  cd ${TMP_DIR}/${NAME}
        ;;
esac


# CURR_DIR=`pwd`  

# echo ""
# echo ""
# echo "-----------------------------------------------------------------------------------"
# echo "INFO: Packaging ${TARGET_ZIPFILE} with ${NAME} ${TYPE} files..."
# echo "      (/bin/tar -zcvf ${TARGET_ZIPFILE} ${SRC})"
# echo "-----------------------------------------------------------------------------------"
# echo ""
# /bin/tar -zcvf ${TARGET_ZIPFILE} ${SRC} 
# if [ $? != 0 ]; then
   # echo "***ERROR: Failed to tar up ${TARGET_ZIPFILE} under ${CURR_DIR}..."
   # exit 1
# fi

# echo "-----------------------------------------------------------------------------------"
# echo ""
# echo "... Done"


# Make sure the application server IP is valid beforehand...
IP_PREFIX=`echo ${APP_SERV_IP} | cut -d '.' -f1`

# According to TECHOPS, Nexant will only use either IP prefix '172' or '192'
if [ "${IP_PREFIX}" != "172" ] && [ "${IP_PREFIX}" != "192" ]; then
   errMsg="*ERROR* The IP prefix, '${IP_PREFIX}', of the given application server IP, '${APP_SERV_IP}', is invalid -- It must be either '172' or '192'! Please verify."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${errMsg}"
   echo "${errMsg}" | /bin/mail -s "*ERROR* Invalid application server IP (prefix) is given!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
   exit 1
fi

echo "Checking 'ping -c 1 -W 5 ${APP_SERV_IP}' ..."
ping -c 1 -W 5 ${APP_SERV_IP}
if [ $? != 0 ]; then
   errMsg="*ERROR* The given application server IP, '${APP_SERV_IP}', is not ping'able/accessible! Please verify."
   echo "$(date +%Y-%m-%d_%H:%M:%S) ${errMsg}"
   echo "${errMsg}" | /bin/mail -s "*ERROR* Invalid/Inaccessible application server IP is given!" ${ERR_EMAIL_TO} ${ERR_EMAIL_CC}
   exit 1
fi





#########################################
# The deployment script that does the job 
#########################################
DEPLOY_SCRIPT="/home/${USR}/bin/BRS-CD/deploy.pl"

EMAIL_LIST="mailto:priyal@nexant.com"


# if [ "$APP_SERV_IP" == "172.20.19.195" ]; then
   # MANUAL_STOP_LDAP=0
   # MANUAL_START_LDAP=0
   # MANUAL_STOP_INTALIO=0
   # MANUAL_START_INTALIO=0
   # MANUAL_STOP_JASPER=1
   # MANUAL_START_JASPER=1
   # DB_USR=backup
   # DB_PASSWD=cBju4guhFX5Aa5V


#################################
# Default deployemnt command-line 
#################################
cmd="sudo -u ${USR} $DEPLOY_SCRIPT --app_usr $USR --app_serv_ip $APP_SERV_IP --build_job $JOB_NAME --custom_customer $NAME"

 if [ "${USR}" = "traksmart" ]; then
		CURRENT_DIR= /usr/local/jetty/jetty-distribution-9.2.10.v20150310/lastBuild/traksmart4
		cd ${CURRENT_DIR}
		ZIP= wget ${TARGET_ZIPFILE} # http://172.20.19.61:9090/job/TS-Customize/ws/target/prpa_Customizations_6.4.0.tar.gz
		tar -zcvf ${ZIP}
		/etc/init.d/jetty restart
else
		echo "$(date +%Y-%m-%d_%H:%M:%S) *ERROR* wget ${TARGET_ZIPFILE} FAILED--Likely connection/permission related or due to bad ${TARGET_ZIPFILE} path!"
fi

echo "$(date +%Y-%m-%d_%H:%M:%S) INFO: DONE"
