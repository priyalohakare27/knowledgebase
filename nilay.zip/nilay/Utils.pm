package BRS::Utils; # Class for utility functions

use strict;
use warnings;
use Carp;
use Switch;
use Env;
use File::Path qw(mkpath rmtree);
use File::Copy qw(move copy);
use File::Basename;
use File::stat;
use POSIX qw(strftime);
use LWP::Simple;
use Net::Ping;
use Getopt::Long;
use Switch;
use Scalar::Util qw(looks_like_number);

use Exporter;

our @ISA    = qw(Exporter);
our @EXPORT = qw(
                 getArgs
                 Usage
                 isValidScript
                 isValidRemoteScript
                 trim
                 readConfigFile
                 genAppName
                 getEmailList
                 isValidIP
                 isValidURL
                 waitInstance
                 isValidBuildJob
                 isValidBuildNum
                 isValidEmailAddress
                 isBuildJobAndAppUsrMatch
                 execCmd
                 backupDB
                 waitDBbackup
                 backupDocsDir
                 createDir
                 createSymLink
                 changeDir
                 moveFile
                 openFile
                 readSymLink
                 getRelVersion
                 genEmail
                 sendEmail
                 getFileModifyTime
                 genDateStr
                 processInstanceServProcess
                 LOG
                 removeFile
                 triggerBuild
                 runUITests
               );

#########################################################################
# Define constants for TRUE & FALSE
#########################################################################
use constant { TRUE => 1, FALSE => 0 };

##########################################################################
# Usage( [ERR_MSG] )
#    Prints usage info if any invalid argument is given.
#
# [ERR_MSG]
#    Optional argument--The error message to be printed before the usage
#    statement
##########################################################################
sub Usage
{
    select(STDERR);
    if (@_)
    {
       print "\n@_\n";
    }

    print "\nUsage: perl $0 [Options ...]\n\n";
    print "Options:\n";
    print "  --build_serv_url             The (Jenkins) build server URL. This is an optional argument.\n\n";
    print "  --nexus_repo_url             The Nexus Maven repository URL for retriving the artifact.\n";
    print "                               This is an optional argument.\n\n";
    print "  --inst_proc_script           The path of the application instance processing script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --web_serv_name              The name of web server (e.g. jetty) on which the application\n";
    print "                               is running. This is an optional argument.\n\n";
    print "  --web_serv_script            The path of the web server (re)start/stop script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --web_serv_config_file       The path of the web server config file.\n";
    print "                               This is an optional argument.\n\n";
    print "  --ldap_ctl_script            The path of the LDAP (re)start/stop script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --intalio_ctl_script         The path of the Intalio (re)start/stop script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --jasper_ctl_script          The path of the Jasper (re)start/stop script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --rtvscand_ctl_script        The path of the rtvscand (re)start/stop script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --db_bk_script               The path of the DB backup script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --db_bkdir                   The path of the DB backup directory\n";
    print "                               This is an optional argument.\n\n";
    print "  --ldap_bk_script             The path of the LDAP backup script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --ldap_full_bkdir            The path of the LDAP full backup directory.\n";
    print "                               This is an optional argument.\n\n";
    print "  --intalio_bk_script          The path of the Intalio backup script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --jasper_bk_script           The path of the Jasper backup script.\n";
    print "                               This is an optional argument.\n\n";
    print "  --build_job                  The (Jenkins) build job by which the artifact to be\n";
    print "                               triggered or to be released/deployed is built.\n\n";
    print "  --svn_repo_path              The Subversion repository path which is supposed to be\n";
    print "                               obtained through the SVN hook script.\n\n";
    print "  --svn_txn_id                 The Subversion transaction ID which is supposed to be\n";
    print "                               obtained through the SVN hook script.\n\n";
    print "  --build_num                  The (Jenkins) build number associated with the artifact\n";
    print "                               to be released/deployed.\n\n";
    print "  --app_usr                    The application user ID under which the application\n";
    print "                               is running\n\n";
    print "  --app_serv_ip                The IP address of the application server on which\n";
    print "                               the artifact is to be deployed.\n\n";
    print "  --email_to_list              The email-to list--must be of nexant.com one(s)--to which deployment HEADS-UP and\n";
    print "                               COMPLETION email notifications are sent.\n\n";
    print "  --email_cc_list              The email-cc list--must be of nexant.com one(s)--to which deployment HEADS-UP and\n";
    print "                               COMPLETION email notifications are sent.\n\n";
    print "  --db_usr                     The DB user specific for DB backup.\n\n";
    print "  --db_passwd                  The DB password specific for DB backup.\n\n";
    print "  --deployerr_mail_to          The email-to list--must be of nexant.com one(s)--to which deployment errors/problems\n";
    print "                               email notification is sent.\n\n";
    print "  --deployerr_mail_cc          The email-cc list--must be of nexant.com one(s)--to which deployment errors/problems\n";
    print "                               email notification is sent.\n\n";
    print "  --artifact_download_dir      The download directory to retrieve the artifact for deployment.\n";
    print "                               This option is only used for application servers (e.g. staging,\n";
    print "                               or production) outside the network domain of the Maven Nexus\n";
    print "                               repository (that the artifact cannot be directly downloaded\n";
    print "                               using wget). Default value is NIL (i.e. for qa or dev server).\n\n";
    print "  --custom_customer            The customer that needs customizations. Default value is NONE\n";
    print "                               (i.e. no customizations). This is an optional argument.\n\n";
    print "  --trigger_other_build        Specify the build job name (e.g. CMS) to be triggered. This option\n";
    print "                               is ONLY used when we also need to trigger another build\n";
    print "                               during a deployment (Currently, This is for deploying a CMS build\n";
    print "                               along with a Tradeally deployment. Default value is NONE.\n";
    print "                               (i.e. Do not trigger another build).\n\n";
    print "  --do_email_notification      Specify whether to send relevant (HEAD-UP/COMPLETION) email notification\n";
    print "                               (Non-zero => YES; zero => NO). Default is to always send email notification\n\n";
    print "  --manual_stop_appInst        Specify whether to manually stop the application instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to automatically stop\n";
    print "                               the application instance.\n\n";
    print "  --manual_start_appInst       Specify whether to manually start the application instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to automatically start\n";
    print "                               the application instance.\n\n";
    print "  --manual_stop_intalio        Specify whether to manually stop the Intalio instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               stop the Intalio instance.\n\n";
    print "  --manual_start_intalio       Specify whether to manually start the Intalio instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               start the Intalio instance.\n\n";
    print "  --manual_stop_jasper         Specify whether to manually stop the Jasper instance.\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               stop the Jasper instance.\n\n";
    print "  --manual_start_jasper        Specify whether to manually start the Jasper instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               start the Jasper instance.\n\n";
    print "  --manual_stop_ldap           Specify whether to manually stop the LDAP instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               stop the LDAP instance.\n\n";
    print "  --manual_start_ldap          Specify whether to manually start the LDAP instance\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               start the LDAP instance.\n\n";
    print "  --manual_switchoff_rtvscand  Specify whether to manually switch off rtvscand\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               switch off rtvscand\n\n";
    print "  --manual_switchon_rtvscand   Specify whether to manually switch on rtvscand\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not)\n";
    print "                               switch on rtvscand\n\n";
    print "  --manual_bk_ldap             Specify whether to manually backup LDAP (Non-zero => YES; zero => NO).\n";
    print "                               Default is to manually (or do not) back up LDAP.\n\n";
    print "  --manual_bk_intalio          Specify whether to manually backup Intalio (Non-zero => YES; zero => NO).\n";
    print "                               Default is to manually (or do not) back up Intalio.\n\n";
    print "  --manual_bk_jasper           Specify whether to manually backup Jasper (Non-zero => YES; zero => NO).\n";
    print "                               Default is to manually (or do not) back up Jasper.\n\n";
    print "  --manual_bk_docsdir          Specify whether to manually backup the documents directory.\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not) back up.\n\n";
    print "  --manual_bk_appdb            Specify whether to manually backup the application database.\n";
    print "                               (Non-zero => YES; zero => NO). Default is to manually (or do not) back up.\n\n";
    print "  --max_ping_tries             Specifies number of tries on ping'ing the application instance.\n";
    print "                               (after deploying the artifact and started the web server for it).\n\n";
    print "  --sleep_time                 Specifies the number of seconds to sleep before ping'ing the\n";
    print "                               application instance again.\n\n";
    print "  --v --verbose                For verbose mode.\n\n";
    print "  --h --help                   Print usage info.\n\n";
    print "Examples:\n";
    print "  perl $0 --help\n";
    print "  perl $0 --verbose --build_serv_url http://172.20.19.61:8080 --nexus_repo_url http://fosbpaeecdev01:8081/nexus/content/repositories --inst_proc_script /path/to/processInstanceServProcess.sh --web_serv_script /etc/init.d/jetty --web_serv_config_file /etc/default/jetty --build_job TS-HEAD --build_num 123 --app_usr traksmart --app_serv_ip 172.20.19.150 --artifact_download_dir NIL --custom_customer CGV --max_ping_tries 30 --sleep_time 10\n";
    print "  perl $0 --verbose --build_serv_url http://172.20.19.61:8080 --nexus_repo_url http://fosbpaeecdev01:8081/nexus/content/repositories --inst_proc_script /path/to/processInstanceServProcess.sh --web_serv_script /etc/init.d/jetty --web_serv_config_file /etc/default/jetty --build_job TA-TRUNK --build_num 23 --app_usr tradeally --app_serv_ip 172.20.19.106 --artifact_download_dir NIL --custom_customer NONE --trigger_other_build CMS --max_ping_tries 30 --sleep_time 10\n";
    print "  perl $0 --verbose --build_serv_url http://172.20.19.61:8080 --nexus_repo_url http://fosbpaeecdev01:8081/nexus/content/repositories --inst_proc_script /path/to/processInstanceServProcess.sh --web_serv_script /etc/init.d/jetty --web_serv_config_file /etc/default/jetty --build_job TS-HEAD --build_num 123 --app_usr traksmart --app_serv_ip 192.168.48.110 --artifact_download_dir /tmp/192.168.48.64_TS-rel-5.2.1_60.2014-03-19-18-02-28 --custom_customer CGV --max_ping_tries 30 --sleep_time 10\n";
    print "\n";
    exit(1);
}

##########################################################################
# getArgs() => <%parsedArgs>
#    Parses command-line arguments and returns a (reference of) hash table
#    of the argument values.
##########################################################################
sub getArgs
{
   my %opts=( # Enable verbose by default
              verbose => 1,
              # Denotes to send relevant email notification by default
              do_email_notification => 1,
              # Default email TO list for sending email about deployment error(s)
              #(e.g. script errors, missing script, deployment configuration file, etc)
              deployerr_mail_to => "mchu\@nexant.com",
              # Default email CC list for sending email about deployment error(s)
              #(e.g. script errors, missing script, deployment configuration file, etc)
              deployerr_mail_cc => "mchu\@nexant.com",
              # Denotes automatically stopping app. instance by default
              manual_stop_appInst => 0,
              # Denotes automatically starting app. instance by default
              manual_start_appInst => 0,
              # Denotes manually stopping Intalio by default
              manual_stop_intalio => 1,
              # Denotes manually starting Intalio by default
              manual_start_intalio => 1,
              # Denotes manually stopping Jasper by default
              manual_stop_jasper => 1,
              # Denotes manually starting Jasper by default
              manual_start_jasper => 1,
              # Denotes manually stopping LDAP by default
              manual_stop_ldap => 1,
              # Denotes manually starting LDAP by default
              manual_start_ldap => 1,
              # Denotes manually switch off rtvscand by default
              manual_switchoff_rtvscand => 1,
              # Denotes manually switch on rtvscand by default
              manual_switchon_rtvscand => 1,
              # Denotes manually (or do not) back up LDAP by default
              manual_bk_ldap => 1,
              # Denotes manually (or do not) back up Intalio by default
              manual_bk_intalio => 1,
              # Denotes manually (or do not) back up Jasper by default
              manual_bk_jasper => 1,
              # Denotes manually (or do not) back up the documents directory by default
              manual_bk_docsdir => 1,
              # Denotes manually (or do not) back up the application database by default
              manual_bk_appdb => 1,
              # For QA or DEV by default
              artifact_download_dir => "NIL",
              # No customizations by default
              custom_customer => "NONE",
              # Do not deploy CMS build by default
              trigger_other_build => "NONE",
            );

   if ( @ARGV > 0 )
   {
       GetOptions( \%opts,
                   'build_serv_url:s',
                   'nexus_repo_url:s',
                   'inst_proc_script:s',
                   'web_serv_name:s',
                   'web_serv_script:s',
                   'web_serv_config_file:s',
                   'ldap_ctl_script:s',
                   'intalio_ctl_script:s',
                   'jasper_ctl_script:s',
                   'rtvscand_ctl_script:s',
                   'db_bk_script:s',
                   'db_bkdir:s',
                   'ldap_bk_script:s',
                   'ldap_full_bkdir:s',
                   'intalio_bk_script:s',
                   'jasper_bk_script:s',
                   'svn_repo_path=s',
                   'svn_txn_id=s',
                   'build_job=s',
                   'build_num=i',
                   'app_usr=s',
                   'app_serv_ip=s',
                   'email_to_list:s',
                   'email_cc_list:s',
                   'db_usr:s',
                   'db_passwd:s',
                   'deployerr_mail_to:s',
                   'deployerr_mail_cc:s',
                   'artifact_download_dir:s',
                   'custom_customer:s',
                   'trigger_other_build:s',
                   'max_ping_tries:i',
                   'sleep_time:i',
                   'do_email_notification:i',
                   'manual_stop_appInst:i',
                   'manual_start_appInst:i',
                   'manual_stop_intalio:i',
                   'manual_start_intalio:i',
                   'manual_stop_jasper:i',
                   'manual_start_jasper:i',
                   'manual_stop_ldap:i',
                   'manual_start_ldap:i',
                   'manual_switchoff_rtvscand:i',
                   'manual_switchon_rtvscand:i',
                   'manual_bk_ldap:i',
                   'manual_bk_intalio:i',
                   'manual_bk_jasper:i',
                   'manual_bk_docsdir:i',
                   'manual_bk_appdb:i',
                   'v|verbose',
                   'h|help',
				   'workflow_engine:s'
       ) or Usage();
   }

   Usage() if ( defined( $opts{h} ) || defined( $opts{help} ) );

   my $msg;

   # Preemptive check: app_serv_ip -- Not necessary as it's been pre-checked by the deployment driver/startup script but just in case...
   if ( $opts{app_serv_ip} )
   {
      unless( &isValidIP( $opts{app_serv_ip} ) )
      {
         $msg = "The given application server IP, " . $opts{app_serv_ip} . " is invalid -- Either not of a valid IP address format or not ping'able! Please verify.";
         &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
         &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid application server IP is given!", $msg );
         exit(1);
      }
   }

   if ( substr( $opts{app_serv_ip}, 0, 3 ) =~ "172" )
   {
      # Preemptive check: build_serv_url
      if ( $opts{build_serv_url} )
      {
         unless( &isValidURL($opts{build_serv_url}) )
         {
            $msg = "The given build server URL, " . $opts{build_serv_url} . " is invalid -- Likely due to a typo! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid build server URL is given!", $msg );
            exit(1);
         }
      }

      # Preemptive check: nexus_repo_url
      if ( $opts{nexus_repo_url} )
      {
         unless( &isValidURL($opts{nexus_repo_url}) )
         {
            $msg = "The given Nexus Maven repository URL, " . $opts{nexus_repo_url} . " is invalid -- Likely due to a typo! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid Nexus Maven repository URL is given!", $msg );
            exit(1);
         }
      }
   }

   # Preemptive check: inst_proc_script
   if ( $opts{inst_proc_script} )
   {
      unless ( &isValidScript( $opts{inst_proc_script} ) )
      {
         $msg = "The given script, '". $opts{inst_proc_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
         &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
         &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid inst_proc_script is given!", $msg );
         exit(1);
      }
   }

   # Preemptive check: web_serv_script
   if ( $opts{web_serv_script} )
   {
      unless ( &isValidScript( $opts{web_serv_script} ) )
      {
         $msg = "The given script, '". $opts{web_serv_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
         &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
         &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid web_serv_script is given!", $msg );
         exit(1);
      }
   }

   # Preemptive check: web_serv_config_file
   if ( $opts{web_serv_config_file} )
   {
      unless ( &isValidScript( $opts{web_serv_config_file} ) )
      {
         $msg = "The given script, '". $opts{web_serv_config_file} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
         &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
         &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid web_serv_config_file is given!", $msg );
         exit(1);
      }
   }

   if ( substr( $opts{app_serv_ip}, 0, 3 ) =~ "192" )
   {
      # Preemptive check: ldap_ctl_script
      if ( $opts{ldap_ctl_script} )
      {
         unless ( &isValidScript( $opts{ldap_ctl_script} ) )
         {
            $msg = "The given script, '". $opts{ldap_ctl_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid ldap_ctl_script is given!", $msg );
            exit(1);
         }
      }

      # Preemptive check: intalio_ctl_script -- Intalio will be checked seperately as it's on a remote server and we don't have enough info at this point to check this
      #if ( $opts{intalio_ctl_script} )
      #{
      #   unless ( &isValidScript( $opts{intalio_ctl_script} ) )
      #   {
      #        &LOG( \*STDERR, sprintf("\nWARNING: The given script, '%s', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify. Abort deployment...\n\n", $opts{intalio_ctl_script}) );
      #   }
      #}

      # Preemptive check: jasper_ctl_script
      if ( $opts{jasper_ctl_script} )
      {
         unless ( &isValidScript( $opts{jasper_ctl_script} ) )
         {
            $msg = "The given script, '". $opts{jasper_ctl_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid jasper_ctl_script is given!", $msg );
            exit(1);
         }
      }

      # Preemptive check: rtvscand_ctl_script
      if ( $opts{rtvscand_ctl_script} )
      {
         unless ( &isValidScript( $opts{rtvscand_ctl_script} ) )
         {
            $msg = "The given script, '". $opts{rtvscand_ctl_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file!";
            &LOG(\*STDERR, "*WARNING* " . $msg . " Deployment will go on but expect some delay due to the virus scan. Please verify and fix it.\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid rtvscand_ctl_script is given!", $msg );
            #exit(1);
         }
      }

      # Preemptive check: db_bk_script
      if ( $opts{db_bk_script} )
      {
         unless ( &isValidScript( $opts{db_bk_script} ) )
         {
            $msg = "The given script, '". $opts{db_bk_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid db_bk_script is given!", $msg );
            exit(1);
         }
      }

      # Preemptive check: ldap_bk_script
      if ( $opts{ldap_bk_script} )
      {
         unless ( &isValidScript( $opts{ldap_bk_script} ) )
         {
            $msg = "The given script, '". $opts{ldap_bk_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid ldap_bk_script is given!", $msg );
            exit(1);
         }
      }

      # Preemptive check: intalio_bk_script -- Intalio will be checked seperately as it's on a remote server
      #   if ( $opts{intalio_bk_script} )
      #   {
      #      unless ( &isValidScript( $opts{intalio_bk_script} ) )
      #      {
      #          &LOG( \*STDERR, sprintf("\nWARNING: The given script, '%s', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify. Abort deployment...\n\n", $opts{intalio_bk_script}) );
      #      }
      #   }

      # Preemptive check: jasper_bk_script
      if ( $opts{jasper_bk_script} )
      {
         unless ( &isValidScript( $opts{jasper_bk_script} ) )
         {
            $msg = "The given script, '". $opts{jasper_bk_script} ."', either does not exist or is not an executable file (i.e. missing the 'x' permission), or is an empty file! Please verify.";
            &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
            &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid jasper_bk_script is given!", $msg );
            exit(1);
         }
      }
   }

   # Preemptive check: build_job
   if ( $opts{build_job} )
   {
      if( &genAppName(substr($opts{build_job}, 0, 2) ) =~ "FAILED" )
      {
          $msg = "The given build job, " . $opts{build_job} . " is bad -- Likely due to a typo! Please double-check the build server for it.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Bad build job is given!", $msg );
          exit(1);
      }
   }

   my $res;

   # Preemptive check: email_to_list
   if ( $opts{email_to_list} )
   {
      $res = &isValidEmailAddress( $opts{email_to_list} );
      unless( $res =~ "VALID" )
      {
          $msg = "The given email_to_list, " . $opts{email_to_list} . " is not valid--It must be of a \@nexant.com one! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid email_to_list argument is given!", $msg );
          exit(1);
      }
   }

   # Preemptive check: email_cc_list
   if ( $opts{email_cc_list} )
   {
      $res = &isValidEmailAddress( $opts{email_cc_list} );
      unless( $res =~ "VALID" )
      {
          $msg = "The given email_cc_list, " . $opts{email_cc_list} . " is not valid--It must be of a \@nexant.com one! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid email_cc_list argument is given!", $msg );
          exit(1);
      }
   }

   if ( defined($opts{db_usr}) && $opts{db_usr} =~ /^\s*$/ )
   {
      $msg = "The given db_usr is not valid (as it contains only white-space and nothing else)! Let's be seriously and try again!!";
      &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
      &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid db_usr argument is given!", $msg );
      exit(1);
   }

   if ( defined($opts{db_passwd}) && $opts{db_passwd} =~ /^\s*$/ )
   {
      $msg = "The given db_passwd is not valid (as it contains only white-space and nothing else)! Let's be seriously and try again!!";
      &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
      &sendEmail( $opts{deployerr_mail_to}, $opts{deployerr_mail_cc}, "*PROBLEM* Invalid db_passwd argument is given!", $msg );
      exit(1);
   }

   return( \%opts );
}

##########################################################################
# isValidScript( <scriptPath> )
#   Checks to see if the given script/file is valid
#
# <scriptPath>
#   Full path of the script/file to be checking
##########################################################################
sub isValidScript
{
   my ($scriptPath) = @_;

   # /etc/default/jetty does not need the 'x' permission, while /opt/jasper/ctlscript.sh and
   # /opt/jasper_backups/jasper_backups.sh can only has the 'x' set for the user (i.e. root)
   # so won't be able to check by the application user account (e.g. traksmart) under whcihc
   # this deployment script is running
   if ( $scriptPath =~ m{^/etc/default/jetty} || $scriptPath =~ m{^/opt/jasper/ctlscript.sh} ||
                                      $scriptPath =~ m{^/opt/jasper_backups/jasper_backups.sh} )
   {
      return( -s $scriptPath && -f $scriptPath );
   }
   else
   {
      return( -s $scriptPath && -f $scriptPath && -x $scriptPath );
   }
}

##########################################################################
# isValidRemoteScript( <scriptPath> <usr> <remoteHost> )
#   Checks to see if the given script/file on a remote host is valid
#
# <scriptPath>
#   Full path of the script/file to be checking
#
# <usr>
#   The user for accessing the remote host
#
# <remoteHost>
#   The remote host on which the script/file to be checking is located
##########################################################################
sub isValidRemoteScript
{
   my ($scriptPath, $usr, $remoteHost) = @_;

   #my $cmd = "ssh -i /home/".$usr."/.ssh/id_rsa_".$usr." ".$usr."@".$remoteHost. " \"test -s ". $scriptPath ." && test -f ". $scriptPath ." && test -x ". $scriptPath ." && echo 'VALID'\"";
   my $cmd = "ssh ".$usr."@".$remoteHost. " \"test -s ". $scriptPath ." && test -f ". $scriptPath ." && test -x ". $scriptPath ." && echo 'VALID'\"";
   my $res =`$cmd`;
   $res = &trim($res);

   if ( $res =~ "VALID" ) { return( TRUE ); }
   return( FALSE );
}


##########################################################################
# readConfigFile( <configFilePath> ) => <%configData>
#   Retrieves config data from the given config file, and returns the data
#   in a (reference of) hash table.
#
# <configFilePath>
#   Full path of the config file to be read.
##########################################################################
sub readConfigFile
{
   my $configFilePath = shift;

   my %configData = ();
   my ($name, $val);

   my $fd = &openFile( $configFilePath, "<" );
   while ( my $line = <$fd> )
   {
        # Skip empty line and comment line
        next if ( $line =~ /^\s*$/ || $line =~ /^\s*$|#/ );

        # Only process line in the <name>=<value> format
        if ( index( $line, "=" ) >= 0 )
        {
            ($name, $val) = split( '=', $line );
            $configData{&trim($name)} = &trim($val);
        }
   }

   close( $fd );
   return( \%configData );
}

##########################################################################
# isBuildJobAndAppUsrMatch( <app_key> <app_usr> )
#    Verifies that build_job & app_usr do match.
#
# <app_key>
#   The key uses for generating an application name
# <app_usr>
#   The application user ID under which the application is running
##########################################################################
sub isBuildJobAndAppUsrMatch
{
    my ($app_key, $app_usr) = @_;

    switch ($app_key)
    {
       case "TS"
       {
           if ( ($app_usr =~ /^traksmart$/) || ($app_usr =~ /^autotest$/) )
           {
              return( TRUE );
           }
           return( FALSE );
       }
       case "TA"
       {
           if ($app_usr =~ /^tradeally$/)
           {
              return( TRUE );
           }
           return( FALSE );
       }
       case "TR"
       {
           if ($app_usr =~ /^trl$/)
           {
              return( TRUE );
           }
           return( FALSE );
       }
       case "DR"
       {
           if ($app_usr =~ /^dr360$/)
           {
              return( TRUE );
           }
           return( FALSE );
       }
       case "GR"
       {
           if ($app_usr =~ /^nexant-dm360$/)
           {
              return( TRUE );
           }
           return( FALSE );
       }
       case "ES"
       {
           if ($app_usr =~ /^goldengate$/)
           {
              return( TRUE );
           }
           return( FALSE );
       }
    }
}

##########################################################################
# genAppName( <app_key> ) => <app_name>
#    Generates an application name based on the given key.
#
# <app_key>
#   The key uses for generating an application name
##########################################################################
sub genAppName
{
    my ($app_key) = shift;

    switch ($app_key)
    {
       case "TS" { return( "traksmart4" ); }
       case "TA" { return( "tradeally" ); }
       case "cm" { return( "cms" ); }
       case "TR" { return( "trl" ); }
       case "DR" { return( "dr360" ); }
       case "GR" { return( "nexant-dm360" ); }
       case "ES" { return( "goldengate" ); }
       else      { return( "FAILED" ); }
    }
}

##########################################################################
# genEmailList( <raw_email_line> ) => (<email_list>)
#    Generates a raw email list into a formated one.
#
# <raw_email_line>
#   The raw email list.
##########################################################################
sub genEmailList
{
    my ($line) = shift;

    my $email_list;

    # If the given raw email list contains ':', it means there are
    # more than one email addresses in the list, which will need to
    # be handled accdordingly
    if ( index($line, ":") >= 0 )
    {
       $email_list = join( ", ", split(/:/, $line) );
    }
    else
    {
       $email_list = $line;
    }

    return( $email_list );
}

##########################################################################
# isValidEmailAddress( <raw_email_line> )
#    Verifies that the given email address/list of email address
#    is/contains invalid email address(es).
#
# *TODO*
#    Use the Email::Valid CPAN module to do the validation BUT if we can
#    convince OPS to install it on all, especially Staging/Prod., servers
##########################################################################
sub isValidEmailAddress
{
    my ($raw_email_line) = @_;

    my @email_list;
    # If the given raw email list contains ',', it means there are
    # more than one email addresses in the list, which will need to
    # be handled accdordingly
    if ( index($raw_email_line, ",") >= 0 )
    {
       @email_list = split(/,/, $raw_email_line );
       foreach (@email_list)
       {
           $_ = &trim( $_ );
           return( $_ ) unless ( $_ =~ /.*\@nexant.com$/ || $_ =~ /.*\@cybage.com$/ );
       }
    }
    else
    {
       $raw_email_line = &trim( $raw_email_line );
       return( $raw_email_line ) unless ( $raw_email_line =~ /.*\@nexant.com$/ || $_ =~ /.*\@cybage.com$/ );
    }
    return( "VALID" );
}

##########################################################################
# getEmailList( <app_key> <env> <brs_hash> ) => (<email_to>, <email_cc>)
#    Generates email-to & email-cc lists based on application & runtime
#    environment
#
# <app_key>
#   The key associated with an application
#
# <env>
#   The runtime environment (i.e. qa, dev, demo, staging, prod)
#
# <brs_hash>
#   Hash table of the default BRS data retrieved from the .BRS.conf file
##########################################################################
sub getEmailList
{
    my ($app_key, $runtimeEnv, $brs_hash) = @_;

    my ($email_to, $email_cc);

    # Generate the application name using the given app_key
    my $app_name = &genAppName( $app_key );

    $email_to = $brs_hash->{ $app_name."_".$runtimeEnv."_mail_to" };
    $email_cc = $brs_hash->{ $app_name."_".$runtimeEnv."_mail_cc" };

    return( $email_to, $email_cc );
}

##########################################################################
# isValidURL( <url> )
#    Checks whether the given URL is a valid/running one or not.
#
# <url>
#   The URL to be verified.
##########################################################################
sub isValidURL
{
    my ($url) = shift;

    return ( defined(get($url)) || defined(head($url)) );
}

##########################################################################
# isValidBuildJob( <buildJob> )
#    Verifies if the given (e.g. Jenkins) build job is a valid one or not.
#
# <buildJob>
#    The build (e.g. Jenkins) job to be verified.
##########################################################################
sub isValidBuildJob
{
    my ($buildJob) = shift;
    return ( &isValidURL($buildJob) );
}

##########################################################################
# isValidBuildNum( <buildNum> )
#    Verifies if the given (e.g. Jenkins) build num is a valid one or not.
#
# <buildNum>
#    The build (e.g. Jenkins) job to be verified.
##########################################################################
sub isValidBuildNum
{
    my ($buildNum) = shift;
    return ( &isValidURL($buildNum) );
}

##########################################################################
# isValidIP( <ip> )
#    Checks if the given IP adress is a valid one or not
#
# <ip>
#    The IP address to be verified.
##########################################################################
sub isValidIP
{
    my ($ip) = shift;

    # Don't even bother to ping it if the given IP is not of a valid ip format
    #unless( $ip =~ /^([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])$/ )
    unless( $ip =~ /^([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])$/ )
    {
       return( FALSE );
    }

    my $p = Net::Ping->new();

    # Specifying the "icmp" protocol requires that the program be run as root
    # or that the program be setuid to root--Not doable for us?
    # my $p = Net::Ping->new( "icmp" );
    my $status = $p->ping($ip);
    $p->close();
    return( $status );
}

##########################################################################
# openFile( <file> <mode> )
#    Opens a file (with error handling) and return a file handle.
#
# <file>
#    The file to be opened.
#
# <mode>
#    The fopen mode.
##########################################################################
sub openFile
{
    my ($file, $mode) = @_;
    my $fd;
    unless ( open($fd, $mode, "$file") )
    {
        &LOG(\*STDERR, "*ERROR* open '$file' failed -- $! Please verify. Abort deployment...\n\n");
        exit(1);
    }
    return( $fd );
}

##########################################################################
# getFileModifyTime( <fileName> <format>)
#    Gets the last modify time of a file based on the given format.
# <format>
#    'desc'    : gets the full description of the last modify time for
#                logging purpose as needed
#    'str'     : gets the last modify time into a single string
#                (This is for using it as an file extension)
##########################################################################
sub getFileModifyTime
{
    my ($fileName, $format) = @_;

    &LOG( \*STDOUT, sprintf( "INFO: Getting the last modify time of '%s (in %s format)'.\n", $fileName, $format ) );

    # Make 'desc' default in case empty <format> option was given
    $format = 'desc' if ( !defined($format) );

    # Not supported in Perl version 5.8.8
    my $last_mod_time = stat($fileName)->mtime;
    #my $last_mod_time = (stat($fileName))[9];

    unless( defined( $last_mod_time ) )
    {
       &LOG( \*STDERR, "*ERROR* Failed to get the last modify time of '%fileName'! Perhaps the file does not exist. Please verify. Abort deployemnt...\n" );
       exit(1);
    }

    if ( $format =~ "desc" )
    {
        return( scalar(localtime($last_mod_time) ) );
    }
    else
    {
        return( strftime('%Y-%m-%d-%H-%M-%S', localtime($last_mod_time) ) );
    }
}

##########################################################################
# genDateStr( <format> ):
#    Generates a time string based on the given format.
#
# <format>
#    'dir'      : for using as an directory name
#    'fext'     : for using as an file extension
#    'timestamp': for using as a timestamp (to be adding into a log file)
##########################################################################
sub genDateStr
{
    my ($format) = shift;

    # Make 'fext' as default if empty string was given
    $format = 'fext' if ( !defined($format) );

    my $timeStr;
    switch ( $format )
    {
          case 'dir'
          {
              $timeStr = `date \"+%d-%b-%Y\"`;  #21-Aug-2012
              chomp ($timeStr);
          }
          case 'fext'
          {
              $timeStr = `date \"+%d-%b-%Y_%H-%M-%S-%Z\"`;  #21-Aug-2012_17-46-08-PDT
              chomp ($timeStr);
          }

          case 'timestamp'
          {
              $timeStr = `date \"+%d-%b-%Y %T %Z\"`;  #21-Aug-2012 17:51:06 PDT
              chomp ($timeStr);
          }
    }
    return $timeStr;
}

##########################################################################
# LOG( <fd>, <str>)
#   Dumps output string to the given file descriptor.
#
# <fd>
#    File descriptor of a file (or STDOUT, STDERR) of whcih to dump the
#    output string
# <str>
#    The output string to be dumping to the log file
##########################################################################
sub LOG
{
    my ($fd, $str) = @_;

    my $timestamp = &genDateStr('timestamp');
    print $fd "[$timestamp] $str";
}

##########################################################################
# trim():
#    Removes leading/trailing whitespace in a string
##########################################################################
sub trim
{
   my $string = shift;
   $string =~ s/^\s+//;
   $string =~ s/\s+$//;
   return $string;
}

##########################################################################
# getRelVersion( <jobName> )
#   Retrieves the release version (e.g. 5.2.1, HEAD, etc) through parsing
#   the build job name.
#
# <jobName>
#   The (Jenkins) build job by which the artifact to be released/deployed
#   is built.
##########################################################################
sub getRelVersion
{
    my ($jobName) = shift;

    my $relVer;
    my @vals = split('-', $jobName);
    if ( $vals[1] =~ /HEAD/ )
    {
       $relVer = "$vals[1]";
    }
    else
    {
       $relVer = &trim( $vals[2] );
    }

    return $relVer;
}

##########################################################################
# createDir( <dir> )
#   Safely creates the given directory.
#
# <dir>
#    The directory to be created.
##########################################################################
sub createDir
{
    my ($dir) = shift;

    unless( defined eval {mkpath("$dir", 0, 0755)} )
    {
        &LOG(\*STDERR, "*ERROR* Failed to create dirctory, $dir -- $! Please verify. Abort deployment...\n\n");
        exit(1);
    }
}

##########################################################################
# createSymLink( <src>, <dest>)
#   Safely creates a symbolic link
#
# <src>
#    The sym. link name
#
# <dest>
#    The actual file/directory that <src> will be pointing to
##########################################################################
sub createSymLink
{
    my ($src, $dest) = @_;
    unless( symlink($src, $dest) )
    {
        &LOG(\*STDERR, "*ERROR* Failed to sym. link $src to $dest -- $! Please verify. Abort deployment...\n\n");
       exit(1);
    }
}

##########################################################################
# readSymLink( <file> )
#   Safely reads the value of a symbolic link, and returns it if symbolic
#   links are implemented.
#
# <file>
#    The name of symbolic link to be read.
##########################################################################
sub readSymLink
{
    my ($file) = shift;

    my $linkValue;
    unless( defined($linkValue = readlink($file)) )
    {
        &LOG(\*STDERR, "*ERROR* Failed to read the sym. link value of $file -- $! Please verify. Abort deployment...\n\n");
        exit(1);
    }
    return( $linkValue );
}

##########################################################################
# CopyFile( <src>, <dest>)
#   Safely copies a file If the destination (second argument) already
#   exists and is a directory, and the source (first argument) is not
#   a filehandle, then the source file will be copied into the directory
#   specified by the destination, using the same base name as the source
#   file. It's a failure to have a filehandle as the source when the
#   destination is a directory.
#
# <src>
#    The file/directory to be copying to <dest>
#
# <dest>
#    The file/directory which <src> will be copying to
##########################################################################
sub CopyFile
{
    my ($src, $dest) = @_;
    unless( copy($src, $dest) )
    {
       &LOG(\*STDERR, "*ERROR* Failed to copy $src to $dest -- $! Please verify. Abort deployment...\n\n");
       exit(1);
    }
}

##########################################################################
# moveFile( <src>, <dest>)
#   Safely moves/renames a file/directory (If the destination already
#   exists and is a directory, and the source is not a directory, then
#   the source file will be renamed into the directory specified by the
#   destination).
#
# <src>
#    The file/directory to be moving/renaming to <dest>
#
# <dest>
#    The file/directory which <src> will be moving/renaming to
##########################################################################
sub moveFile
{
    my ($src, $dest) = @_;
    unless( move($src, $dest) )
    {
       &LOG(\*STDERR, "*ERROR* Failed to move/rename $src to $dest -- $! Please verify. Abort deployment...\n\n");
       exit(1);
    }
}

##########################################################################
# changeDir( <dir> )
#   Safely cd to the given directory.
#
# <dir>
#    The directory to be cd into
##########################################################################
sub changeDir
{
    my ($dir) = shift;
    unless( chdir($dir) )
    {
       &LOG(\*STDERR, "*ERROR* Failed to chdir $dir -- $! Please verify. Abort deployment...\n\n");
       exit(1);
    }
}

##########################################################################
# removeFile( <file> )
#   Safely remove the given file or directory.
#
# <file>
#    The file or directory to be created.
##########################################################################
sub removeFile
{
    my ($file) = shift;

    # If it's a directory...
    if ( -d $file )
    {
        unless( defined eval {rmtree("$file", 0, 0755)} )
        {
            &LOG(\*STDERR, "*ERROR* Failed to remove dirctory $file -- $! Please verify. Abort deployment...\n\n");
            exit(1);
        }
        &LOG( \*STDOUT, "INFO: Dirctory '${file}' is removed.\n" );
   }
   # Otherwise
   else
   {
       unless( unlink($file) )
       {
            &LOG(\*STDERR, "*ERROR* Failed to remove file $file -- $! Please verify. Abort deployment...\n\n");
           exit(1);
       }
       &LOG( \*STDOUT, "INFO: File '${file}' is removed.\n" );
   }
}

##########################################################################
# checkAppInstanceStatus( <instanceURL> )
#   Checks the status of an application instance by doing a wget on
#   the given instance URL (as for unknown reason Perl get/head do not
#   work well in this case.
#
# <instanceURL>
#   The URL of instance to be checked.
#
##########################################################################
sub checkAppInstanceStatus
{
   my ($instanceURL) = shift;

   my $fext = &genDateStr('fext');
   my $wget_log = "/tmp/appInstanceStatus.log_$fext";

   system( "rm -f /tmp/appInstanceStatus.log_*");
   system( "wget --no-check-certificate --delete-after $instanceURL 2> ${wget_log}");

   my $grepRes = `grep \"Unavailable\" $wget_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/Unavailable/i )
   {
      return( "EXCEPTION" );
   }

   $grepRes = `grep \"refused\" $wget_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/refused/i )
   {
      return( "IN-PROGRESSIVE" );
   }

   $grepRes = `grep \"Giving up\" $wget_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/Giving up/i )
   {
      return( "TIMEOUT" );
   }

   $grepRes = `grep \"connected\" $wget_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/connected/i )
   {
      return( "RUNNING" );
   }

   # Not likely to happen but just in case ...
   return( "UNKNOWN" );
}

##########################################################################
# checkAppInstance( <instanceURL>, <status> )
#   Checks if the given application instance starts up successfully
#   (by doing a wget on the instance URL) as (for unknown reason)
#   get/head do not work well in this case.
#
# <instanceURL>
#   The (URL of the) instance to ping/wait -- This is used for ping/wait
#   the application instance
#
# <status>
#   The status to check for
#
##########################################################################
sub checkAppInstance
{
   my ($instance, $status) = @_;

   my $res = &checkAppInstanceStatus( $instance );

   switch ($res)
   {
       case "EXCEPTION"
       {
          &LOG(\*STDERR, "*ERROR* The application instance process is currently running but in an error state due to certain exception/error in previous startup attempt. \nPlease check the log file(s) under the application user's home directory or web server (e.g. jetty) logs directory.\n\n");
          if ( $status =~ "startup" )
          {
             $status = "shutdown";
          }
          else
          {
             $status = "startup";
          }
       }
       case "IN-PROGRESSIVE"
       {
          &LOG(\*STDOUT, "INFO: Currently, the application instance is still not completely $status yet.\n\n");
          if ( $status =~ "startup" )
          {
             $status = "shutdown";
          }
       }
       case "TIMEOUT"
       {
          &LOG(\*STDERR, "*ERROR* wget's attempt to connect the application instance failed and timed out.\n\n");
          if ( $status =~ "startup" )
          {
             $status = "shutdown";
          }
          else
          {
             $status = "startup";
          }
       }
       case "RUNNING"
       {
          &LOG(\*STDOUT, "INFO: The application instance is currently up and running.\n\n");
          if ( $status =~ "shutdown" )
          {
             $status = "startup";
          }
       }
       case "UNKNOWN"
       {
          &LOG(\*STDERR, "*ERROR* wget failed to connect the application instance due to unknown reason -- Check the /tmp/appInstanceStatus.log_* file to find out.\n\n");
          if ( $status =~ "startup" )
          {
             $status = "shutdown";
          }
          else
          {
             $status = "startup";
          }
       }
   }
   return( $status );
}

##########################################################################
# waitLDAPinstance( <ctlScript> <status> )
#   Checks if the given LDAP is currently running
#
# <ctlScript>
#   The path of the LDAP control script (i.e. /etc/init.d/ldap)
#
# <status>
#   The status to check for
#
##########################################################################
sub waitLDAPinstance
{
   my ($ctlScript, $status) = @_;

   my $fext = &genDateStr('fext');
   my $status_log = "/tmp/ldapStatus.log_$fext";

   system( "rm -f /tmp/ldapStatus.log_*");
   system( "sudo $ctlScript status > ${status_log}");

   my $grepRes = `grep \"running\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/running/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "startup" );
   }

   $grepRes = `grep \"stopped\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/stopped/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "shutdown" );
   }
}

##########################################################################
# waitIntalioInstance( <ctlScript> <intalioHost> <appUsr> <status> )
#   Checks if the given Intalio is currently running
#
# <ctlScript>
#   The path of the Intalio control script (i.e. /etc/init.d/cloud)
#
# <intalioHost>
#   The Intalio host/ip
#
# <appUsr>
#   The user name (e.g. traksmart) under which the application is
#   running -- This is used for pinging/waiting Intalio
#
# <status>
#   The status to check for
#
##########################################################################
sub waitIntalioInstance
{
   my ($ctlScript, $intalioHost, $appUsr, $status) = @_;

   my $fext = &genDateStr('fext');
   my $status_log = "/tmp/IntalioStatus.log_$fext";

   system( "rm -f /tmp/IntalioStatus.log_*");

   # The "-t -t" option somehow does not work well with Intalio (see SCM-3663)
   #my $cmd = "ssh -t -t -i /home/".$appUsr."/.ssh/id_rsa_".$appUsr." ".$appUsr."@".$intalioHost. " sudo ".$ctlScript. " status > ".$status_log;
   #my $cmd = "ssh -i /home/".$appUsr."/.ssh/id_rsa_".$appUsr." ".$appUsr."@".$intalioHost. " sudo ".$ctlScript. " status > ".$status_log;
   my $cmd = "ssh ".$appUsr."@".$intalioHost. " sudo ".$ctlScript. " status > ".$status_log;
   &execCmd( "$cmd" );

   # See if the "pid" string exists in the log file
   my $grepRes = `grep \"pid\" $status_log`;
   $grepRes = &trim($grepRes);

   &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );

   # If result of grepping "pid" returns somethings--Intalio is running
   if( $grepRes )
   {
       return( "startup" );
   }
   return( "shutdown" );
}

##########################################################################
# waitJasperInstance( <ctlScript> <instanceKey> <status> )
#   Checks if the given Jasper is currently running
#
# <ctlScript>
#   The path of the Jasper control script (i.e. /opt/jasper/ctlscript.sh)
#
# <instanceKey>
#   The key for determining which instance to ping/wait
#
# <status>
#   The status to check for
#
##########################################################################
sub waitJasperInstance
{
   my ($ctlScript, $instanceKey, $status) = @_;

   my $fext = &genDateStr('fext');
   my $status_log = "/tmp/jasperStatus.log_$fext";

   my ($name, $proc) = split( '-', $instanceKey );
   my $cmd;
   if ( $proc =~ "all" )
   {
      $cmd = "sudo $ctlScript status > ${status_log}";
   }
   else
   {
      $cmd = "sudo $ctlScript status $proc > ${status_log}";
   }

   system( "rm -f /tmp/jasperStatus.log_*" );
   &execCmd( "$cmd" );

   my $grepRes = `grep \"already running\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/already running/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "startup" );
   }

   $grepRes = `grep \"not running\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/not running/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "shutdown" );
   }
}

##########################################################################
# waitRtvscand( <ctlScript> <status> )
#   Checks if the given waitRtvscand is currently switching on
#
# <ctlScript>
#   The path of the rtvscand control script
#
# <status>
#   The status to check for
#
##########################################################################
sub waitRtvscand
{
   my ($ctlScript, $status) = @_;

   my $fext = &genDateStr('fext');
   my $status_log = "/tmp/rtvscandStatus.log_$fext";

   system( "rm -f /tmp/rtvscandStatus.log_*" );
   system( "sudo $ctlScript status > ${status_log}");

   my $grepRes = `grep \"rtvscand is running\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/rtvscand is running/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "startup" );
   }

   $grepRes = `grep \"rtvscand is not running\" $status_log`;
   $grepRes = &trim($grepRes);
   if ( $grepRes =~ m/rtvscand is not running/i )
   {
       &LOG( \*STDOUT, sprintf( "INFO: '%s' \n", $grepRes) );
       return( "shutdown" );
   }
}

##########################################################################
# pingInstance( <instance>, <instanceHost> <appUsr>
#                           <instanceKey>, <status> )
#   Pings staus of the given instance (e.g. application, Intalio, etc)
#
# <instance>
#   The (URL of the) instance to ping/wait -- This is used for ping/wait
#   the application instance
#
# <instanceHost>
#   The instance hostname/IP -- This is used for pinging/waiting Intalio
#
# <appUsr>
#   The user name (e.g. traksmart) under which the application is
#   running -- This is used for pinging/waiting Intalio
#
# <instanceKey>
#   The key for determining which instance to ping/wait
#
# <status>
#   The status to ping for
#
##########################################################################
sub pingInstance
{
    my ($instance, $instanceHost, $appUsr, $instanceKey, $status) = @_;

    &LOG( \*STDOUT, sprintf( "INFO: Ping'ing the '%s' status of the %s instance.\n", $status, $instanceKey) );

    switch ( $instanceKey )
    {
       case "application"
       {
          return( &checkAppInstance( $instance, $status ) );
       }
       case "ldap"
       {
          return( &waitLDAPinstance( $instance, $status ) );
       }
       case "intalio"
       {
          return( &waitIntalioInstance( $instance, $instanceHost, $appUsr, $status ) );
       }
       case /^jasper/
       {
          return( &waitJasperInstance( $instance, $instanceKey, $status ) );
       }
       case /^rtvscand/
       {
          return( &waitRtvscand( $instance, $status ) );
       }
    }
}

##########################################################################
# waitInstance( <instance>, <instanceHost> <maxPingTries>, <appUsr>,
#                     <sleepTime>, <instanceKey>, <status> )
#   Pings the staus of the given instance repeatedly and wait until
#   either it's up or shutdown or timeout after the given time period.
#
# <instance>
#   The (URL of the) instance to ping/wait -- This is used for ping/wait
#   the application instance
#
# <instanceHost>
#   The instance hostname/IP -- This is used for pinging/waiting Intalio
#
# <appUsr>
#   The user name (e.g. traksmart) under which the application is
#   running -- This is used for pinging/waiting Intalio
#
# <maxPingTries>
#   Number of tries on ping'ing the given instance
#
# <sleepTime>
#   Number of seconds to sleep before ping'ing the given instance again
#
# <instanceKey>
#   The key for determining which instance to ping/wait
#
# <status>
#   The wait status
#
##########################################################################
sub waitInstance
{
    my ($instance, $instanceHost, $appUsr, $maxPingTries, $sleepTime, $instanceKey, $status) = @_;

    my $cnt = 0;

    # Wait time for shutdown/startup non-application instances should be much less
    unless( $instanceKey =~ "application" )
    {
        $sleepTime /= 5;
    }
    while( &pingInstance( $instance, $instanceHost, $appUsr, $instanceKey, $status ) !~ "$status" )
    {
        &LOG( \*STDOUT, sprintf( "INFO: Waiting for the %s instance to %s.\n", $instanceKey, $status) );
        if ( $cnt++ == $maxPingTries )
        {
           &LOG( \*STDOUT, sprintf( "INFO: Giving up after failing to %s the %s instance.\n", $status, $instanceKey ) );

           $status = "TIMEOUT";
           last;
        }
        sleep($sleepTime);
    }
    return( $status );
}

##########################################################################
# execCmd( <cmd> )
#   Executes a command through system() with error checking.
#
# <cmd>
#   The command to be executed
#
##########################################################################
sub execCmd
{
   my ($cmd) = shift;

   unless( $cmd =~ /db_backup/ )
   {
      &LOG(\*STDOUT, "INFO: Executing \"$cmd\"\n");
   }

   unless ( system( $cmd ) == 0 )
   {
      &LOG(\*STDERR, "*ERROR* System $cmd failed -- $!\n");
      exit(1);
   }
  # elsif ($? & 127)
  # {
  #    &LOG(\*STDERR, sprintf( "*ERROR* System %s failed -- died with signal %d, %s coredump\n",
  #          $cmd, ($? & 127),  ($? & 128) ? 'with' : 'without') );
  #    exit(1);
  # }
  # else
  # {
  #    &LOG(\*STDERR, sprintf( "*ERROR* System %s failed -- exited with value %d\n", $cmd, $? >> 8) );
  #    exit(1);
  # }
}

##########################################################################
# backupDocsDir( <this> )
#    Backups the documents directory
#
# <this>
#    The relevant object
#
##########################################################################
sub backupDocsDir
{
  my ($this) = shift;
  my $appName = $this->app_name;

  my $docsDirRoot = "/app/" . $appName;

  # Well, dr360 uses the same documents dir path as traksmart
  if ( $appName =~ "dr360" )
  {
      # TODO: Should avoid hard-coding here but think of a reliable way to dynamically get
      # the right directory path (Perhaps by parsing the ApplicationProperties.groovy file?)
      $docsDirRoot = "/app/traksmart4";
  }

  my $docsDirPath = $docsDirRoot . "/documents";

  &LOG( \*STDOUT, "INFO: Backing up ". $this->instance_name ."'s ". $docsDirPath ." directory.\n" );
  unless( -e $docsDirPath )
  {
      my $msg = $this->instance_name ."'s documetns directory path, " . $docsDirPath . " does not exist! Please verify.";
      &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
      &sendEmail( $this->deployerr_mail_to, $this->deployerr_mail_cc, "*PROBLEM* The documetns directory path is missing!", $msg );
      exit(1);
  }

  my $cmd = "cd $docsDirRoot; tar -zcf documents_bk.tar.gz documents";
  &execCmd( "$cmd" );
  &LOG( \*STDOUT, "INFO: Completed backing up ". $this->instance_name ."'s ". $docsDirPath ." directory.\n" );
}

##########################################################################
# backupDB( <db_bk_script>, <type>, <user>, <passwd>, <host>, <name>,
#                                                    <backupDir>, <tag> )
#    Backups the given database
#
# <db_bk_script>
#    The script that actually performs the DB backup
#
# <type>
#    The DB type
#
# <user>
#    The DB user
#
# <passwd>
#    The DB user password
#
# <host>
#    The DB host
#
# <name>
#   The DB name
#
# <backupDir>
#   The directory to store the DB backup file
#
# <tag>
#   The tag to distinguish whether the backup is done pre war-file
#   installation or not
#
##########################################################################
sub backupDB
{
   my ($db_bk_script, $type, $user, $passwd, $host, $name, $backupDir, $tag) = @_;

   # Check if the backup directory exists, if not create it
   unless( -e $backupDir )
   {
       &LOG(\*STDOUT, "WARNING: $backupDir does not exist -- create it.\n");
       &createDir( $backupDir );
   }
   #my $cmd = "mysqldump -f --user=".$user." --password=".$passwd." --host=".$host." ".$name." | gzip > ${backupDir}/".$name."-".$tag.".sql.gz";

   # Since DB backup usually takes the longerest time to complete,
   # it will be done in the background process so that other backup
   # tasks for LDAP, Intalio, etc can be done concurrently
   my $cmd = "$db_bk_script $type $user $passwd $host $name $backupDir $tag &";
   &execCmd( "$cmd" )
}

##########################################################################
# waitDBbackup( <bkStatusFile>, <maxPingTries>, <sleepTime> )
#   Waits & checks DB backup status
#
# <bkStatusFile>
#   The path of the DB backup status file
#
# <maxPingTries>
#   Number of tries on pinging the DB backup status
#
# <sleepTime>
#   Number of seconds to sleep before pinging the DB backup status
#
##########################################################################
sub waitDBbackup
{
   my ($bkStatusFile, $maxPingTries, $sleepTime) = @_;

   my $cnt = 0;
   my $status;

   while( ! -e $bkStatusFile )
   {
        &LOG( \*STDOUT, "INFO: Waiting for application database backup to complete.\n" );
        if ( $cnt++ == $maxPingTries )
        {
           &LOG( \*STDOUT, sprintf( "INFO: Giving up after application database backup does not complete after more than %d minutes.\n", ($maxPingTries * $sleepTime / 60) ) );
           $status = "TIMEOUT";
           return( $status );
        }
        sleep($sleepTime);
    }

    $status = `cat $bkStatusFile`;
    return( &trim($status) );
}

##########################################################################
# triggerBuild(<build_serv_url>, <build_job>)
#    Triggers a specific build
#
# <build_serv_url>
#    The (Jenkins) build server URL
#
# <build_job>
#    The (Jenkins) build job to be triggered
#
##########################################################################
sub triggerBuild
{
   my ($this) = shift;

   my $build_serv_url = $this->build_serv_url;
   my $build_job = $this->build_job;

   my $build_job_url = "${build_serv_url}/job/$build_job/buildWithParameters?trigger_other_build=$build_job";
   unless( isValidBuildJob( $build_job_url ) )
   {
      my $msg = "Unable to trigger build as the given build job, " . $build_job . " does not exist! Please go to " . $build_serv_url . " and verify.";
      &LOG(\*STDERR, "ERROR* " . $msg . " Aborting deployment...\n\n");
      &sendEmail( $this->deployerr_mail_to, $this->deployerr_mail_cc, "*PROBLEM* Unable to trigger build!", $msg );
      exit(1);
   }

   &LOG(\*STDOUT, "INFO: Triggering the \"$build_job\" build...\n");
   &execCmd( "/usr/bin/curl --user jenkins:snikneJ \"$build_job_url\"" );
}

##########################################################################
# getMailTool() => <mailTool>
#    Returns the mail tool.
#
##########################################################################
sub getMailTool
{
    return( ($^O =~ /linux/) ? '/usr/sbin/sendmail -t -oi' : '/bin/mail' );
}

#############################################################################
# genEmail( <instance_name>, <instance_url>, <build_serv_url>, <app_serv_ip>,
#           <build_job>, <build_num>, <mailType> )
#    Generate deployment heads-up or completion email messages.
#
# ARGUMENTS:
#   <instance_name>
#      The name uses to identify an app. instance (e.g. "PSEG (DSMC) Staging")
#
#   <instance_url>
#      The URL of an app. instance
#
#   <build_serv_url>
#      The (Jenkins) build server URL
#
#   <app_serv_ip>
#      The IP address of an app. instance
#
#   <build_job>
#      The (Jenkins) build job by which the artifact toby which the artifact to be
#      to be released/deployed is built
#
#   <build_num>
#      The (Jenkins) build number associated with the artifact to be released/deployed
#
#   <mailType>
#      Type of email to send -- One of "HEADS-UP", "DEPLOY-DONE",
#      "DEPLOY-FAILED",whichs's used to determine the content of email.
#
# RETURN VALUES:
#   <mailSubject>
#      The email subject line to be generating according to the given
#      mail type.
#
#   <mailMsg>
#      The email message to be generating according to the given mail type.
###########################################################################
sub genEmail
{
    my ($instance_name, $instance_url, $build_serv_url, $app_serv_ip, $build_job, $build_num, $mailType) = @_;

    my $deployEnvDesc = $instance_name . " (" . $app_serv_ip . ") server";
    my ($mailSubject, $mailMsg);
    switch ($mailType)
    {
       case "HEADS-UP"
       {
          $mailSubject = "*HEADS-UP* Deploying ".$build_job." build #".$build_num." to the ".$deployEnvDesc." in a moment";
          $mailMsg = "Hi all, <br><br> \
          The <a href=".$instance_url.">".$deployEnvDesc."</a> will be shutdown in a moment for deploying <b><font color=#ff0000>".$build_job."</b></font> build (<a href=".$build_serv_url."/job/".$build_job."/".$build_num.">#".$build_num."</a>). <br><br>\
          Another email will be sent when the deployment is completed (and the server is restarted).<br><br>Thanks, <br> -Michael <br>";
       }
       case "DEPLOY-DONE"
       {
          $mailSubject = "*COMPLETED* Deploying ".$build_job." build #".$build_num." to the ".$deployEnvDesc;
          $mailMsg = "Hi all, <br><br>
                   Deployment of <b><font color=#ff0000>".$build_job."</b></font> build (<a href=".$build_serv_url."/job/".$build_job."/".$build_num.">#".$build_num."</a>) to the <a href=".$instance_url.">".$deployEnvDesc."</a> is COMPLETED (and the server is restarted). <br><br>\
                   See the detail of changes at ".$build_serv_url."/job/".$build_job."/".$build_num."/changes<br><br>Thanks, <br> -Michael <br>";
       }
       case "DEPLOY-FAILED"
       {
          $mailSubject = "*PROBLEM* deploying ".$build_job." build #".$build_num." to the ".$deployEnvDesc;
          $mailMsg = "Hi all, <br><br> \
                   FYI--It seems that there's a problem deploying <b><font color=#ff0000>".$build_job."</b></font> build (<a href=".$build_serv_url."/job/".$build_job."/".$build_num.">#".$build_num."</a>) to the <a href=".$instance_url.">".$deployEnvDesc."</a>,<br> which is currently under investigation. <br><br>\
                   Another email will be sent when the problem is resolved. Thanks for your patience. <br><br>Regards, <br> -Michael <br>";
       }
       case ["APP_SHUTDOWN_FAILED","LDAP_SHUTDOWN_FAILED","Intalio_SHUTDOWN_FAILED","Jasper_SHUTDOWN_FAILED","APP_STARTUP_FAILED","LDAP_STARTUP_FAILED","Intalio_STARTUP_FAILED","Jasper_STARTUP_FAILED","rtvscand_SWITCH-OFF_FAILED","rtvscand_SWITCH-ON_FAILED"]
       {
          my ($instance, $action, $dummy) = split(/_/, $mailType);
          $mailSubject = "*PROBLEM* Failed to " . $action . " " . $instance. " of the ".$deployEnvDesc;

          my $mailStr;
          if ( $instance =~ "APP" )
          {
             $mailSubject = "*PROBLEM* Failed to " . $action . " the " . $deployEnvDesc;
             $mailStr = " ";
          }
          else
          {
             $mailStr = " <b><font color=#ff0000>".$instance."</b></font> of ";
          }
          #$mailMsg = "Hi, <br><br> \
          $mailMsg = "It seems that there's a problem " . $action . $mailStr . "the <a href=".$instance_url.">".$deployEnvDesc."</a>.<br> Please refer to the deployment log in the build tool (e.g. Jenkins) for details.";
       }
    }

    return( $mailSubject, $mailMsg );
}

##########################################################################
# SUBROUTINE:
#   sendEmail( <to>, <cc>, <subject>, <message> )
#      Sends email by using /usr/lib/sendmail, but will be utilizing
#      MIME::Lite as needed, which requires downloading/installing from
#      CPAN as it's not currently available on all of our Linux servers.
#
# ARGUMENTS:
#   <to>
#      The email recipient(s)
#
#   <cc>
#      The email cc list
#
#   <subject>
#      The subject line of the email
#
#   <message>
#      The email message
#
# RETURN VALUE: NONE
##########################################################################
sub sendEmail
{
   my ($to, $cc, $subject, $message) = @_;

   my $MAIL_TOOL = &getMailTool();
   unless( open(MAIL, "|$MAIL_TOOL") )
   {
      &LOG(\*STDERR, "*ERROR* Failed to open the mail program, $MAIL_TOOL -- $! Please verify. Abort deployment...\n\n");
      exit(1);
   }

print MAIL <<TO_END;
To: $to
Cc: $cc
Subject: $subject
Content-Type: Text/Html; Charset="iso-8859-1"

$message

TO_END
   close(MAIL);
}

##########################################################################
# SUBROUTINE:
#   processInstanceServProcess( <procInstServScript> <servName> <appUsr>
#                               <deployEnvIP> <action> [version] ):
#
#   Perform given action to a server process associated with the
#   application instance on the given deployment server
#
# ARGUMENTS:
#   <procInstServScript>
#     The script that actually performs the given action
#
#   <servName>
#     The name of a server process to which the given action to be performed
#
#   <appUsr>
#     The user name (e.g. traksmart) under which the application is running
#
#   <deployEnvIP>
#     The IP address of an instances--This is used for the situation"
#     that multiple instances are running on the same machine"
#     (e.g. QA .210 & .217) that their startup scripts are named"
#     by an IP address file extension
#
#   <action>
#     One of the following ones:
#        stop   : stops the application instance"
#        start  : starts the application instance"
#        restart: restarts the application instance"
#
#   [version]
#     Application release/version (e.g. 5.5.0, 5.6.0, etc) 
##########################################################################
sub processInstanceServProcess
{
    my ($procInstServScript, $servName, $appUsr, $deployEnvIP, $action, $version, $workflow_engine) = @_;

    #my $cmd = "${HOME_DIR}/bin/processInstanceServProcess.sh $deployEnvIP $action";
    my $cmd = "$procInstServScript $servName $appUsr $deployEnvIP $action $version $workflow_engine";
    &execCmd( "$cmd" );
}

##########################################################################
# runUITests()
#    Launch auto UI tests
#
##########################################################################
sub runUITests
{
   my ($bld_serv_url, $version, $serv_url) = @_;

   # Doesn't seem to be able to launch Jenkins job with the following curl command-line after upgrading to v1.577
   #my $cmd = "${bld_serv_url}/job/TS-${version}-UI-Tests-CD/buildWithParameters?version=${version}\&browser=FIREFOX\&serv_url=${serv_url}\&login=nexantsupport\&passwd=Test\.123";
   #my $cmd = "${bld_serv_url}/job/TS-${version}-UI-Tests-CD/buildWithParameters?version=${version}\&browser=CHROME\&serv_url=${serv_url}\&login=nexantsupport\&passwd=Test\.123";
   my $cmd = "(cd /tmp; rm -f jenkins-cli.jar; wget ${bld_serv_url}/jnlpJars/jenkins-cli.jar)";
   &execCmd( $cmd );

   $cmd = "java -jar /tmp/jenkins-cli.jar -s ${bld_serv_url} build TS-${version}-UI-Tests-CD -p \"version=${version} browser=CHROME serv_url=${serv_url} login=nexantsupport passwd=Test.123\" --username jenkins --password J3nK1nS";

   print STDERR "INFO: Launching \"$cmd\" to start auto tests ...\n";
#   &execCmd( "/usr/bin/curl --user jenkins:$N1k03J \"$cmd\"" );
   &execCmd( $cmd );
}

