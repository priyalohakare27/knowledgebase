# Class for Deploy related functionalities
package BRS::Release::FullRelease::Deploy_Customization;

use strict;
use warnings;
use Switch;
use List::Util 'max';
use Cwd;
use Carp;
use File::Basename;
use BRS::Release::FullRelease;
our @ISA = qw(BRS::Release::FullRelease);

use BRS::Utils;


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class) = shift;

  my $self = $class->SUPER::new( @_ );

  $self->init( @_ );

  bless( $self, $class );

  return( $self );
}

##############################################################
# Destructor
##############################################################
sub DESTROY
{
   my ($self) = shift;

   &removeFile( $self->deploy_state_file ) if( defined( $self->deploy_state_file ) && -r $self->deploy_state_file );
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Check/enforce mandatory options as Getopt::Long::GetOptions doesn't
   # do so -- That's why it's called GetOptions??
   Usage( "\n***ERROR: You must specify an application user ID (e.g. traksmart) under which the application is running***\n\n" ) unless defined( $args->{app_usr} );
   Usage( "\n***ERROR: You must specify at least one application server IP address (e.g. 172.20.19.128) on which the artifact is to be deployed***\n\n" ) unless defined( $args->{app_serv_ip} );

   # Initialize common build/release data through the parent class
   $self->SUPER::init( $args );

   # Set the default values, which will be overwritten by those specifying in the
   # ${home}/BRS/conf/.Deploy.conf file (if any), which in turn will be overwritten
   # by those specifying through the command-line options
   max_ping_tries( $self, 60 ); # Max. number of tries on ping'ing an app. instance
   sleep_time( $self, 15); # Number of seconds to sleep befre re-ping'ing

  # web server (e.g. Jetty, Tomcat, etc) related script/config files (default is Jetty)
   web_serv_name( $self, "jetty" );
   web_serv_script( $self, "/etc/init.d/jetty" );
   web_serv_config_file( $self, "/etc/default/jetty" );

   # Set the data specific to this Deploy object
   # with the ones specified on the command-line
   app_serv_ip( $self, $args->{app_serv_ip} );
   artifact_download_dir( $self, $args->{artifact_download_dir} );
   custom_customer( $self, $args->{custom_customer} );
   workflow_engine( $self, $args->{workflow_engine} );
   
   my ($default_brs_data, $tmpStr, $msg);

   my $configFilePath = ${home}."/BRS/conf/.Deploy.conf";
   inst_proc_script( $self, "${home}/bin/processInstanceServProcess.sh" );

  

   # In case the deployment configuration file is missing or empty, so that we can still send email to the right person(s)
   deployerr_mail_to( $self, $args->{deployerr_mail_to} );
   my $res = &isValidEmailAddress( $self->deployerr_mail_to );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email TO list, " . $res . " (as specified in " . $configFilePath . ", is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   deployerr_mail_cc( $self, $args->{deployerr_mail_cc} );
   $res = &isValidEmailAddress( $self->deployerr_mail_cc );
   unless( $res =~ "VALID" )
   {
       $msg = "The deploy error email CC list, " . $res . " (as specified in " . $configFilePath . ", is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       exit(1);
   }

   # Override the default config file with the one specified in command-line, if any
   $configFilePath = $args->{config_file} if defined( $args->{config_file} );

   my ($ip1, $ip2, $ip3, $ip4) = split( /\./, $self->app_serv_ip );
   runtime_env( $self, ($ip1 =~ "172") ? "qa" : "nonqa" );

   # Override with those given in the command-line arguments if any
   email_to_list( $self, $args->{email_to_list} );
   $res = &isValidEmailAddress( $self->email_to_list );
   unless( $res =~ "VALID" )
   {
       $msg = "The email TO list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Non \@nexant.com email TO addresses were specified!", $msg );
       exit(1);
   }

   email_cc_list( $self, $args->{email_cc_list} );
   $res = &isValidEmailAddress( $self->email_cc_list );
   unless( $res =~ "VALID" )
   {
       $msg = "The email CC list, " . $res . " (as specified in " . $configFilePath . "), is invalid--It must be of a \@nexant.com one! Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Non \@nexant.com email CC addresses were specified!", $msg );
       exit(1);
   }

	# Override the default config file with the one specified in command-line, if any
    $configFilePath = $args->{config_file} if defined( $args->{config_file} );
	
	if ( -r $configFilePath )
   {
       # Retrieve default common build/release data from the config file
       $default_brs_data = readConfigFile( $configFilePath );

       # Double check just in case
       unless( %{$default_brs_data} )
       {
          $msg = "Nothing was read/retrieved from the deployment config file, " . $configFilePath . "--Likely due to the file is either empty or corrupted! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Deployment config file seems to be either empty or corrupted!", $msg );
          exit(1);
       }

       # Retrieve email TO/CC lists (for sending email about deployment errors) from the default config file
       my ($deployerrMailTO, $deployerrMailCC) = &getEmailList( "deployerr", $self->runtime_env, $default_brs_data );
       deployerr_mail_to( $self, $deployerrMailTO );
       deployerr_mail_cc( $self, $deployerrMailCC );

       max_ping_tries( $self, $default_brs_data->{$self->max_ping_tries} );
       sleep_time( $self, $default_brs_data->{$self->sleep_time} );

       inst_proc_script( $self, "${home}/bin/$default_brs_data->{inst_proc_script}" );

       db_bk_script( $self, "${home}/bin/$default_brs_data->{db_bk_script}" );

       web_serv_name( $self, $default_brs_data->{$self->web_serv_name} );
       web_serv_script( $self, $default_brs_data->{web_serv_script} );
       web_serv_config_file( $self, $default_brs_data->{web_serv_config_file} );

       unless( $default_brs_data->{$self->app_serv_ip} )
       {
          $msg = "The IP address, ". $self->app_serv_ip . ", that associates with the instance URL line is not found in " . $configFilePath . ". Perhaps this is a new application server that its instance URL line has not been added! Please verify.";
          &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
          &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* IP address not found in the deployment config file missing!", $msg );
          exit(1);
       }
   }
   else
   {
       $msg = "The deployment config file, " . $configFilePath . ", is missing! Perhaps it was removed accidently? Please verify.";
       &LOG(\*STDERR, "*ERROR* " . $msg . " Aborting deployment...\n\n");
       &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, "*PROBLEM* Deployment config file is missing!", $msg );
       exit(1);
   }
   
   if ( $self->app_serv_ip =~ "172.20.18.53" && $VER !~ "HEAD" )
   {
       web_serv_script( $self, $self->web_serv_script . "_" . $self->app_usr . $VER ); 
       web_serv_config_file( $self, $self->web_serv_config_file . "_" . $self->app_usr . $VER ); 
   }
   else
   {
       web_serv_script( $self, $args->{web_serv_script} );
   }
}

###############################################################
# Method to update the current deployment state according to
# the deployment state file.
###############################################################
sub updateCurrDeployStateFromFile
{
   my ($self) = shift;

   my $deployStateRef = readConfigFile( $self->deploy_state_file );
   curr_deploy_state( $self, $deployStateRef->{curr_deploy_state} );
}

#################################################################
# Method to determine/handle whether this is a re-deployemnt of
# the same build to the same server (which was terminated earlier
# due to certain reason) or this is a brand new deployemnt
#################################################################
sub handleDeployState
{
   my ($self) = shift;

   my $cmd;
   if( -r $self->deploy_state_file )
   {
      &LOG( \*STDOUT, "INFO: The depoyment state file, '". $self->deploy_state_file ."', does already exist (i.e. This is a re-deployment of the same build to the same application server).\n" );

      # Update the deployment state accordingly
      &updateCurrDeployStateFromFile( $self );
   }
   else
   {
      &LOG( \*STDOUT, "INFO: The depoyment state file, '". $self->deploy_state_file ."', does NOT exist (i.e. This is a brand new deployemnt).\n" );

      # Update the deployment state file accordingly
      $cmd = "echo curr_deploy_state=NEW > " . $self->deploy_state_file;
      &execCmd( "$cmd" );
   }
}

##########################################################################
# installArtifact( <obj> )
#    Retrieves and installs the artifact (e.g. a .war file)
#
# <obj>
#    This reference of this Deploy object
#
##########################################################################
sub installArtifact
{
    my ($self) = shift;
    my $web_serv_home = $self->web_serv_home;
    my $appName = $self->app_name;
    my $artifact_name = $self->artifact_name;
    my $artifactDir = $self->artifact_dir;
    my $build_serv_url = $self->build_serv_url;
    my $build_job = $self->build_job;
	my $lastBuildPath = $web_serv_home . "/lastBuild";
  
    my $artifact_download_dir = $self->artifact_download_dir;
    my $custom_customer = $self->custom_customer;

    my ($tmpNameBackup, $artifactLoc, $timestamp, $cmd);

   

    # Retriving the needed info
    my $artifactDirPath = ${lastBuildPath}."/".${artifactDir}; #"/home/traksmart/build/";

    &LOG( \*STDOUT, "INFO: application name: '${appName}'\n" );
    &LOG( \*STDOUT, "INFO: artifact names: '${artifact_name}'\n" );
    &LOG( \*STDOUT, "INFO: cd into '${lastBuildPath}'.\n" );
	&changeDir( $lastBuildPath );
	
    # If customer customizations is needed, launch a build to generate
    # a tar.gz with customization files, to be downloaded and untar
    # into the artifact directory
    if ( $custom_customer !~ "NONE" )
    {
        my $VERSION = &getRelVersion( $build_job );
        $build_job = lc( $build_job );
        #$cmd = $build_serv_url . "/job/TS-Customize/buildWithParameters?CUSTOMER=" . $custom_customer . "\&RELEASE=".$VERSION;
        $cmd = "(cd /tmp; rm -f jenkins-cli.jar; wget ${build_serv_url}/jnlpJars/jenkins-cli.jar)";
        &LOG( \*STDOUT, "INFO: Launching \"$cmd\" to install jenkins-cli.jar for starting Jenkins job in command-line.\n");
        &execCmd( $cmd );

        sleep 15;
	
        $cmd = "java -jar /tmp/jenkins-cli.jar -s ${build_serv_url} build TS-Customize -p CUSTOMER=${custom_customer} -p RELEASE=${build_job} --username jenkins --password J3nK1nS";

        print STDERR "INFO: Launching \"$cmd\" to create customization package ...\n";
		eval{
			&execCmd( $cmd );
		};

        sleep 90;

        my $customZipFile = $custom_customer . "_Customizations_" . $VERSION . ".tar.gz";
        my $customZipFilePath = $build_serv_url . "/job/TS-Customize/lastBuild/artifact/target/$customZipFile";

        &LOG( \*STDOUT, "INFO: Downloading '$customZipFilePath'.\n");

        # wget the customizations zip file
        &execCmd( "wget $customZipFilePath" );
        &LOG( \*STDOUT, "INFO: Installing '$customZipFilePath'.\n");

        # untar the customizations zip file
        &execCmd( "tar -zxvf $customZipFile" );
    }
}

###############################################################
# Method to deploy the artifact to the given application server
###############################################################
sub deploy
{
    my ($self) = shift;

    my ($instance, $cmd, $msg);

    my $ver = "";
    if ( $self->app_serv_ip =~ "172.20.18.53" )
    {
        $ver = &getRelVersion( $self->build_job );
    }

    # Automatically stop the application instance as needed, unless it's specified
    # to manually stop the application instance (This should be rare -- One example
    # would be when we're deploying a CMS build together with Tradeally in which
    # the application instance should have already been stopped when the CMS/Tradeally
    # deployment process started earlier)
	   &LOG(\*STDOUT, "INFO: Shutting down ". $self->instance_name ."(IP: ". $self->app_serv_ip .")'s ". $self->web_serv_name ." process.\n");

	   $instance = $self->instance_url;

	   # For 172.20.18.53, since it's being used for running multiple (e.g. HEAD, 6.0.0, etc) UI tests, while only one instance is supposed
	   # to be running at a time, we will need to shutdown all instances before starting any instance for running UI tests
	   #if ( $self->app_serv_ip =~ "172.20.19.194" && $ver !~ "HEAD" )
	   if ( $self->app_serv_ip =~ "172.20.18.53" && $ver !~ "HEAD" )
	   {
		  &processInstanceServProcess( $self->inst_proc_script, $self->web_serv_name, $self->app_usr, $self->app_serv_ip, "stop", "");
	   }

	   &processInstanceServProcess( $self->inst_proc_script, $self->web_serv_name, $self->app_usr, $self->app_serv_ip, "stop", $ver);

	   # Due to fire wall rules, wget on Staging/Production servers' DNS URLs won't work
	   # One way to get around this: wget http://localhost:8080/<app_name>/unprotected/login.do
	   if ( $self->runtime_env =~ m/staging|prod/i )
	   {
		  $instance = "http://localhost:8080/" . $self->app_name . "/unprotected/login.do";
	   }

	   # Pings the staus of the applicationb instance repeatedly until either
	   # it's shutdown or timeout after the given time period.
	   if ( &waitInstance( $instance, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "application", "shutdown" ) =~ "TIMEOUT" )
	   {
		   # Sending out failure email and abort deployment if the application instance failed to be shutdwon
		   # after certain time--This situation should be rare but if so happen relevant parties will be notified
		   # for further investigation...
		   &sendEmail( $self->deployerr_mail_to, $self->deployerr_mail_cc, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "APP_SHUTDOWN_FAILED") );

		   &LOG( \*STDERR, "*ERROR* Failed to shutdwon ". $self->instance_name ."'s ". $self->web_serv_name ." process! Please verify. Abort deployment... \n" );
		   exit(1);
	   }

	   &LOG( \*STDOUT, "INFO: ". $self->instance_name ."'s ". $self->web_serv_name ." process is shutdown now.\n" );
	   $cmd = "echo curr_deploy_state=APP_INSTANCE_SHUTDOWN > " . $self->deploy_state_file;
	   &execCmd( "$cmd" );

	   # Update the deployment state file accordingly
	   curr_deploy_state( $self, "APP_INSTANCE_SHUTDOWN\n" );

	   &LOG( \*STDOUT, "INFO: Removing ". $self->web_serv_home . "/tmp/* \n" );
	   $cmd = "rm -rf " . $self->web_serv_home . "/tmp/*";
	   &execCmd( "$cmd" );

    &LOG(\*STDOUT, "INFO: Start installing the artifact/tar-file.\n");

    # Install the artifact
    &installArtifact($self);

    # Automatically start the application instance as needed, unless it's specified
    # to manually start the application instance (This should be rare -- One example
    # would be when we're deploying a CMS build together with Tradeally in which
    # the application instance should only be started after both CMS & Tradeally
    # builds have already been deployed to the same webapps directory on the same VM)
       &LOG(\*STDOUT, "INFO: Starting up ". $self->instance_name ."(IP: ". $self->app_serv_ip . ")'s ". $self->app_name ."/". $self->web_serv_name ." process.\n");
	   &LOG(\*STDOUT, "Workflow engine name: ". $self->workflow_engine."\n");

       # Start up the specific application instance
       &processInstanceServProcess( $self->inst_proc_script, $self->web_serv_name, $self->app_usr, $self->app_serv_ip, "start", $ver, $self->workflow_engine);

       $instance = $self->instance_url;

       #if ( $self->app_serv_ip =~ "172.20.18.53" && $ver !~ "HEAD" )
       #{
       #   $instance = "http://" . $self->app_serv_ip . ":8180/" . $self->app_name . "/unprotected/login.do";
       #}

       # Due to fire wall rules, wget on Staging/Production servers' DNS URLs won't work
       # One way to get around this: wget http://localhost:8080/<app_name>/unprotected/login.do
       if ( $self->runtime_env =~ m/staging|prod/i )
       {
          $instance = "http://localhost:8080/" . $self->app_name . "/unprotected/login.do";
       }

       &LOG( \*STDOUT, "INFO: Ping'ing the startup status of ". $self->instance_name ."'s ". $self->web_serv_name ." instance: ". $self->instance_url ."\n");

       # Pings the staus of the applicationb instance repeatedly until either
       # it's shutdown or timeout after the given time period.
       if ( &waitInstance( $instance, $self->app_serv_ip, $self->app_usr, $self->max_ping_tries, $self->sleep_time, "application", "startup" ) =~ "TIMEOUT" )
       {
           # Sending out failure email and abort deployment if the application instance
           # failed to start after certain time--This will usually be caused by some
           # application-related exceptions/errors, database connection timeout during
           # application start-up, or application taking longer than maximum wait time
           # (i.e. 15 minutes) to start up
           &sendEmail( $self->email_to_list, $self->email_cc_list, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num, "APP_STARTUP_FAILED") );

           &LOG( \*STDERR, "*ERROR* Failed to start up ". $self->instance_name ."'s ". $self->web_serv_name ." instance. Please verify. Abort deployment...\n\n" );
           exit(1);
       }

    &LOG(\*STDOUT, "INFO: Deployment of " . $self->build_job . " build #" . $self->build_num . " to the " .$self->instance_name . " (IP: " . $self->app_serv_ip . ") server is COMPLETED SUCCESSFULLY.\n");

    # Only handle email notification situation when the relevant flag is set (to TRUE).
    # Currently, the flag is only set to FALSE when we're deploying CMS together with
    # TradeAlly
    if ( $self->do_email_notification )
    {
       &LOG(\*STDOUT, "INFO: Sending completion email to " . $self->email_to_list . " " . $self->email_cc_list .".\n");

       # Send deployement done email
       &sendEmail( $self->email_to_list, $self->email_cc_list, &genEmail( $self->instance_name, $self->instance_url, $self->build_serv_url, $self->app_serv_ip, $self->build_job, $self->build_num,, "DEPLOY-DONE") ) if ( $self->trigger_other_build =~ "NONE" );
    }
}

##############################################################
# Method to set/get the workflow engine type (e.g. Intallio/Activiti)
# using which the application is running.
#
# If an workflow engine is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub workflow_engine
{
   my ($self, $workflow_engine) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called workflow_engine() with a class! Please call with an object instead.";
   }

   $self->{_workflow_engine} = $workflow_engine if defined( $workflow_engine ) && $workflow_engine;
   return( $self->{_workflow_engine} );
}

##############################################################
# Method to set/get the number of seconds to sleep
#
# If a number of seconds to sleep is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub sleep_time
{
   my ($self, $sleep_time) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called sleep_time() with a class! Please cal with an object instead.";
   }

   $self->{_sleep_time} = $sleep_time if defined( $sleep_time ) && $sleep_time;
   return( $self->{_sleep_time} );
}

##############################################################
# Method to set/get the path of the application instance
# processing ((re)start/stop) script.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub inst_proc_script
{
   my ($self, $inst_proc_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called inst_proc_script() with a class! Please cal with an object instead.";
   }

   $self->{_inst_proc_script} = $inst_proc_script if defined( $inst_proc_script ) && $inst_proc_script;
}
   return( $self->{_inst_proc_script} );

   
##############################################################
# Method to set/get the web server name.
#
# If a web server name is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub web_serv_name
{
   my ($self, $web_serv_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_name() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_name} = $web_serv_name if defined( $web_serv_name ) && $web_serv_name;
   return( $self->{_web_serv_name} );
}
   
##############################################################
# Method to set/get the path of the web server (re)start/stop
# script.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub web_serv_script
{
   my ($self, $web_serv_script) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_script() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_script} = $web_serv_script if defined( $web_serv_script ) && $web_serv_script;
   return( $self->{_web_serv_script} );
}

##############################################################
# Method to set/get the path of the web server config file.
#
# If a path is given, set the value; otherwise just returns
# the existing data.
##############################################################
sub web_serv_config_file
{
   my ($self, $web_serv_config_file) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called web_serv_config_file() with a class! Please cal with an object instead.";
   }

   $self->{_web_serv_config_file} = $web_serv_config_file if defined( $web_serv_config_file ) && $web_serv_config_file;
   return( $self->{_web_serv_config_file} );
}
   
##############################################################
# Method to set/get the email-to list.
#
# If an email-to list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub email_to_list
{
   my ($self, $email_to_list) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called email_to_list() with a class! Please cal with an object instead.";
   }

   $self->{_email_to_list} = $email_to_list if defined( $email_to_list ) && $email_to_list;
   return( $self->{_email_to_list} );
}

##############################################################
# Method to set/get the email-cc list.
#
# If an email-cc list is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub email_cc_list
{
   my ($self, $email_cc_list) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called email_cc_list() with a class! Please cal with an object instead.";
   }

   $self->{_email_cc_list} = $email_cc_list if defined( $email_cc_list ) && $email_cc_list;
   return( $self->{_email_cc_list} );
}


##############################################################
# Method to set/get the application server IP address on which
# the artifact is to be deployed.
#
# If a application server IP address is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub app_serv_ip
{
   my ($self, $app_serv_ip) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_serv_ip() with a class! Please cal with an object instead.";
   }

   $self->{_app_serv_ip} = $app_serv_ip if defined( $app_serv_ip ) && $app_serv_ip;
   return( $self->{_app_serv_ip} );
}

##############################################################
# Method to set/get the download directory to retrieve the
# artifact for deployment
#
# If a artifact_download_dir is given, set the value;
# otherwise just returns the existing data.
##############################################################
sub artifact_download_dir
{
   my ($self, $artifact_download_dir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called artifact_download_dir() with a class! Please cal with an object instead.";
   }

   $self->{_artifact_download_dir} = $artifact_download_dir if defined( $artifact_download_dir ) && $artifact_download_dir;
   return( $self->{_artifact_download_dir} );
}

##############################################################
# Method to set/get the customer (e.g. CGV, PSEG) that needs
# customizations; default to NONE (i.e. no customizations
# is needed.
#
# If a customer or NONE is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub custom_customer
{
   my ($self, $custom_customer) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called custom_customer() with a class! Please cal with an object instead.";
   }

   $self->{_custom_customer} = $custom_customer if defined( $custom_customer ) && $custom_customer;
   return( $self->{_custom_customer} );
}


##############################################################
# Method to set/get the do_email_notification flag
#
# If an argument is given, set the value; otherwise just
# returns the existing data.
##############################################################
sub do_email_notification
{
   my ($self, $do_email_notification) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called do_email_notification() with a class! Please cal with an object instead.";
   }

   $self->{_do_email_notification} = $do_email_notification if defined( $do_email_notification ) && $do_email_notification;
   return( $self->{_do_email_notification} );
}

##############################################################
# Method to set/get the application name (e.g. traksmart4).
#
# If an application name is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub app_name
{
   my ($self, $app_name) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called app_name() with a class! Please cal with an object instead.";
   }

   $self->{_app_name} = $app_name if defined( $app_name ) && $app_name;
   return( $self->{_app_name} );
}


##############################################################
# Method to set/get the artifact directory (e.g. traksmart4)
# sitting under the JETTY_HOME/webapps directory.
#
# If an artifact directory is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub artifact_dir
{
   my ($self, $artifact_dir) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called artifact_dir() with a class! Please cal with an object instead.";
   }

   $self->{_artifact_dir} = $artifact_dir if defined( $artifact_dir ) && $artifact_dir;
   return( $self->{_artifact_dir} );
}

##############################################################
# Method to set/get the current deployment state.
#
# If a deployment state is given, set the value; otherwise
# just returns the existing data.
##############################################################
sub curr_deploy_state
{
   my ($self, $curr_deploy_state) = @_;

   unless( ref $self )
   {
      croak "Incorrectly called curr_deploy_state() with a class! Please cal with an object instead.";
   }

   $self->{_curr_deploy_state} = $curr_deploy_state if defined( $curr_deploy_state ) && $curr_deploy_state;
   return( $self->{_curr_deploy_state} );
}

##############################################################
# Prints the Release object info
##############################################################
sub print_info
{
   my $self = shift;

   $self->SUPER::print_info();

   printf( "app_serv_ip: '%s'\ncustom_customer: '%s'\napp_name: '%s'\nartifact_name: '%s'\nartifact_dir: '%s'\ninstance_url: '%s'\ninstance_name: '%s'\nweb_serv_name: '%s'\nweb_serv_home: '%s'\nnexant_app_home: '%s'\nruntime_env: '%s'\nweb_serv_script: '%s'\nweb_serv_config_file: '%s'\ninst_proc_script: '%s'\ndb_bk_script: '%s'\nldap_ctl_script: '%s'\nintalio_ctl_script: '%s'\njasper_ctl_script: '%s'\nldap_bk_script: '%s'\nintalio_bk_script: '%s'\njasper_bk_script: '%s'\nartifact_download_dir: '%s'\napp_prop_file: '%s'\n(Intalio) integration_host: '%s'\n(Intalio) integration_ip_internal: '%s'\njasper_hostname: '%s'\nldap_host: '%s'\ndb_type: '%s'\ndb_host: '%s'\ndb_port: '%s'\ndb_name: '%s'\ndb_usr: '%s'\ndb_passwd: '%s'\ndb_bkdir: '%s'\ndb_bk_status_file: '%s'\ndb_bk_stderr_file: '%s'\nldap_full_bkdir: '%s'\ndeploy_state_file: '%s'\ntrigger_other_build: '%s'\ndo_email_notification: '%s'\nmanual_stop_appInst: '%s'\nmanual_start_appInst: '%s'\nmanual_stop_intalio: '%s'\nmanual_start_intalio: '%s'\nmanual_stop_jasper: '%s'\nmanual_start_jasper: '%s'\nmanual_stop_ldap: '%s'\nmanual_start_ldap: '%s'\nmanual_switchoff_rtvscand: '%s'\nmanual_switchon_rtvscand: '%s'\nmanual_bk_ldap: '%s'\nmanual_bk_intalio: '%s'\nmanual_bk_jasper: '%s'\nmanual_bk_docsdir: '%s'\nmanual_bk_appdb: '%s'\nmax_ping_tries: %d\nsleep_time: %d\n", $self->app_serv_ip, $self->custom_customer, $self->app_name, $self->artifact_name, $self->artifact_dir, $self->instance_url, $self->instance_name, $self->web_serv_name, $self->web_serv_home, $self->nexant_app_home, $self->runtime_env, $self->web_serv_script, $self->web_serv_config_file, $self->inst_proc_script, $self->db_bk_script, $self->ldap_ctl_script, $self->intalio_ctl_script, $self->jasper_ctl_script, $self->ldap_bk_script, $self->intalio_bk_script, $self->jasper_bk_script, $self->artifact_download_dir, $self->app_prop_file, $self->integration_host, $self->integration_ip_internal, $self->jasper_hostname, $self->ldap_host, $self->db_type, $self->db_host, $self->db_port, $self->db_name, $self->db_usr, '******', $self->db_bkdir, $self->db_bk_status_file, $self->db_bk_stderr_file, $self->ldap_full_bkdir, $self->deploy_state_file, $self->trigger_other_build, $self->do_email_notification ? 'TRUE' : 'FALSE', $self->manual_stop_appInst ? 'TRUE' : 'FALSE', $self->manual_start_appInst ? 'TRUE' : 'FALSE', $self->manual_stop_intalio ? 'TRUE' : 'FALSE', $self->manual_start_intalio ? 'TRUE' : 'FALSE', $self->manual_stop_jasper ? 'TRUE' : 'FALSE', $self->manual_start_jasper ? 'TRUE' : 'FALSE', $self->manual_stop_ldap ? 'TRUE' : 'FALSE', $self->manual_start_ldap ? 'TRUE' : 'FALSE', $self->manual_switchoff_rtvscand ? 'TRUE' : 'FALSE', $self->manual_switchon_rtvscand ? 'TRUE' : 'FALSE', $self->manual_bk_ldap ? 'TRUE' : 'FALSE',  $self->manual_bk_intalio ? 'TRUE' : 'FALSE',  $self->manual_bk_jasper ? 'TRUE' : 'FALSE', $self->manual_bk_docsdir ? 'TRUE' : 'FALSE', $self->manual_bk_appdb ? 'TRUE' : 'FALSE', $self->max_ping_tries, $self->sleep_time );
}

1;