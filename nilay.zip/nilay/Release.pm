package BRS::Release; # Base class for the Release related functionalities

use strict;
use warnings;
use BRS;
use BRS::Utils;

our @ISA = qw(BRS);


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class) = shift;

  my $self = $class->SUPER::new( @_ );

  $self->init( @_ );

  bless( $self, $class );

  return( $self );
}

##############################################################
# Destructor
##############################################################
sub DESTROY 
{
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Check/enforce mandatory option as Getopt::Long::GetOptions doesn't 
   # do so
   Usage( "\n***ERROR: You must specify a build number (e.g. 23) of the artifact to be deployed***\n" ) unless defined( $args->{build_num} );

   # Initialize common build/release data through the parent class 
   $self->SUPER::init( $args );

   # Set the data specific to this Release object 
   build_num( $self, $args->{build_num} );
   my $build_job_url = $self->build_serv_url . "/job/" . $self->build_job;

   # Only check this when the target application server is in the 172 domain.
   # Otherwise, it won't work
   if ( substr( $args->{app_serv_ip}, 0, 3 ) =~ "172" )
   { 
      unless( &isValidBuildNum( $build_job_url. "/" . $self->build_num ) )
      {
          printf("\n*ERROR* The given build number, '%s', does NOT exist in '%s'! Please double-check and try again.\n\n", $self->build_num, $build_job_url);
          exit(1);
      }
   }
}

##############################################################
# Method to set/get the (e.g. Jenkins) build number associated
# with the artifact to be released/deployed.
#
# If a build job is given, set the value; otherwise returns
# the existing data.
##############################################################
sub build_num
{
   my ($self, $build_num) = @_;
   $self->{_build_num} = $build_num if defined( $build_num );
   return( $self->{_build_num} );
}

##############################################################
# Prints the Release object info
##############################################################
sub print_info
{
   my $self = shift;

   $self->SUPER::print_info();
   printf( "build_num: '%s'\n", $self->build_num );
}

1;
