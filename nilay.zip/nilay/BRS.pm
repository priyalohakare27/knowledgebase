package BRS; # Base class for the Build/Release System

use strict;
use warnings;

use Carp;
use Env;
use Scalar::Util qw(blessed);
use Cwd;
use BRS::Utils;


##############################################################
# Constructor
##############################################################
sub new
{
  my ($class, $args) = @_;

#print "BRS->new\n";

  my $self = bless {}, $class;

  # Initialize common build/release data
  $self->init( $args );

  return( $self );
}

##############################################################
# Initialization
##############################################################
sub init
{
   my ($self, $args) = @_;

   # Check/enforce mandatory options as Getopt::Long::GetOptions doesn't 
   # do so -- That's why it's called GetOptions??
   Usage( "\n***ERROR: You must specify the build job (e.g. TS-rel-5.2.1) by which the artifact to be released/deployed is built***\n" ) unless defined( $args->{build_job} ); 

   my $home = "/home/".$args->{app_usr};

   # Set the default values
   my $configFilePath = $home . "/BRS/conf/.BRS.conf";
   build_serv_url( $self, "http://172.20.19.67:8080" );
   nexus_repo_url( $self, "http://fosbpaeecdev01:8081/nexus/content/repositories" );

   # Override the default config file with the one specified in command-line, 
   # if any 
   $configFilePath = $args->{config_file} if defined( $args->{config_file} );

   my $default_brs_data;
   if ( -r $configFilePath )
   {
       # Retrieve default common build/release data from the config file
       $default_brs_data = readConfigFile( $configFilePath );

       # Double check just in case ...
       unless( %{$default_brs_data} )
       {
          print STDERR "*ERROR* Nothing was read/retrieved from the buildrelease config file, $configFilePath. Might be due to the file is empty. Please verify.\n";
          exit(1);
       } 

       build_serv_url( $self, $default_brs_data->{build_serv_url} );
       nexus_repo_url( $self, $default_brs_data->{nexus_repo_url} );
   }
   else
   {
       print STDERR "*ERROR* The buildrelease config file, $configFilePath, is missing! Something is not right. Please verify.\n";
       exit(1);
   }
 
   # Override the default values with the ones specified in command-line, 
   # if any
   build_serv_url( $self, $args->{build_serv_url} );
   nexus_repo_url( $self, $args->{nexus_repo_url} );
   build_job( $self, $args->{build_job} );

   my $build_url = $self->build_serv_url . "/job/";

   # Only check these when the target application server is in the 172 domain.
   # Otherwise, it won't work
   if ( substr( $args->{app_serv_ip}, 0, 3 ) =~ "172" )
   {
      unless( &isValidURL($self->build_serv_url) )
      {
          printf("\n*ERROR* The given (Jenkins) build server URL, '%s', is not valid! Please verify and try again.\n\n", $self->build_serv_url);
          exit(1);
      }

     unless( &isValidURL($self->nexus_repo_url) )
     {
         printf("\n*ERROR* The given Nexus Maven repository URL, '%s', is not valid! Please verify and try again.\n\n", $self->nexus_repo_url);
         exit(1);
     }

     unless( &isValidBuildJob( $build_url . "/" . $self->build_job ) )
     {
        printf("\n*ERROR* The given build job, '%s', does NOT exist in the build server, '%s'! Please double-check and try again.\n\n", $self->build_job, $self->build_serv_url);
        exit(1);
     }
   }
}

##############################################################
# Method to set/get the (e.g. Jenkins) build server URL.
#
# If an URL is given, set the value; otherwise returns the 
# existing data.
##############################################################
sub build_serv_url
{
   my ($self, $build_serv_url) = @_;
   $self->{_build_serv_url} = $build_serv_url if defined( $build_serv_url ) && $build_serv_url;
   return( $self->{_build_serv_url} );
}

##############################################################
# Method to set/get the Nexus Maven repository URL.
#
# If an URL is given, set the value; otherwise returns the 
# existing data.
##############################################################
sub nexus_repo_url
{
   my ($self, $nexus_repo_url) = @_;
   $self->{_nexus_repo_url} = $nexus_repo_url if defined( $nexus_repo_url ) && $nexus_repo_url;
   return( $self->{_nexus_repo_url} );
}

##############################################################
# Method to set/get the (e.g. Jenkins) build job by which the
# artifact to be released/deployed is built.
#
# If a build job is given, set the value; otherwise returns
# the existing data.
##############################################################
sub build_job
{
   my ($self, $build_job) = @_;
   $self->{_build_job} = $build_job if defined( $build_job );
   return( $self->{_build_job} );
}

##############################################################
# Prints the BRS object info
##############################################################
sub print_info
{
   my $self = shift;
   printf("\n<< %s Objetc Info >>\n", blessed($self));
   printf( "build_serv_url: '%s'\nnexus_repo_url: '%s'\ninst_proc_script: '%s'\nweb_serv_script: '%s'\nweb_serv_config_file: '%s'\nbuild_job: '%s'\nemail_to_list: '%s'\nemail_cc_list: '%s'\n", $self->build_serv_url, $self->nexus_repo_url, $self->inst_proc_script, $self->web_serv_script, $self->web_serv_config_file, $self->build_job, $self->email_to_list, $self->email_cc_list);
}

1;
